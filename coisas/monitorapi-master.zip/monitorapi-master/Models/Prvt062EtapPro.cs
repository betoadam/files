using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MonitorAPI.Models
{
    [Table("PRVT062_ETAP_PRO")]
    public class Prvt062EtapPro
    {
        [Key]
        [Column("ID_ETAP")]
        public int IdEtap { get; set; }

        [Column("ID_PRO")]
        public int IdPro { get; set; }

        [Column("TXT_DESC_ETAP")]
        public int TxtDescEtap { get; set; }

        [Column("ID_ORDE_ETAP")]
        public int IdOrdeEtap { get; set; }

        [Column("ID_SIT_ETAP")]
        public char IdSitEtap { get; set; }

        [Column("DT_H_INC")]
        public DateTime DtHInc { get; set; }

        [Column("DT_H_ATC")]
        public DateTime DtHAtc { get; set; }

    }
}