using Microsoft.EntityFrameworkCore;

namespace MonitorAPI.Models
{
    public class DatabaseContext : DbContext
    {
        public DatabaseContext(DbContextOptions<DatabaseContext> options)
            : base(options)
        {
        }

        public DbSet<Prvt061ProFlux> Prvt061ProFlux { get; set; }
        public DbSet<Prvt062EtapPro> Prvt062EtapPro { get; set; }
        public DbSet<Prvt063DemdProm> Prvt063DemdProm { get; set; }
        public DbSet<Prvt064LgProm> Prvt064LgProm { get; set; }
        public DbSet<Prvt112CeProm> Prvt112CeProm { get; set; }
        public DbSet<Prvt113EvtUsr> Prvt113EvtUsr { get; set; }
        public DbSet<Prvt114LgRel> Prvt114LgRel { get; set; }
        public DbSet<Prvt115ClienteExtrato> Prvt115ClienteExtrato { get; set; }
        public DbSet<Prvt116ChvCript> Prvt116ChvCript { get; set; }
        public DbSet<Prvt012TipoLog> Prvt012TipoLog { get; set; }


        //public DbSet<MonitorAPI.Models.Car> Car { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder) {
            modelBuilder.HasDefaultSchema("SYSTEM");

            modelBuilder.Entity<Prvt064LgProm>()
                .HasKey(c => new { c.IdProt, c.IdEtap });

            modelBuilder.Entity<Prvt112CeProm>()
                .HasKey(c => new { c.CdAg, c.IdNumCc, c.AmRef });

            modelBuilder.Entity<Prvt115ClienteExtrato>()
                .HasKey(c => new { c.CdAg, c.IdNumCc, c.CdAgSegm, c.CdCli });

            modelBuilder.Entity<Prvt116ChvCript>()
                .HasKey(c => new { c.CdAg, c.IdNumCc, c.NmArq, c.IdVsDoc });
            //modelBuilder.Entity<User>().ToTable("USER_LOGINS","SYSTEM");

            // modelBuilder.Entity<User>().HasKey(x=> new{x.id});
            // modelBuilder.Entity<User>().Property("Login").HasColumnName("LOGIN");
            // modelBuilder.Entity<User>().Property("Grupo").HasColumnName("GRUPO");
            // modelBuilder.Entity<User>().Property("id").HasColumnName("ID");
        }
    }
}