using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MonitorAPI.Models
{
    [Table("PRVT114_LG_REL")]
    public class Prvt114LgRel
    {
        [Column("CD_T_LG")]
        public int CdTLg { get; set; }

        [Column("TXT_DESC_ACAO")]
        public string TxtDescAcao { get; set; }

        [Key]
        [Column("DT_MVTO")]
        public DateTime DtMvto { get; set; }

        [Column("TXT_DESC_LG")]
        public string TxtDescLg { get; set; }

        [Column("ID_USR")]
        public string IdUsr { get; set; }

        [Column("DT_H_ATC")]
        public DateTime DtHAtc { get; set; }

        [Column("SGL_SIST")]
        public char? SglSist { get; set; }

        [Column("CD_AG")]
        public int CdAg { get; set; }

        [Column("ID_NUM_CC")]
        public int IdNumCc { get; set; }
    }
}