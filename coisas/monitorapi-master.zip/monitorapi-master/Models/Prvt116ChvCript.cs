using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MonitorAPI.Models
{
    [Table("PRVT116_CHV_CRIPT")]
    public class Prvt116ChvCript
    {
        [Column("CD_AG")]
        public int CdAg { get; set; }

        [Column("ID_NUM_CC")]
        public int IdNumCc { get; set; }

        [Column("DT_REF")]
        public DateTime DtRef { get; set; }

        [Column("TXT_CHV_CRIPT")]
        public string TxtChvCript { get; set; }

        [Column("NM_ARQ")]
        public string NmArq { get; set; }

        [Column("DT_H_ATC")]
        public DateTime DtHAtc { get; set; }

        [Column("ID_VS_DOC")]
        public string IdVsDoc { get; set; }
    }
}