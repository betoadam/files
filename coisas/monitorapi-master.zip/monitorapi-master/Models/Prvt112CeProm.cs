using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MonitorAPI.Models
{
    [Table("PRVT112_CE_PROM")]
    public class Prvt112CeProm
    {
        [Column("CD_AG")]
        public int CdAg { get; set; }

        [Column("ID_NUM_CC")]
        public int IdNumCc { get; set; }

        [Column("AM_REF")]
        public int AmRef { get; set; }

        [Column("ID_TCKT")]
        public int IdTckt { get; set; }

        [Column("IC_CT_QRTN")]
        public char IcCtQrtn { get; set; }

        [Column("IC_ENV_MSG")]
        public char IcEnvMsg { get; set; }

        [Column("ID_RTNO_MSG")]
        public int? IdRtnoMsg { get; set; }

        [Column("ID_VLDC_EMAIL_CAD")]
        public int? IdVldcEmailCad { get; set; }

        [Column("ID_VLDC_TEL_CAD")]
        public int? IdVldcTelCad { get; set; }

        [Column("DT_H_ENV_MSG")]
        public DateTime? DtHEnvMsg { get; set; }

        [Column("CD_AG_ENV_MSG")]
        public int? CdAgEnvMsg { get; set; }

        [Column("ID_NUM_CC_ENV_MSG")]
        public int? IdNumCcEnvMsg { get; set; }

        [Column("ID_TCKT_MSG")]
        public int IdTcktMsg { get; set; }

        [Column("IC_PROM_RNTD_FIXO")]
        public char? IcPromRntdFixo { get; set; }

        [Column("IC_PROM_BNCH_FIXO")]
        public char? IcPromBnchFixo { get; set; }

        [Column("IC_PROM_RNTD_FLEX")]
        public char? IcPromRntdFlex { get; set; }

        [Column("IC_PROM_IND_ACUD")]
        public char? IcPromIndAcud { get; set; }

        [Column("IC_PROM_IND_CDI")]
        public char? IcPromIndCdi { get; set; }

        [Column("IC_PROM_IND_EQVT")]
        public char? IcPromIndEqvt { get; set; }

        [Column("IC_PROM_RESM_CT")]
        public char? IcPromResmCt { get; set; }

        [Column("IC_PROM_MVTC_RF")]
        public char? IcPromMvtcRf { get; set; }

        [Column("IC_PROM_MVTC_FDO")]
        public char? IcPromMvtcFdo { get; set; }

        [Column("IC_PROM_MVTC_PREVD")]
        public char? IcPromMvtcPrevd { get; set; }

        [Column("IC_PROM_MVTC_COE")]
        public char? IcPromMvtcCoe { get; set; }

        [Column("IC_PROM_ATVO_TERC")]
        public char? IcPromAtvoTerc { get; set; }

        [Column("IC_PROM_ATVO_FDO")]
        public char? IcPromAtvoFdo { get; set; }

        [Column("IC_PROM_ATVO_TSDR")]
        public char? IcPromAtvoTsdr { get; set; }

        [Column("IC_PROM_ATVO_PUBL")]
        public char? IcPromAtvoPubl { get; set; }

        [Column("IC_PROM_ATVO_PREVD")]
        public char? IcPromAtvoPrevd { get; set; }

        [Column("IC_PROM_ATVO_CTRA")]
        public char? IcPromAtvoCtra { get; set; }

        [Column("IC_PROM_ATVO_DRTV")]
        public char? IcPromAtvoDrtv { get; set; }

        [Column("IC_PROM_ATVO_COE")]
        public char? IcPromAtvoCoe { get; set; }

        [Column("IC_PROM_FECH_CART")]
        public char? IcPromFechCart { get; set; }

        [Column("TXT_LG_ETAP_PRO")]
        public string TxtLgEtapPro { get; set; }

        [Column("IC_AMST_EXTT_MENS")]
        public char? IcAmstExttMens { get; set; }

        [Column("DT_H_GERC_AMST")]
        public DateTime? DtHGercAmst { get; set; }

        [Column("IC_EXTT_MENS")]
        public char? IcExttMens { get; set; }

        [Column("DT_H_GERC_EXTT")]
        public DateTime? DtHGercExtt { get; set; }
    }
}