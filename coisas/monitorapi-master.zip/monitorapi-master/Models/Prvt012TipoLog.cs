﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MonitorAPI.Models
{
    [Table("PRVT012_TIPO_LOG")]
    public class Prvt012TipoLog
    {
        [Key]
        [Column("CD_T_LG")]
        public int CdTLg { get; set; }
        [Column("TXT_DESC_T_LG")]
        public string TxtDescTLg { get; set; }
    }
}