using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MonitorAPI.Models
{
    [Table("PRVT061_PRO_FLUX")]
    public class Prvt061ProFlux
    {
        [Key]
        [Column("ID_PRO")]
        public int IdPro { get; set; }

        [Column("ID_FLUX")]
        public int IdFlux { get; set; }

        [Column("TXT_DESC_PRO")]
        public string TxtDescPro { get; set; }

        [Column("ID_PRO_PRDS")]
        public int IdProPrds { get; set; }

        [Column("ID_SIT_PRO")]
        public char IdSitPro { get; set; }

        [Column("DT_H_INC")]
        public DateTime DtHInc { get; set; }

        [Column("DT_H_ATC")]
        public DateTime DtHAtc { get; set; }

    }
}