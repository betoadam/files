using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MonitorAPI.Models
{
    [Table("PRVT115_CLIENTE_EXTRATO")]
    public class Prvt115ClienteExtrato
    {
        [Column("AM_REF")]
        public string AmRef { get; set; }

        [Column("CD_AG")]
        public int CdAg { get; set; }

        [Column("ID_NUM_CC")]
        public int IdNumCc { get; set; }

        [Column("SGL_SIST_ORIG")]
        public string SglSistOrig { get; set; }

        [Column("CD_AG_SEGM")]
        public int CdAgSegm { get; set; }

        [Column("CD_CLI")]
        public int CdCli { get; set; }

        [Column("ID_T_SEGM_CLI")]
        public int IdTSegmCli { get; set; }

        [Column("ID_OPC_EXTT")]
        public int IdOpcExtt { get; set; }

        [Column("ID_USR_GRTE")]
        public int IdUsrGrte { get; set; }

        [Column("NM_GRTE_RELM")]
        public int NmGrteRelm { get; set; }

        [Column("NM_ESCT_RELM")]
        public int NmEsctRelm { get; set; }

        [Column("CD_MRC_CLI")]
        public int CdMrcCli { get; set; }

        [Column("ID_T_PES")]
        public int IdTPes { get; set; }

        [Column("NM_GRTE")]
        public int NmGrte { get; set; }

        [Column("ID_NUM_RAM_GRTE")]
        public int IdNumRamGrte { get; set; }

        [Column("ID_EMAIL_GRTE")]
        public int IdEmailGrte { get; set; }

        [Column("DT_H_ATC")]
        public int DtHAtc { get; set; }

        [Column("ID_USR")]
        public int IdUsr { get; set; }

        [Column("ID_TCKT")]
        public int IdTckt { get; set; }
    }
}
