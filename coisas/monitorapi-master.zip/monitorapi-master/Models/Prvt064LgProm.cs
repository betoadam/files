using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MonitorAPI.Models
{
    [Table("PRVT064_LG_PROM")]
    public class Prvt064LgProm
    {
        [Column("ID_PROT")]
        public int IdProt { get; set; }

        [Column("ID_ETAP")]
        public int IdEtap { get; set; }

        [Column("Q_TOT_REGS")]
        public int QTotRegs { get; set; }

        [Column("Q_RG_PROC")]
        public int? QRgProc { get; set; }

        [Column("TXT_OBS")]
        public string TxtObs { get; set; }

        [Column("ID_SIT_ETAP")]
        public char IdSitEtap { get; set; }

        [Column("DT_H_INC")]
        public DateTime? DtHInc { get; set; }

        [Column("DT_H_CCSO")]
        public DateTime? DtHCcso { get; set; }
    }
}