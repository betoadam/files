using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MonitorAPI.Models
{
    [Table("PRVT063_DEMD_PROM")]
    public class Prvt063DemdProm
    {
        [Key]
        [Column("ID_PROT")]
        public int IdProt { get; set; }

        [Column("ID_FLUX")]
        public int IdFlux { get; set; }

        [Column("CD_AG")]
        public int CdAg { get; set; }

        [Column("ID_NUM_CT")]
        public int IdNumCt { get; set; }

        [Column("DT_REF")]
        public DateTime DtRef { get; set; }

        [Column("ID_USR_SLCT")]
        public string IdUsrSlct { get; set; }

        [Column("ID_USR_AUTR")]
        public string IdUsrAutr { get; set; }

        [Column("IC_APRV")]
        public char IcAprv { get; set; }

        [Column("ID_SIT_DEMD")]
        public char IdSitDemd { get; set; }

        [Column("DT_H_INC")]
        public DateTime DtHInc { get; set; }

        [Column("DT_H_CCSO")]
        public DateTime DtHCcso { get; set; }

        [Column("ID_TCKT")]
        public long IdTckt { get; set; }
    }
}