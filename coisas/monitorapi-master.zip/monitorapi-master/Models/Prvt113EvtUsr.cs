using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MonitorAPI.Models
{
    [Table("PRVT113_EVT_USR")]
    public class Prvt113EvtUsr
    {
        [Column("CD_T_LG")]
        public int? CdTLg { get; set; }

        [Column("ID_USR")]
        public int IdUsr { get; set; }

        [Column("TXT_DESC_ACAO")]
        public string TxtDescAcao { get; set; }

        [Key]
        [Column("DT_H_ATC")]
        public DateTime DtHAtc { get; set; }

        [Column("TXT_DESC_FLUX")]
        public string TxtDescFlux { get; set; }
    }
}