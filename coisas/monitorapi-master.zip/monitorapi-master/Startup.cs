using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.EntityFrameworkCore;
using MonitorAPI.Models;
using MonitorAPI.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.OpenApi.Models;
using System;
using System.Reflection;
using System.IO;

namespace MonitorAPI
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }
        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.

        public void ConfigureServices(IServiceCollection services)
        {
            
            services.AddCors(options =>
            {
                options.AddPolicy("Default", builder =>
                {
                    builder.AllowAnyOrigin();
                    builder.AllowAnyMethod();
                    builder.AllowAnyHeader();
                });
            });
            services.AddAuthorization(options =>
            {
                options.AddPolicy("TI", policy => policy.RequireRole("Perfil1", "Perfil2"));
                options.AddPolicy("Backoffice", policy => policy.RequireRole("Perfil1", "Perfil2"));
                options.AddPolicy("Marketing", policy => policy.RequireRole("Perfil1", "Perfil2"));
                options.AddPolicy("Produtos", policy => policy.RequireRole("Perfil1", "Perfil2"));

            });
            services.AddDbContext<DatabaseContext>(opt =>
               //opt.UseInMemoryDatabase("CarList"));
               opt.UseOracle(Configuration.GetConnectionString("DefaultConnection"), x => x.UseOracleSQLCompatibility("11"))
            );

            //services.AddMvc(config =>
            //{
            //    var policy = new AuthorizationPolicyBuilder()
            //                     .RequireAuthenticatedUser()
            //                     .Build();
            //    config.Filters.Add(new AuthorizeFilter(policy));
            //}).SetCompatibilityVersion(CompatibilityVersion.Version_2_1);

            // Register the Swagger generator, defining 1 or more Swagger documents
            
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo 
                { 
                    Title = "MonitorAPI", 
                    Version = "v1" 
                });
                    // Set the comments path for the Swagger JSON and UI.
                    var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
                    var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
                    c.IncludeXmlComments(xmlPath);
            });

            services.AddMvc();
            services.AddSingleton<IConfiguration>(Configuration);
            services.AddScoped<MarketingService>();
            services.AddScoped<Prvt115ClienteExtrato>();
            services.AddScoped<Prvt112CeProm>();
            services.AddScoped<Prvt012TipoLog>(); 
            services.AddScoped<ProdutoService>();
            services.AddScoped<HomeService>();
            services.AddScoped<BackofficeService>(); 
            services.AddScoped<Prvt116ChvCript>(); 
            services.AddScoped<GeracaoService>();
            services.AddScoped<TiService>();
        }

        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            //app.UseCors("Default");
            app.UseCors(x => x
            .AllowAnyOrigin()
            .AllowAnyMethod()
            .AllowAnyHeader()
            );
            app.UseMvc();


            // Enable middleware to serve generated Swagger as a JSON endpoint.
            app.UseSwagger();

            // Enable middleware to serve swagger-ui (HTML, JS, CSS, etc.),
            // specifying the Swagger JSON endpoint.
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "MonitorAPI v1");
            });


        }

       

    }
}