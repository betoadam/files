using System;
using System.IdentityModel.Tokens.Jwt;
using MonitorAPI.Models;
using System.Linq;
using Microsoft.Extensions.Configuration;
using MonitorAPI.DTO;
using System.Collections.Generic;
using MonitorAPI.Oracle;
using System.Data;
using Dapper;
using Microsoft.EntityFrameworkCore;

namespace MonitorAPI.Services
{
    public class ProdutoService
    {
        private readonly DatabaseContext _context;

        public ProdutoService(DatabaseContext context)
        {
            _context = context;
        }

        public Prvt113EvtUsr ObterLog(string tipo)
        {
            //var prvt012Tipo = _context.Prvt012TipoLog.Where(x => x.CdTLg == valores.IdTipoLog).ToList().FirstOrDefault();
            //var user = _context.Users.Where(x => x.Id == valores.IdUser).ToList().FirstOrDefault();
            var user = 4546754;
            var prvt113EvtUsr = new Prvt113EvtUsr()
            {

                //IdUsr = 4546754,
                TxtDescAcao = String.Format("USUARIO: {0} APROVOU TOTALMENTE OS RELATORIO {1}", user, tipo),
                DtHAtc = DateTime.Now,
                CdTLg = 1

            };

            return prvt113EvtUsr;

        }
         public bool auth(string role)
        {

            if (role == "PRODUTO_2"|| role == "TI")
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /*
           (A)pproved
           (W)aiting 
           (P)arcial
           (R)eproved
        */


    }


}
