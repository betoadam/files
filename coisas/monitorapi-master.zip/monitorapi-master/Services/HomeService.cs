using System;
using System.IdentityModel.Tokens.Jwt;
using MonitorAPI.Models;
using System.Linq;
using Microsoft.Extensions.Configuration;
using MonitorAPI.DTO;
using System.Collections.Generic;
using MonitorAPI.Oracle;
using System.Data;
using Dapper;
using Microsoft.EntityFrameworkCore;

namespace MonitorAPI.Services
{
    public class HomeService
    {
        private readonly DatabaseContext _context;
        public HomeService(DatabaseContext context)
        {
            _context = context;
        }

        /*
           (A)pproved
           (W)aiting 
           (P)arcial
           (R)eproved
        */

        public List<ConsultaHomeBaseDTO> ConsultaBase(string data)
        {
            DateTime mesReferencia = Convert.ToDateTime(data);

            List<ConsultaHomeBaseDTO> consulta = (from t061 in _context.Prvt061ProFlux
                                                  join t063 in _context.Prvt063DemdProm on t061.IdFlux equals t063.IdFlux
                                                  join t062 in _context.Prvt062EtapPro on t061.IdPro equals t062.IdPro
                                                  join t064 in _context.Prvt064LgProm on t063.IdProt equals t064.IdProt
                                                  where t063.IdFlux == 4 && t064.IdEtap == t062.IdEtap
                                                  && t063.DtRef.Month == mesReferencia.Month && t063.DtRef.Year == mesReferencia.Year
                                                  select new ConsultaHomeBaseDTO
                                                  {
                                                      TxtDescPro = t061.TxtDescPro,
                                                      IdSitDemd = t063.IdSitDemd,
                                                      IdSitEtap = t064.IdSitEtap
                                                  }).ToList();

            if (consulta.Count() == 0)
            {
                throw new Exception("Nenhum registro foi encontrado! Verifique o mês de referencia!");
            }

            return consulta;
        }

        public RelatorioStatusDTO HomeStatus(string mesReferencia, string tipo, List<ConsultaHomeBaseDTO> consulta)
        {
            DescricaoProcessoDTO descCoe = new DescricaoProcessoDTO(tipo, "TSD");
            DescricaoProcessoDTO descPrevidencia = new DescricaoProcessoDTO(tipo, "RDF");
            DescricaoProcessoDTO descFundos = new DescricaoProcessoDTO(tipo, "FUNDOS");

            List<char> listaTi = (from c in consulta
                                  where c.TxtDescPro.Trim() == descCoe.IntegraSaldoContaCorrente
                                  || c.TxtDescPro.Trim() == descCoe.IntegraMovimentoContaCorrente
                                  || c.TxtDescPro.Trim() == descCoe.IntegraRelacionamentoCliente
                                  || c.TxtDescPro.Trim() == descCoe.IntegraListaCliente
                                  || c.TxtDescPro.Trim() == descCoe.IntegraSaldoPoupanca
                                  || c.TxtDescPro.Trim() == descCoe.IntegraMovimentoPoupanca
                                  || c.TxtDescPro.Trim() == descCoe.IntegraSuitability
                                  || c.TxtDescPro.Trim() == descCoe.RelatorioDados
                                  select (c.IdSitDemd == 'I' && c.IdSitEtap == 'P' ? 'W' : c.IdSitEtap == 'C' ? 'A' : 'R')).ToList();
            //lista ti 9 registros

            char ti = (listaTi.Where(x => x == 'A').Count() == listaTi.Count() ? 'A'
                     : listaTi.Where(x => x == 'W').Count() == listaTi.Count() ? 'W'
                     : listaTi.Where(x => x == 'R').Count() == listaTi.Count() ? 'R'
                     : 'P');

            char marketing1 = (from c in consulta
                             where c.TxtDescPro.Trim() == descCoe.IntegraLaminaFundos
                             select (c.IdSitDemd == 'I' && c.IdSitEtap == 'P' ? 'W' : c.IdSitEtap == 'C' ? 'A' : 'R')
                                                    ).FirstOrDefault();
            List<char> listaMarketing2 = (from c in consulta
                                          where c.TxtDescPro.Trim() == descCoe.RelatorioUploadImagensCE
                                          || c.TxtDescPro.Trim() == descCoe.RelatorioUploadImagensIS
                                          || c.TxtDescPro.Trim() == descCoe.RelatorioUploadImagensRF
                                          select (c.IdSitDemd == 'I' && c.IdSitEtap == 'P' ? 'W' : c.IdSitEtap == 'C' ? 'A' : 'R')
                                        ).ToList();

            char marketing2 = (listaMarketing2.Where(x => x == 'A').Count() == listaMarketing2.Count() ? 'A'
                     : listaMarketing2.Where(x => x == 'W').Count() == listaMarketing2.Count() ? 'W'
                     : listaMarketing2.Where(x => x == 'R').Count() == listaMarketing2.Count() ? 'R'
                     : 'P');

            List<char> listaBackoffice = (from c in consulta
                                          where c.TxtDescPro.Trim() == descCoe.RelatorioValidacaoDados
                                          || c.TxtDescPro.Trim() == descFundos.RelatorioValidacaoDados
                                          || c.TxtDescPro.Trim() == descPrevidencia.RelatorioValidacaoDados
                                          select (c.IdSitDemd == 'I' && c.IdSitEtap == 'P' ? 'W' : c.IdSitEtap == 'C' ? 'A' : 'R')
                                        ).ToList();

            char backoffice = (listaBackoffice.Where(x => x == 'A').Count() == listaBackoffice.Count() ? 'A'
                     : listaBackoffice.Where(x => x == 'W').Count() == listaBackoffice.Count() ? 'W'
                     : listaBackoffice.Where(x => x == 'R').Count() == listaBackoffice.Count() ? 'R'
                     : 'P');

            char produtos = (from c in consulta
                             where c.TxtDescPro.Trim() == descCoe.RelatorioGerarAmostra
                             select (c.IdSitDemd == 'I' && c.IdSitEtap == 'P' ? 'W' : c.IdSitEtap == 'C' ? 'A' : 'R')
                                        ).FirstOrDefault();

            char produtos2 = (from c in consulta
                              where c.TxtDescPro.Trim() == descCoe.RelatorioValidaAmostraPF
                              select (c.IdSitDemd == 'I' && c.IdSitEtap == 'P' ? 'W' : c.IdSitEtap == 'C' ? 'A' : 'R')
                                        ).FirstOrDefault();

            char marketing3 = (from c in consulta
                               where c.TxtDescPro.Trim() == descCoe.RelatorioValidaAmostraMKT
                               select (c.IdSitDemd == 'I' && c.IdSitEtap == 'P' ? 'W' : c.IdSitEtap == 'C' ? 'A' : 'R')
                                        ).FirstOrDefault();

            char automatico = (from c in consulta
                               where c.TxtDescPro.Trim() == descCoe.RelatorioGerarPdf
                               select (c.IdSitDemd == 'I' && c.IdSitEtap == 'P' ? 'W' : c.IdSitEtap == 'C' ? 'A' : 'R')
                                        ).FirstOrDefault();

            var retorno = new RelatorioStatusDTO
            {
                Automatico = automatico,
                Backoffice = backoffice,
                Marketing1 = marketing1,
                Marketing2 = marketing2,
                Marketing3 = marketing3,
                Produtos2 = produtos2,
                Ti = ti,
                Produtos = produtos
            };
            return retorno;
        }

        public Prvt063DemdProm ObterT063(string data)
        {
            DateTime mesReferencia = Convert.ToDateTime(data);

            var consulta = (from t063 in _context.Prvt063DemdProm
                            where t063.IdFlux == 4
                            && t063.DtRef.Month == mesReferencia.Month && t063.DtRef.Year == mesReferencia.Year
                            select t063).ToList().FirstOrDefault();

            return consulta;
        }

        public Prvt064LgProm ObterT064(string data, string descPro)
        {
            DateTime mesReferencia = Convert.ToDateTime(data);

            var consulta = (from t061 in _context.Prvt061ProFlux
                            join t063 in _context.Prvt063DemdProm on t061.IdFlux equals t063.IdFlux
                            join t062 in _context.Prvt062EtapPro on t061.IdPro equals t062.IdPro
                            join t064 in _context.Prvt064LgProm on t063.IdProt equals t064.IdProt
                            where t063.IdFlux == 4 && t064.IdEtap == t062.IdEtap
                            && t063.DtRef.Month == mesReferencia.Month && t063.DtRef.Year == mesReferencia.Year
                            && t061.TxtDescPro.Trim() == descPro
                            select t064).ToList().FirstOrDefault();

            if (consulta == null)
            {
                throw new Exception("Nenhum registro foi encontrado! Verifique o mês de referencia!");
            }

            return consulta;
        }

        public List<Prvt064LgProm> ObterListaT064(string data, List<string> descPro)
        {
            DateTime mesReferencia = Convert.ToDateTime(data);

            var consulta = (from t061 in _context.Prvt061ProFlux
                            join t063 in _context.Prvt063DemdProm on t061.IdFlux equals t063.IdFlux
                            join t062 in _context.Prvt062EtapPro on t061.IdPro equals t062.IdPro
                            join t064 in _context.Prvt064LgProm on t063.IdProt equals t064.IdProt
                            where t063.IdFlux == 4 && t064.IdEtap == t062.IdEtap
                            && t063.DtRef.Month == mesReferencia.Month && t063.DtRef.Year == mesReferencia.Year
                            && descPro.Contains(t061.TxtDescPro.Trim())
                            select t064).ToList();

            if (consulta == null)
            {
                throw new Exception("Nenhum registro foi encontrado! Verifique o mês de referencia!");
            }

            return consulta;
        }

        public List<RetornoAmostraContasDTO> ObterListaT112(string data)
        {
            DateTime mesReferencia = Convert.ToDateTime(data);
            DateTime dataReferencia = new DateTime(mesReferencia.Year, mesReferencia.Month, DateTime.DaysInMonth(mesReferencia.Year, mesReferencia.Month));
            var consulta = (from t112 in _context.Prvt112CeProm
                            join t063 in _context.Prvt063DemdProm on t112.IdTckt equals t063.IdTckt
                            where t063.IdFlux == 4
                            && t112.IcAmstExttMens == 'S'
                            && t063.DtRef.Month == mesReferencia.Month
                            && t063.DtRef.Year == mesReferencia.Year
                            select t112).ToList();

            if (consulta == null)
            {
                throw new Exception("Nenhum registro foi encontrado! Verifique o mês de referencia!");
            }

            List<RetornoAmostraContasDTO> listaAmostraContas = (from c in consulta
                                                                select new RetornoAmostraContasDTO()
                                                                {
                                                                    Sistema = "EXT",
                                                                    Legado = "EXT",
                                                                    Agencia = c.CdAg.ToString(),
                                                                    Conta = c.IdNumCc.ToString(),
                                                                    DataReferencia = dataReferencia.ToString("yyyy/MM/dd").Replace("/", ""),
                                                                    Template = "1",
                                                                    Segmento = "22",
                                                                    CodigoCliente = "4135305",
                                                                    CodigoTipoPessoa = "0007",
                                                                    UsuarioSolicitante = "AUTOMAT"
                                                                }).ToList();

            return listaAmostraContas;
        }

        public List<Prvt113EvtUsr> ObterListaT113()
        {
            return (from t113 in _context.Prvt113EvtUsr
                    select t113).ToList();
        }
        public void GerarAmostra(string data, string tipo)
        {
            HomeService _homeService = new HomeService(_context);
            var descProc = new DescricaoProcessoDTO(tipo, "");

            var amostra = _homeService.ObterT064(data, descProc.RelatorioGerarAmostra);
            amostra.IdSitEtap = 'P';
            _context.Update(amostra);
            _context.SaveChanges();
        }
        public void UploadImagens(string data, string tipo)
        {
            HomeService _homeService = new HomeService(_context);
            var descProc = new DescricaoProcessoDTO(tipo, "");

            var imagensCE = _homeService.ObterT064(data, descProc.RelatorioUploadImagensCE);
            imagensCE.IdSitEtap = 'P';
            _context.Update(imagensCE);

            var imagensIS = _homeService.ObterT064(data, descProc.RelatorioUploadImagensIS);
            imagensIS.IdSitEtap = 'P';
            _context.Update(imagensIS);

            var imagensRF = _homeService.ObterT064(data, descProc.RelatorioUploadImagensRF);
            imagensRF.IdSitEtap = 'P';
            _context.Update(imagensRF);

            _context.SaveChanges();
        }

        public void ArquivoLamina(string data, string tipo)
        {

            HomeService _homeService = new HomeService(_context);
            var descProc = new DescricaoProcessoDTO(tipo, "");

            var lamina = _homeService.ObterT064(data, descProc.IntegraLaminaFundos);
            lamina.IdSitEtap = 'P';
            _context.Update(lamina);
            _context.SaveChanges();
        }

        //operacao = Previdencia/Coe/Fundos
        public void ValidacaoDados(string data, string tipo)
        {

            HomeService _homeService = new HomeService(_context);
            string[] operacao = new string[3] { "TSD", "RDF", "FUNDOS" };

            foreach (var item in operacao)
            {

                var descProc = new DescricaoProcessoDTO(tipo, item);
                var ValidacaoDados = _homeService.ObterT064(data, descProc.RelatorioValidacaoDados);
                ValidacaoDados.IdSitEtap = 'P';
                _context.Update(ValidacaoDados);
                _context.SaveChanges();
            }
        }
    }

}
