﻿using MonitorAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MonitorAPI.DTO;
using Microsoft.Extensions.Configuration;
using Microsoft.EntityFrameworkCore;

using Amqp;
using Amqp.Framing;
using Amqp.Types;

namespace MonitorAPI.Services
{
    public class GeracaoService
    {
        private readonly DatabaseContext _databaseContext;

        private readonly IConfiguration _configuration;

        public GeracaoService(DatabaseContext databaseContext, IConfiguration configuration)
        {
            _databaseContext = databaseContext;
            _configuration = configuration;
        }
        public Prvt116ChvCript ObterLog116(int cdAg, int numCc, string dataRef, string txtChave, string arquivo)
        {
            DateTime data = DateTime.Now;
            var DtRef = String.Format("02/{0}",dataRef);
            DateTime dateRef = DateTime.ParseExact(DtRef, "d", null);

            var t116 = _databaseContext.Prvt116ChvCript
                                             .Where(p => p.CdAg == cdAg)
                                             .Where(x => x.IdNumCc == numCc)
                                             .Where(y => y.TxtChvCript == txtChave).OrderByDescending(z => z.DtHAtc).FirstOrDefault();


            if (t116 != null)
            {
                string vs = t116.IdVsDoc.Substring(1,1); 
                t116.IdVsDoc = "V"+(Convert.ToInt32(vs) + 1).ToString();
                t116.DtHAtc = data;
                return t116;

            }
            else
            {
                var prvt116 = new Prvt116ChvCript()
                {
                    CdAg = cdAg,
                    IdNumCc = numCc,
                    DtRef = dateRef,
                    DtHAtc = data,
                    TxtChvCript = txtChave,
                    NmArq = arquivo,
                    IdVsDoc = "V1"



                };

                return prvt116;
            }
            



        }

        // List<RetornoAmostraContasDTO>
        public void verifyTosend(string data, int tipo)
        {

            DateTime mesReferencia = Convert.ToDateTime(data);

            // Consulta para o modelo de dev externo
            // var consulta = (from t112 in _databaseContext.Prvt112CeProm
            //                 join t063 in _databaseContext.Prvt063DemdProm on t112.IdTckt equals t063.IdTckt
            //                 join t115 in _databaseContext.Prvt115ClienteExtrato on t112.CdAg equals t115.CdAg
            //                 where t063.IdFlux == 4
            //                 && t115.IdNumCc == t112.IdNumCc
            //                 && t112.DtHEnvMsg == null 
            //                 && t112.IcEnvMsg == 'N' 
            //                 && t115.IdTpRel == tipo 
            //                 && t112.IcAmstExttMens != 'S'
            //                 && t112.IcExttMens != 'B'
            //                 && t063.DtRef.Month == mesReferencia.Month
            //                 && t063.DtRef.Year == mesReferencia.Year
            //                 select t112).ToList();


            var consulta = (from t112 in _databaseContext.Prvt112CeProm
                            join t063 in _databaseContext.Prvt063DemdProm on t112.IdTckt equals t063.IdTckt
                            join t115 in _databaseContext.Prvt115ClienteExtrato on t112.CdAg equals t115.CdAg
                            where t063.IdFlux == 4
                            && t115.IdNumCc == t112.IdNumCc
                            && t112.DtHEnvMsg == null 
                            && t112.IcEnvMsg == 'N' 
                            && t115.IdOpcExtt == tipo 
                            && t112.IcAmstExttMens != 'S'
                            && t112.IcExttMens != 'B'
                            && t063.DtRef.Month == mesReferencia.Month
                            && t063.DtRef.Year == mesReferencia.Year
                            select t112).ToList();

            if (consulta == null)
            {
                throw new Exception("Nenhum registro foi encontrado! Verifique se os registros já foram enviados!");
            }

            List<RetornoAmostraContasDTO> listaAmostraContas = (from c in consulta
                                                                select new RetornoAmostraContasDTO()
                                                                {
                                                                    Sistema = "EXT",
                                                                    Legado = "EXT",
                                                                    Agencia = c.CdAg.ToString(),
                                                                    Conta = c.IdNumCc.ToString(),
                                                                    DataReferencia = c.DtHGercAmst.ToString(),
                                                                    Template = "1",
                                                                    Segmento = "22",
                                                                    CodigoCliente = "4135305",
                                                                    CodigoTipoPessoa = "0007",
                                                                    UsuarioSolicitante = "AUTOMAT"
                                                                }).ToList();


            foreach(RetornoAmostraContasDTO amostra in listaAmostraContas)
            {
                publishOnQueue(amostra);
                saveOnSend(amostra, mesReferencia, tipo);
            }


            return;
        }

        private void saveOnSend(RetornoAmostraContasDTO mensagem, DateTime mesReferencia, int tipo)
        {

            // se o uso for na base dev externo mudar "t115.ID_OPC_EXTT" por "t115.ID_TP_REL"
            _databaseContext.Database.ExecuteSqlCommand(
                "update PRVT112_CE_PROM SET IC_ENV_MSG = 'S', DT_H_ENV_MSG = {0} "+
                "where CD_AG = {1} " +
                "and ID_NUM_CC = {2} " +
                "and IC_ENV_MSG = 'N' " +
                "and IC_AMST_EXTT_MENS != 'B' "+
                "and CD_AG in " +
                "(select t112.CD_AG from PRVT112_CE_PROM t112 " +
                "inner join PRVT063_DEMD_PROM t063 on t063.ID_TCKT = t112.ID_TCKT " +
                "inner join PRVT115_CLIENTE_EXTRATO t115 on t115.CD_AG = t112.CD_AG " +
                "where t063.id_flux = 4 " +
                "and t115.ID_NUM_CC = t112.ID_NUM_CC " +
                "and t115.ID_OPC_EXTT = {5}" +
                "and EXTRACT(MONTH FROM t063.DT_REF) = {3} and EXTRACT(YEAR FROM t063.DT_REF) = {4} )",
                DateTime.Now,
                mensagem.Agencia,
                mensagem.Conta,
                mesReferencia.Month,
                mesReferencia.Year,
                tipo
            );
            _databaseContext.SaveChanges();
        }

        private void publishOnQueue(RetornoAmostraContasDTO mensagem) 
        {
            var login = _configuration.GetValue<String>("QueueSettings:Login");
            var password = _configuration.GetValue<String>("QueueSettings:Password");
            var queueAdress = _configuration.GetValue<String>("QueueSettings:Address");
            var name = _configuration.GetValue<String>("QueueSettings:Name");

            Address address = new Address("amqp://"+login+":"+password+"@"+queueAdress);
            
            Connection connection = new Connection(address);

            Session session = new Session(connection);  
            SenderLink sender = new SenderLink(session, "send-1", name);

            
            Message message1 = new Message(mensagem);
            
            message1.Header = new Header();
            message1.Header.Durable = true;
            sender.Send(message1);

            
            sender.Close();
            session.Close();
            connection.Close();
        }

        public String receiveTOQueue()
        {

            var login = _configuration.GetValue<String>("QueueSettings:Login");
            var password = _configuration.GetValue<String>("QueueSettings:Password");
            var queueAdress = _configuration.GetValue<String>("QueueSettings:Address");
            var name = _configuration.GetValue<String>("QueueSettings:Name");

            Address address = new Address("amqp://"+login+":"+password+"@"+queueAdress);
            
            Connection connection = new Connection(address);

            Session session = new Session(connection); 

            ReceiverLink receiver = new ReceiverLink(session, "send-1", name);
            Message msg = receiver.Receive();
            receiver.Accept(msg);  
            String resultado = msg.Body.ToString();
            
            
            receiver.Close();
            session.Close();
            connection.Close();

            return resultado;
        }


    }
}
