using System;
using System.IdentityModel.Tokens.Jwt;
using MonitorAPI.Models;
using System.Linq;
using Microsoft.Extensions.Configuration;
using MonitorAPI.DTO;
using System.Collections.Generic;
using MonitorAPI.Oracle;
using System.Data;
using Dapper;
using Microsoft.EntityFrameworkCore;

namespace MonitorAPI.Services
{
    public class BackofficeService
    {
        private readonly DatabaseContext _context;
        private readonly HomeService _homeService;

        public BackofficeService(DatabaseContext context, HomeService homeService)
        {
            _context = context;
            _homeService = homeService;
        }

        /*
           (A)pproved
           (W)aiting 
           (P)arcial
           (R)eproved
        */

        public RelatorioBackofficeDTO ConsultaBackoffice(string mesReferencia, string tipo)
        {
            //var service = new HomeService(_context);
            var consulta = _homeService.ConsultaBase(mesReferencia);

            DescricaoProcessoDTO descCoe = new DescricaoProcessoDTO(tipo, "TSD");
            DescricaoProcessoDTO descPrevidencia = new DescricaoProcessoDTO(tipo, "RDF");
            DescricaoProcessoDTO descFundos = new DescricaoProcessoDTO(tipo, "FUNDOS");

            char backofficeprevidencia = (from c in consulta
                                          where c.TxtDescPro.Trim() == descPrevidencia.RelatorioValidacaoDados
                                          select (c.IdSitDemd == 'I' && c.IdSitEtap == 'P' ? 'W' : c.IdSitEtap == 'C' ? 'A' : 'R')
                                            ).FirstOrDefault();

            char backofficefundos = (from c in consulta
                                     where c.TxtDescPro.Trim() == descFundos.RelatorioValidacaoDados
                                     select (c.IdSitDemd == 'I' && c.IdSitEtap == 'P' ? 'W' : c.IdSitEtap == 'C' ? 'A' : 'R')
                                            ).FirstOrDefault();

            char backofficecoe = (from c in consulta
                                  where c.TxtDescPro.Trim() == descCoe.RelatorioValidacaoDados
                                  select (c.IdSitDemd == 'I' && c.IdSitEtap == 'P' ? 'W' : c.IdSitEtap == 'C' ? 'A' : 'R')
                                            ).FirstOrDefault();

            List<char> listaBackoffice = (from c in consulta
                                          where c.TxtDescPro.Trim() == descCoe.RelatorioValidacaoDados
                                          || c.TxtDescPro.Trim() == descFundos.RelatorioValidacaoDados
                                          || c.TxtDescPro.Trim() == descPrevidencia.RelatorioValidacaoDados
                                          select (c.IdSitDemd == 'I' && c.IdSitEtap == 'P' ? 'W' : c.IdSitEtap == 'C' ? 'A' : 'R')
                                        ).ToList();

            char backoffice = (listaBackoffice.Where(x => x == 'A').Count() == listaBackoffice.Count() ? 'A'
                     : listaBackoffice.Where(x => x == 'W').Count() == listaBackoffice.Count() ? 'W'
                     : listaBackoffice.Where(x => x == 'R').Count() == listaBackoffice.Count() ? 'R'
                     : 'P');

            RelatorioBackofficeDTO relatorioBack = new RelatorioBackofficeDTO
            {
                Backoffice = backoffice,
                Backofficecoe = backofficecoe,
                Backofficefundos = backofficefundos,
                Backofficeprevidencia = backofficeprevidencia
            };

            return relatorioBack;
        }
        public Prvt113EvtUsr ObterLog(string tipo)
        {
            //var prvt012Tipo = _context.Prvt012TipoLog.Where(x => x.CdTLg == valores.IdTipoLog).ToList().FirstOrDefault();
            //var user = _context.Users.Where(x => x.Id == valores.IdUser).ToList().FirstOrDefault();
            var user = 4546754;
            var prvt113EvtUsr = new Prvt113EvtUsr()
            {

                //IdUsr = 4546754,
                TxtDescAcao = String.Format("USUARIO: {0} APROVOU TOTALMENTE OS RELATORIO {1}", user, tipo),
                DtHAtc = DateTime.Now,
                CdTLg = 1

            };

            return prvt113EvtUsr;

        }

       
        public void ReprovarBackOfficeT112(string data)
        {
            DateTime mesReferencia = Convert.ToDateTime(data);

            _context.Database.ExecuteSqlCommand("update PRVT112_CE_PROM SET IC_EXTT_MENS = 'B' where CD_AG in " +
                                               "(select t112.CD_AG from PRVT112_CE_PROM t112" +
                                               " inner join PRVT063_DEMD_PROM t063 on t063.ID_TCKT = t112.ID_TCKT " +
                                               " inner join PRVT061_PRO_FLUX t061 on t061.ID_FLUX = t063.ID_FLUX " +
                                               " inner join PRVT062_ETAP_PRO t062 on t062.ID_PRO = t061.ID_PRO " +
                                               " inner join PRVT064_LG_PROM t064 on t064.ID_PROT = t063.ID_PROT " +
                                               " where t063.id_flux = 4 " +
                                               "   and t064.ID_ETAP = t062.ID_ETAP " +
                                               "   and EXTRACT(MONTH FROM t063.DT_REF) = {0} and EXTRACT(YEAR FROM t063.DT_REF) = {1} " +
                                               "   and t061.TXT_DESC_PRO = 'RELATORIO - DADOS DO RELATORIO')" +
                                               " and ID_NUM_CC in " +
                                               "(select t112.ID_NUM_CC from PRVT112_CE_PROM t112 " +
                                               " inner join PRVT063_DEMD_PROM t063 on t063.ID_TCKT = t112.ID_TCKT " +
                                               " inner join PRVT061_PRO_FLUX t061 on t061.ID_FLUX = t063.ID_FLUX " +
                                               " inner join PRVT062_ETAP_PRO t062 on t062.ID_PRO = t061.ID_PRO " +
                                               " inner join PRVT064_LG_PROM t064 on t064.ID_PROT = t063.ID_PROT " +
                                               " where t063.id_flux = 4 " +
                                               "   and t064.ID_ETAP = t062.ID_ETAP " +
                                               "   and EXTRACT(MONTH FROM t063.DT_REF) = {0} and EXTRACT(YEAR FROM t063.DT_REF) = {1} " +
                                               "   and t061.TXT_DESC_PRO = 'RELATORIO - DADOS DO RELATORIO')" +
                                               " and AM_REF in " +
                                               "(select t112.AM_REF from PRVT112_CE_PROM t112 " +
                                               " inner join PRVT063_DEMD_PROM t063 on t063.ID_TCKT = t112.ID_TCKT " +
                                               " inner join PRVT061_PRO_FLUX t061 on t061.ID_FLUX = t063.ID_FLUX " +
                                               " inner join PRVT062_ETAP_PRO t062 on t062.ID_PRO = t061.ID_PRO " +
                                               " inner join PRVT064_LG_PROM t064 on t064.ID_PROT = t063.ID_PROT " +
                                               " where t063.id_flux = 4 " +
                                               "   and t064.ID_ETAP = t062.ID_ETAP " +
                                               "   and EXTRACT(MONTH FROM t063.DT_REF) = {0} and EXTRACT(YEAR FROM t063.DT_REF) = {1} " +
                                               "   and t061.TXT_DESC_PRO = 'RELATORIO - DADOS DO RELATORIO');", mesReferencia.Month, mesReferencia.Year);

            /*foreach (var item in consulta)
            {
                item.IcExttMens = 'B';
                _context.Update(item);
            }*/

            _context.SaveChanges();

            return;
        }
         public bool auth(string role)
        {

            if (role == "TI" || role == "FUNDOS_PREV_2" || role == " RDF_COE_2" || role == " CORRETORA_TESOURO_2")
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
