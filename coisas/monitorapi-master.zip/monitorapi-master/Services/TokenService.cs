using System;
using System.IdentityModel.Tokens.Jwt;
using MonitorAPI.Models;
using System.Linq;
using Microsoft.Extensions.Configuration;
using System.Threading.Tasks;
using System.Collections.Generic;
using MonitorAPI.DTO;

namespace MonitorAPI.Services
{
    public class TokenService
    {
        private readonly DatabaseContext _context;
        private readonly IConfiguration _configuration;

        public TokenService(DatabaseContext context, IConfiguration configuration)
        {
            _context = context;
            _configuration = configuration;
        }

        // public async Task<IEnumerable<UserDTO>> InspectToken(string bearerToken)
        // {
        //     JwtSecurityTokenHandler handler = new JwtSecurityTokenHandler();
        //     UserRepository repo = new UserRepository(_context, _configuration);
        //     UserDTO dadosUsuario = new UserDTO();
        //     string token = string.Empty;

        //     if (!string.IsNullOrEmpty(bearerToken))
        //     {
        //         if (bearerToken.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase))
        //             token = bearerToken.Substring("Bearer ".Length).Trim();
        //         else
        //             return null;

        //         if (!string.IsNullOrEmpty(token))
        //         {
        //             var tokenDescprit = handler.ReadJwtToken(token);

        //             foreach (var item in tokenDescprit.Payload)
        //             {
        //                 switch (item.Key)
        //                 {
        //                     case "login":
        //                         dadosUsuario.Login = item.Value.ToString();
        //                         break;
        //                     case "grupo":
        //                         dadosUsuario.Grupo = item.Value.ToString();
        //                         break;
        //                 }
        //             }

        //             var user = await repo.GetUserByNameAndGroup(dadosUsuario);

        //             if (user.Count() > 0)
        //                 return user;
        //             else
        //                 return null;
        //         }
        //         else
        //             return null;
        //     }
        //     else
        //         return null;
        // }
    }
}