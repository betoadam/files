using System;
using System.IdentityModel.Tokens.Jwt;
using MonitorAPI.Models;
using System.Linq;
using Microsoft.Extensions.Configuration;
using MonitorAPI.DTO;
using System.Collections.Generic;
using MonitorAPI.Oracle;
using System.Data;
using Dapper;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;
using System.Net.Http;

namespace MonitorAPI.Services
{
    public class MarketingService
    {
        private readonly DatabaseContext _context;

        public MarketingService(DatabaseContext context)
        {
            _context = context;
        }

        public Prvt113EvtUsr ObterLog(string tipo)
        {
            //var prvt012Tipo = _context.Prvt012TipoLog.Where(x => x.CdTLg == valores.IdTipoLog).ToList().FirstOrDefault();
            //var user = _context.Users.Where(x => x.Id == valores.IdUser).ToList().FirstOrDefault();
            var user = 4546754;
            var prvt113EvtUsr = new Prvt113EvtUsr()
            {

                //IdUsr = 4546754,
                TxtDescAcao = String.Format("USUARIO: {0} APROVOU TOTALMENTE OS RELATORIO {1} as {2}", user, tipo, DateTime.Now),
                DtHAtc = DateTime.Now,
                CdTLg = 1

            };

            return prvt113EvtUsr;

        }

        /*
           (A)pproved
           (W)aiting 
           (P)arcial
           (R)eproved
        */

        public async Task<string> CriarArquivoImg(string apiStorage)
        {
            var baseUrl = new Uri(apiStorage);

            HttpClient client = new HttpClient { Timeout = TimeSpan.FromSeconds(30) };

            client.DefaultRequestHeaders.Add("Authorization", "Basic dXNy122ltZhYaAdFdA6213nhlVDk=");
            client.DefaultRequestHeaders.Add("amc-aplicacao", "ACD");
            client.DefaultRequestHeaders.Add("amc-message-id", "25896");
            client.DefaultRequestHeaders.Add("amc-session-id", "22588");
            client.DefaultRequestHeaders.Add("Accept-language", "pt-BR");

            MultipartFormDataContent form = new MultipartFormDataContent();

            byte[] file_bytes = new byte[55];

            form.Add(new StringContent("nao sei"), "object ");
            form.Add(new StringContent("pdf"), "type");
            form.Add(new ByteArrayContent(file_bytes, 0, file_bytes.Length), "binary", "helloWorld.pdf");

            HttpResponseMessage response = await client.PostAsync(baseUrl, form);

            var responseString = await response.Content.ReadAsStringAsync();

            return responseString;
        }

         public bool auth(string role)
        {

            if (role == "MARKETING_2" || role == "TI")
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
