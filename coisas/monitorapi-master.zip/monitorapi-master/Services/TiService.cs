using System;
using System.IdentityModel.Tokens.Jwt;
using MonitorAPI.Models;
using System.Linq;
using Microsoft.Extensions.Configuration;
using MonitorAPI.DTO;
using System.Collections.Generic;
using MonitorAPI.Oracle;
using System.Data;
using Dapper;
using Microsoft.EntityFrameworkCore;

namespace MonitorAPI.Services
{
    public class TiService
    {
        private readonly DatabaseContext _context;
        private readonly HomeService _homeService;

        public TiService(DatabaseContext context, HomeService homeService)
        {
            _context = context;
            _homeService = homeService;
        }

        /*
           (A)pproved
           (W)aiting 
           (P)arcial
           (R)eproved
        */

        public List<StatusDescricaoDTO> ListaTi(string mesReferencia)
        {
           //var service = new HomeService(_context);
            var consulta = _homeService.ConsultaBase(mesReferencia);

            DescricaoProcessoDTO desc = new DescricaoProcessoDTO("", "");

            List<StatusDescricaoDTO> listaTi = (from c in consulta
                                                where c.TxtDescPro.Trim() == desc.IntegraSaldoContaCorrente
                                                || c.TxtDescPro.Trim() == desc.IntegraMovimentoContaCorrente
                                                || c.TxtDescPro.Trim() == desc.IntegraRelacionamentoCliente
                                                || c.TxtDescPro.Trim() == desc.IntegraListaCliente
                                                || c.TxtDescPro.Trim() == desc.IntegraSaldoPoupanca
                                                || c.TxtDescPro.Trim() == desc.IntegraMovimentoPoupanca
                                                || c.TxtDescPro.Trim() == desc.IntegraSuitability
                                                || c.TxtDescPro.Trim() == desc.RelatorioDados
                                                select new StatusDescricaoDTO()
                                                {
                                                    Status = (c.IdSitDemd == 'I' && c.IdSitEtap == 'P' ? 'W' : c.IdSitEtap == 'C' ? 'A' : 'R'),
                                                    Descricao = c.TxtDescPro
                                                }).ToList();

            return listaTi;
        }

        public List<Prvt112CeProm> EnviarFila (string data, string tipo)
        {
            DateTime mesReferencia = Convert.ToDateTime(data);

            //verificar FK t112 ~ t115
            var consulta = (from t112 in _context.Prvt112CeProm
                            join t063 in _context.Prvt063DemdProm on t112.IdTckt equals t063.IdTckt
                            join t115 in _context.Prvt115ClienteExtrato on t112.CdAg equals t115.CdAg
                            where t063.IdFlux == 4
                            && t112.IcExttMens == null
                            && t063.DtRef.Month == mesReferencia.Month
                            && t063.DtRef.Year == mesReferencia.Year
                            && t115.IdNumCc == t112.IdNumCc
                            select t112).ToList();

            if (consulta == null)
            {
                throw new Exception("Nenhum registro foi encontrado! Verifique o m�s de referencia!");
            }

            foreach (var item in consulta)
            {
                item.IcExttMens = 'E';
                _context.Set<Prvt112CeProm>().Attach(item);
                _context.Entry(item).Property(x => x.IcExttMens).IsModified = true;
            }

            _context.SaveChanges();

            try
            {
                foreach (var item in consulta)
                {
                    item.IcExttMens = 'C';
                    _context.Set<Prvt112CeProm>().Attach(item);
                    _context.Entry(item).Property(x => x.IcExttMens).IsModified = true;
                }
            }
            catch
            {
                foreach (var item in consulta)
                {
                    item.IcExttMens = 'F';
                    _context.Set<Prvt112CeProm>().Attach(item);
                    _context.Entry(item).Property(x => x.IcExttMens).IsModified = true;
                }
            }

            _context.SaveChanges();

            var descProc = new DescricaoProcessoDTO(tipo, "");
            //HomeService homeService = new HomeService(_context);
            var updateRelatorio = _homeService.ObterT064(data, descProc.RelatorioGerarPdf);

            updateRelatorio.IdSitEtap = 'C';

            _context.Update(updateRelatorio);
            _context.SaveChanges();

            return consulta;
        }
        public bool auth(string role)
        {

            if (role == "TI")
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
