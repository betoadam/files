using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using MonitorAPI.Models;
using MonitorAPI.Services;
using MonitorAPI.DTO;
using Microsoft.AspNetCore.Hosting;
using System.IO;
namespace MonitorAPI.Controllers
{
    [ApiController]
    public class BackofficeController : ControllerBase
    {
        private readonly DatabaseContext _context;
        private readonly IConfiguration _configuration;
        private readonly BackofficeService _backofficeService;
        private readonly HomeService _homeService;

        public BackofficeController(DatabaseContext context, IConfiguration configuration, BackofficeService backofficeService, HomeService homeService)
        {
            _context = context;
            _configuration = configuration;
            _backofficeService = backofficeService;
            _homeService = homeService;
        }

        /// <summary>
        ///     BACK OFFICE STATUS
        /// </summary>
        /// <remarks>
        ///     Sample request:
        ///
        ///     GET /backoffice
        ///     {
        ///         "data": 03/2020,
        ///         "tipo": "PRIVATE",
        ///     }
        /// </remarks>
        //tipo = Private/Safrainvest/Outros
        [Route("backoffice")]
        [HttpGet]
        public ActionResult<RelatorioBackofficeDTO> GetPrivateBackoffice(string data, string tipo)
        {
            // var service = new BackofficeService(_context);
            
                try
                {
                    tipo = tipo.ToUpper();
                    RelatorioBackofficeDTO retorno = _backofficeService.ConsultaBackoffice(data, tipo);
                    return retorno;
                }
                catch (Exception ex)
                {
                    return BadRequest(ex);
                }
            
        }
        /// <summary>
        ///     VALIDAÇÃO DE DADOS APROVAR
        /// </summary>
        /// <remarks>
        ///     Sample request:
        ///
        ///     PUT /backoffice/aprovar
        ///     {
        ///         "data": 03/2020,
        ///         "tipo": "PRIVATE",
        ///         "operacao: "fUNDOS",
        ///         "role": "TI"
        ///     }
        /// </remarks>
        //tipo = Private/Safrainvest/Outros
        //operacao = RDF/TSD/FUNDOS
        [Route("backoffice/aprovar")]
        [HttpPut]

        public ActionResult<RelatorioBackofficeDTO> PutBackofficeAprova([FromBody]JsonDTO obs, string data, string tipo, string operacao, string role)
        {
            role = role.ToUpper();
            var auth = _backofficeService.auth(role);

            if (auth)
            {
                try
                {
                    tipo = tipo.ToUpper();
                    operacao = operacao.ToUpper();
                    //operacao = (operacao == "RDF" ? "RDF" : operacao);

                    DescricaoProcessoDTO descProc = new DescricaoProcessoDTO(tipo, operacao);

                    //var homeService = new HomeService(_context);
                    //var backofficeService = new BackofficeService(_context);

                    var validacao = _homeService.ObterT064(data, descProc.RelatorioDados);

                    if (validacao.IdSitEtap != 'C')
                    {
                        return Ok(new { Message = "Etapa dados processados nao concluida!" });
                    }

                    var consulta = _homeService.ObterT064(data, descProc.RelatorioValidacaoDados);

                    consulta.IdSitEtap = 'C';
                    consulta.TxtObs = obs.Obs;

                    _context.Update(consulta);
                    var prvt113 = _backofficeService.ObterLog(tipo);
                    prvt113.TxtDescFlux = "APROVACAO TOTAL BACKOFFICE" + operacao;
                    _context.Add(prvt113);
                    _context.SaveChanges();

                    RelatorioBackofficeDTO retorno = _backofficeService.ConsultaBackoffice(data, tipo);

                    return retorno;
                }
                catch (Exception ex)
                {
                    return BadRequest(ex);
                }
            }
        
            return BadRequest(new {Message="Usuário não autorizado"});
        }

        /// <summary>
        ///     VALIDAÇÃO DE DADOS REPROVAR
        /// </summary>
        /// <remarks>
        ///     Sample request:
        ///
        ///     PUT /backoffice/reprovar
        ///     {
        ///         "data": 03/2020,
        ///         "tipo": "PRIVATE",
        ///         "operacao: "fUNDOS",
        ///         "role": "TI"
        ///     }
        /// </remarks>
        //tipo = Private/Safrainvest/Outros
        //operacao = Previdencia/Coe/Fundos
        [Route("backoffice/reprovar")]
        [HttpPut]
        public ActionResult PutBackofficeReprova([FromBody]JsonDTO obs, string data, string tipo, string operacao, string role)
        {
            role = role.ToUpper();
            var auth = _backofficeService.auth(role);

            if (auth)
            {
                try
                {
                    tipo = tipo.ToUpper();
                    operacao = operacao.ToUpper();
                    //operacao = (operacao == "RDF" ? "RDF" : operacao);

                    //var homeService = new HomeService(_context);
                    //var backofficeService = new BackofficeService(_context);


                DescricaoProcessoDTO descProc = new DescricaoProcessoDTO(tipo, operacao);
                

                var validacao = _homeService.ObterT064(data, descProc.RelatorioDados);
                if (validacao.IdSitEtap != 'C' )
                {
                    return Ok(new { Message = "Etapa dados processados nao concluida!" });
                }

                var consulta = _homeService.ObterT064(data, descProc.RelatorioValidacaoDados);
                if (consulta.IdSitEtap == 'R' )
                {
                    return Ok(new { Message = "Etapa já reprovada!" });
                }
                consulta.IdSitEtap = 'R';
                consulta.TxtObs = obs.Obs;
                _context.Update(consulta);

                    _backofficeService.ReprovarBackOfficeT112(data);
                    var prvt113 = _backofficeService.ObterLog(tipo);
                    prvt113.TxtDescFlux = "REPROVACAO TOTAL BACKOFFICE";
                    _context.Add(prvt113);

                    _context.SaveChanges();
                    return Ok(new {Message="Imagem(s) Atualizada(s)!"});
                }
                catch (Exception ex)
                {
                    return BadRequest(ex);
                }
                 }
 
            return BadRequest(new {Message="Usuário não autorizado"});
        }
    }
}


