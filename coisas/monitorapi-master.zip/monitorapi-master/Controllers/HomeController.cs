using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using MonitorAPI.Models;
using MonitorAPI.Services;
using MonitorAPI.DTO;


namespace MonitorAPI.Controllers
{
    [ApiController]
    public class HomeController : ControllerBase
    {
        private readonly DatabaseContext _context;
        private readonly IConfiguration _configuration;
        private readonly HomeService _homeService;
        public HomeController(DatabaseContext context, IConfiguration configuration, HomeService homeService)
        {
            _context = context;
            _configuration = configuration;
            _homeService = homeService;
        }
        /// <summary>
        ///     STATUS DAS APROVAÇÕES
        /// </summary>
        /// <remarks>
        ///     Sample request:
        ///
        ///     GET /home
        ///     {
        ///         "data": 03/2020
        ///     }
        /// </remarks>
        [Route("home")]
        [HttpGet]
        public ActionResult<RelatorioStatusRetornoDTO> GetHome(string data)
        {
            try
            {
                var retorno = new RelatorioStatusRetornoDTO();
                //var service = new HomeService(_context);

                var consultaBase = _homeService.ConsultaBase(data);

                retorno.Outros = _homeService.HomeStatus(data, "OUTROS", consultaBase);
                retorno.Private = _homeService.HomeStatus(data, "PRIVATE", consultaBase); ;
                retorno.Safrainvest = _homeService.HomeStatus(data, "SAFRAINVEST", consultaBase);

                return retorno;//_context.Users.ToListAsync();
            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }
        /// <summary>
        ///     HOME
        /// </summary>
        /// <remarks>
        ///     Sample request:
        ///
        ///     GET /download/amostra113
        /// </remarks>
        [Route("download/amostra113")]
        [HttpGet]
        public ActionResult<List<Prvt113EvtUsr>> GetPrvt113()
        {
            try
            {
                var retorno = new List<Prvt113EvtUsr>();
               // var _homeService = new Home_homeService(_context);

                retorno = _homeService.ObterListaT113();

                return retorno;
            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }

        // [Route("auth")]
        // [HttpGet]
        // public async Task<IActionResult> Home()
        // {

        //     //Pegar o Token que foi enviado na requisi��o
        //     string authorization = Request.Headers["Authorization"].FirstOrDefault();

        //     //Instancia do servico para checar o conteudo do Token
        //     TokenService tokenService = new TokenService(_context, _configuration);

        //     //Metodo para validar o usuario dentro do token
        //     var userCheck = await tokenService.InspectToken(authorization);

        //     if (userCheck != null && userCheck.Count() > 0)
        //         return Ok(userCheck);
        //     else
        //         return Unauthorized();
        // }
        
    }
}
