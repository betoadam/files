using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using MonitorAPI.Models;
using MonitorAPI.Services;
using MonitorAPI.DTO;
using System.Net;
using System.Text;
using System.Net.Http;
using System.IO;

namespace MonitorAPI.Controllers
{
    [ApiController]
    public class MarketingController : ControllerBase
    {
        private readonly DatabaseContext _context;
        private readonly IConfiguration _configuration;
        private readonly MarketingService _marketingService;
        private readonly HomeService _homeService;

        public MarketingController(DatabaseContext context, IConfiguration configuration, MarketingService marketingService, HomeService homeService)
        {
            _context = context;
            _configuration = configuration;
            _marketingService = marketingService;
            _homeService = homeService;
        }

        /// <summary>
        ///     ARQUIVO LÂMINA
        /// </summary>
        /// <remarks>
        ///     Sample request:
        ///
        ///     PUT /lamina
        ///     {
        ///         "data": 03/2020,
        ///         "tipo": "PRIVATE",
        ///         "role": "TI"
        ///     }
        /// </remarks>
        [Route("lamina")]
        [HttpPut]
        public ActionResult PutLamina(string data, string tipo, string role)
        {
            role = role.ToUpper();
            var auth = _marketingService.auth(role);

            if (auth)
            {
                try
                {
                    tipo = tipo.ToUpper();
                    //var service = new HomeService(_context);

                    var descProc = new DescricaoProcessoDTO(tipo, "");

                    var validacao = _homeService.ObterT064(data, descProc.IntegraLaminaFundos);

                    if (validacao.IdSitEtap != 'P')
                    {
                        return Ok(new { Message = "Etapa Lamina de fundos ja concluida!" });
                        
                    }

                    var consulta = _homeService.ObterT064(data, descProc.IntegraLaminaFundos);
                    consulta.IdSitEtap = 'C';
                    _context.Update(consulta);
                    _context.SaveChanges();

                    return Ok(new {Message="Sucesso na inclusao!"});
                }
                catch (Exception ex)
                {
                    return BadRequest(ex);
                }
            }

            return BadRequest(new {Message="Usuário não autorizado"});
        }

        /// <summary>
        ///     ENVIO DE IMAGEM PARA STORAGE
        /// </summary>
        /// <remarks>
        ///     Sample request:
        ///
        ///     PUT /upload/imagem
        ///     {
        ///         "data": 03/2020,
        ///         "tipo": "PRIVATE",
        ///         "role": "TI"
        ///     }
        /// </remarks>
        //tipo = Private/Safrainvest/Outros
        [Route("upload/imagem")]
        [HttpPut]
        public ActionResult PutUploadImagem(string data, string tipo, string role)
        {
            role = role.ToUpper();
            var auth = _marketingService.auth(role);

            if (auth)
            {
                try
                {
                    tipo = tipo.ToUpper();
                    // var service = new HomeService(_context);

                    var descProc = new DescricaoProcessoDTO(tipo, "");

                    var validacao = _homeService.ObterT064(data, descProc.RelatorioDados);

                    if (validacao.IdSitEtap != 'C')
                    {
                        return Ok(new { Message = "Etapa dados processados nao concluida!" });

                    }

                    validacao = _homeService.ObterT064(data, descProc.IntegraLaminaFundos);

                    if (validacao.IdSitEtap != 'C')
                    {
                       return Ok(new { Message = "Etapa Lamina nao concluida!" });
                        
                    }

                    validacao = _homeService.ObterT064(data, descProc.RelatorioUploadImagensCE);

                    if (validacao.IdSitEtap != 'P')
                    {
                        return Ok(new { Message = "Imagem CE nao enviada!" });
                    }
                    validacao = _homeService.ObterT064(data, descProc.RelatorioUploadImagensIS);

                    if (validacao.IdSitEtap != 'P')
                    {
                        return Ok(new { Message = "Imagem IS nao enviada!" });
                    }
                    validacao = _homeService.ObterT064(data, descProc.RelatorioUploadImagensRF);

                    if (validacao.IdSitEtap != 'P')
                    {
                        return Ok(new { Message = "Imagem RF nao enviada!"});
                    }

                    List<string> listaTipo = new List<string>
                    {
                        descProc.RelatorioUploadImagensCE,
                        descProc.RelatorioUploadImagensIS,
                        descProc.RelatorioUploadImagensRF
                    };

                    var consulta = _homeService.ObterListaT064(data, listaTipo);

                    foreach (var item in consulta)
                    {
                        item.IdSitEtap = 'C';
                        _context.Set<Prvt064LgProm>().Attach(item);
                        _context.Entry(item).Property(x => x.IdSitEtap).IsModified = true;
                    }

                    var prvt113 = _marketingService.ObterLog(tipo);
                    prvt113.TxtDescFlux = "APROVACAO TOTAL MARKETING";
                    _context.Add(prvt113);

                    _context.SaveChanges();


                    var teste = _marketingService.CriarArquivoImg(_configuration.GetValue<string>("ApiStorage") + "/img/criar_arquivo");

                    return Ok(new {Message="Sucesso no upload!"});
                }
                catch (Exception ex)
                {
                    return BadRequest(ex);
                }
            }

            return BadRequest(new {Message="Usuário não autorizado"});
        }

        /// <summary>
        ///     VALIDAÇÃO DE AMOSTRAS E RELATÓRIOS / APROVAR MK3
        /// </summary>
        /// <remarks>
        ///     Sample request:
        ///
        ///     PUT /validacao/aprovar/marketing
        ///     {
        ///         "data": 03/2020,
        ///         "tipo": "PRIVATE",
        ///         "role": "TI"
        ///     }
        /// </remarks>
        //tipo = Private/Safrainvest/Outros
        [Route("validacao/aprovar/marketing")]
        [HttpPut]
        public ActionResult PutValidacaoAprovarMarketing([FromBody]JsonDTO obs, string data, string tipo, string role)
        {
            role = role.ToUpper();
            var auth = _marketingService.auth(role);

            if (auth)
            {
                try
                {
                    tipo = tipo.ToUpper();
                    //var service = new HomeService(_context);
                    var descProc = new DescricaoProcessoDTO(tipo, "");

                    var validacao = _homeService.ObterT064(data, descProc.RelatorioGerarAmostra);

                    if (validacao.IdSitEtap != 'C')
                    {
                        return Ok(new { Message = "Etapa Geraçãoo de Amostra não concluída!" });
                    }

                    var consulta = _homeService.ObterT064(data, descProc.RelatorioValidaAmostraMKT);

                    consulta.IdSitEtap = 'C';
                    consulta.TxtObs = obs.Obs;

                    var prvt113 = _marketingService.ObterLog(tipo);
                    prvt113.TxtDescFlux = "APROVACAO TOTAL MARKETING";
                    _context.Add(prvt113);
                    _context.Update(consulta);
                    _context.SaveChanges();

                    return Ok(new {Message="Sucesso no upload!"});
                    
                }
                catch (Exception ex)
                {
                    return BadRequest(ex);
                }
            }


            return BadRequest(new {Message="Usuário não autorizado"});
        }

        /// <summary>
        ///     VALIDAÇÃO DE AMOSTRAS E RELATÓRIOS / REPROVAR MK3
        /// </summary>
        /// <remarks>
        ///     Sample request:
        ///
        ///     PUT /validacao/reprovar/marketing
        ///     {
        ///         "data": 03/2020,
        ///         "tipo": "PRIVATE",
        ///         "step" : "upload imagem"
        ///         "role": "TI"
        ///     }
        /// </remarks>
        //tipo = Private/Safrainvest/Outros
        //step = "upload imagem" / "arquivo lamina"
        [Route("validacao/reprovar/marketing")]
        [HttpPut]
        public ActionResult PutValidacaoReprovarMarketing([FromBody]JsonDTO obs, string data, string tipo, string step, string role)
        {
            role = role.ToUpper();
            var auth = _marketingService.auth(role);

            if (auth)
            {
                try
                {
                    tipo = tipo.ToUpper();
                    step = step.ToUpper();
                    //var service = new HomeService(_context);

                    var descProc = new DescricaoProcessoDTO(tipo, "");
                    var descCoe = new DescricaoProcessoDTO(tipo, "TSD");
                    var descFundos = new DescricaoProcessoDTO(tipo, "FUNDOS");
                    var descPrevidencia = new DescricaoProcessoDTO(tipo, "RDF");

                    var validacao = _homeService.ObterT064(data, descProc.RelatorioGerarAmostra);

                    if (validacao.IdSitEtap != 'C')
                    {
                        return Ok(new { Message = "Etapa Geraçãoo de Amostra não concluída!" });
                    }

                    List<string> listaTipo = new List<string> 
                    {
                        descProc.RelatorioGerarAmostra,
                        descProc.RelatorioValidaAmostraPF,
                        descProc.RelatorioValidaAmostraMKT
                    };

                    if (step == "GERACAOAMOSTRA")
                    {
                        listaTipo.Add(descProc.RelatorioGerarAmostra);
                    }

                    if (step == "UPLOADIMAGEM")
                    {
                        
                        listaTipo.Add(descProc.RelatorioUploadImagensIS);
                        listaTipo.Add(descProc.RelatorioUploadImagensRF);
                        listaTipo.Add(descProc.RelatorioUploadImagensCE);

                    }

                    if (step == "ARQUIVOLAMINA")
                    {
                       
                        listaTipo.Add(descProc.RelatorioUploadImagensIS);
                        listaTipo.Add(descProc.RelatorioUploadImagensRF);
                        listaTipo.Add(descProc.RelatorioUploadImagensCE);
                        listaTipo.Add(descProc.IntegraLaminaFundos);
                      
                    }

                   

                    var consulta = _homeService.ObterListaT064(data, listaTipo);

                    foreach (var item in consulta)
                    {
                        item.IdSitEtap = 'P';
                        _context.Set<Prvt064LgProm>().Attach(item);
                        _context.Entry(item).Property(x => x.IdSitEtap).IsModified = true;
                    }
                    validacao.TxtObs = obs.Obs;
                    _context.Update(validacao);
                    var prvt113 = _marketingService.ObterLog(tipo);
                    prvt113.TxtDescFlux = "REPROVACAO TOTAL MARKETING";
                    _context.Add(prvt113);
                    _context.SaveChanges();

                    return Ok(new { Message = "Sucesso na reprovacao marketing" });
                }
                catch (Exception ex)
                {
                    return BadRequest(ex);
                }
            }
            return BadRequest(new {Message="Usuário não autorizado"});
        }


        /// <summary>
        ///     UPLOAD IMAGEM / ENVIAR IMAGENS
        /// </summary>
        /// <remarks>
        ///     Sample request:
        ///
        ///     POST /marketing/img
        ///     {
        ///         "data": 03/2020,
        ///         "tipo": "PRIVATE",
        ///         "role": "TI",
        ///         "Files": "imagem1.png",
        ///         "Files": "imagem2.png",
        ///         "Files": "imagem3.png"
        ///     }
        /// </remarks>
        [Route("marketing/img")]
        [HttpPost]

        public ActionResult PostImg([FromForm]FileDTO objFile, string data, string tipo, string role, string setorImagem)
        {
            role = role.ToUpper();
            var auth = _marketingService.auth(role);
            if (auth)
            {
                try
                {
                    var folder = _configuration.GetValue<string>("DefaultConnection:Folder");
                    try
                    {
                        if (!Directory.Exists(folder))
                        {
                            Directory.CreateDirectory(folder);
                        }
                    }
                    catch (System.Exception ex)
                    {
                        return BadRequest(ex);
                    }
                    string nomeImagem = objFile.Files.FileName;
                    bool aprovacaoImagem = false;
                    var tipoArquivo = nomeImagem.Split('.');
                    nomeImagem = setorImagem;
                    tipo = tipo.ToUpper();

                    var descProc = new DescricaoProcessoDTO(tipo, "");

                    var validacao = _homeService.ObterT064(data, descProc.IntegraLaminaFundos);
                    nomeImagem = tipo + "_" + nomeImagem + "_" + data.Replace("/", "-") + "." + tipoArquivo[1];


                    if (tipoArquivo[1] == "pdf" || tipoArquivo[1] == "png" ||
                        tipoArquivo[1] == "jpeg" || tipoArquivo[1] == "jpg")
                    {
                        aprovacaoImagem = true;
                    }
                    else
                    {
                        return Ok(new { Message = "As imagem devem que estar nos formatos PDF, PNG, JPEG ou JPG" });
                    }

                    if (System.IO.File.Exists(folder + nomeImagem))
                    {
                        DateTime date = DateTime.Now;
                        string data1 = date.ToString("dd-MM-yyyy_hh:mm:ss");
                        System.IO.File.Move(folder + nomeImagem, folder + nomeImagem + "_" + data1 + "." + tipoArquivo[1]);
                    }

                    if (validacao.IdSitEtap != 'C')
                    {
                        return Ok(new { Message = "Etapa dados processados não concluída!" });
                    }

                    if (aprovacaoImagem == true)
                    {

                        using (FileStream fileStream = System.IO.File.Create(folder + nomeImagem))
                        {
                            objFile.Files.CopyTo(fileStream);
                            fileStream.Flush();

                        }
                        switch (setorImagem)
                        {
                            case "CENARIO_ECONOMICO":
                                validacao = _homeService.ObterT064(data, descProc.RelatorioUploadImagensCE);
                                validacao.IdSitEtap = 'C';
                                _context.Update(validacao);
                                _context.SaveChanges();
                                break;

                            case "INFORME_SAFRA":
                                validacao = _homeService.ObterT064(data, descProc.RelatorioUploadImagensIS);
                                validacao.IdSitEtap = 'C';
                                _context.Update(validacao);
                                _context.SaveChanges();
                                break;
                            case "RENTABILIDADE_FUNDOS":
                                validacao = _homeService.ObterT064(data, descProc.RelatorioUploadImagensRF);
                                validacao.IdSitEtap = 'C';
                                _context.Update(validacao);
                                _context.SaveChanges();
                                break;
                        }

                    }
                    else
                    {
                        return Ok(new { Message = "Imagem não aprovada!" });
                    }
                    var prvt113 = _marketingService.ObterLog(tipo);
                    prvt113.TxtDescFlux = "APROVACAO TOTAL MARKETING UPLOAD IMAGEM";
                    _context.Add(prvt113);
                    _context.SaveChanges();
                    return Ok(new {Message="Imagem(s) Atualizada(s)!"});

                }
                catch (Exception ex)
                {
                    return BadRequest(ex);
                }
            }

            return BadRequest(new {Message="Usuário não autorizado"});
        }

        /// <summary>
        ///    UPLOAD IMAGEM / PEGAR IMAGENS ENVIADAS
        /// </summary>
        /// <remarks>
        ///         Sample request:
        ///
        ///     GET /marketing/imagens
        ///     {
        ///         "data": 03/2020,
        ///         "tipo": "PRIVATE",
        ///         "role": "TI"
        ///     }
        /// </remarks>
        [Route("marketing/imagens")]
        [HttpGet]
        public ActionResult<string[]> GetImg(string data, string tipo, string role)
        {
            role = role.ToUpper();
            var auth = _marketingService.auth(role);

            if (auth)
            {
                try
                {
                    var folder = _configuration.GetValue<string>("DefaultConnection:Folder");
                    string[] lisImagens = new string[3] { "CENARIO_ECONOMICO", "INFORME_SAFRA", "RENTABILIDADE_FUNDOS" };
                    string[] tipoArquivo = new string[4] { "pdf", "png", "jpeg", "jpg" };
                    string[] lisimagem = new string[3];
                    for (int i = 0; i < lisImagens.Length; i++)
                    {
                        foreach (string extencao in tipoArquivo)
                        {
                            var nomeImagem = tipo.ToUpper() + "_" + lisImagens[i] + "_" + data.Replace("/", "-") + "." + extencao;
                            if (System.IO.File.Exists(folder + nomeImagem))
                            {

                                lisimagem[i] = nomeImagem;
        
                            }
                        }
                    }
                    return lisimagem;
                }
                catch (Exception ex)
                {
                    return BadRequest(ex);
                }
            }

            return BadRequest(new {Message="Usuário não autorizado"});

        }

        /// <summary>
        ///    VALIDAÇÃO DE AMOSTRAS E RELATÓRIOS / VOLTAR FLUXO MK3
        /// </summary>
        /// <remarks>
        ///     Sample request:
        ///
        ///     PUT /marketing/revisaoAprovacao
        ///     {
        ///         "data": 03/2020,
        ///         "tipo": "PRIVATE",
        ///         "step": "ARQUIVO LAMINA",
        ///         "role": "TI"
        ///     }
        /// </remarks>
        [Route("marketing/revisaoAprovacao")]
        [HttpPut]
        public ActionResult PutRevisaoAprovacaoMarketing(string data, string tipo, string step, string role)
        {
            role = role.ToUpper();
            var auth = _marketingService.auth(role);

            if (auth)
            {
                try
                {
                    if (step == "GERAR AMOSTRAS")
                    {
                        _homeService.GerarAmostra(data, tipo);
                    }
                    else if (step == "UPLOAD IMAGEM")
                    {
                        _homeService.GerarAmostra(data, tipo);
                        _homeService.UploadImagens(data, tipo);
                    }
                    else if (step == "ARQUIVO LAMINA")
                    {
                        _homeService.GerarAmostra(data, tipo);
                        _homeService.UploadImagens(data, tipo);
                        _homeService.ArquivoLamina(data, tipo);
                    }
                    return Ok(new {Message="Sucesso"});
                }
                catch (Exception ex)
                {
                    return BadRequest(ex);
                }
            }

            return BadRequest(new {Message="Usuário não autorizado"});

        }
    }
}
