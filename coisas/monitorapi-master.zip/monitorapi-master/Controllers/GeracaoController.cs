﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MonitorAPI.Models;
using MonitorAPI.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MonitorAPI.DTO;

namespace MonitorAPI.Controllers
{
    public class GeracaoController : ControllerBase
    {
        private readonly DatabaseContext _context;
        private readonly Prvt116ChvCript _prvt116ChvCript;
        private readonly GeracaoService _geracaoService;

        public GeracaoController(DatabaseContext context, Prvt116ChvCript prvt116ChvCript, GeracaoService geracaoService)
        {
            _context = context;
            _prvt116ChvCript = prvt116ChvCript;
            _geracaoService = geracaoService;
        }
        /// <summary>
        ///  SALVAR LOG NA PRVT116
        /// </summary>
        /// <remarks>
        ///     Sample request:
        ///
        ///     PUT geracao/salvarLog
        ///     {
        ///         "cdAg": 1234,
        ///         "numCc": 1234567,
        ///         "dataRef": 2019-11-02 00:00:00,
        ///         "txtChave": "texto chave",
        ///         "arquivo":  "nome do documento
        ///     }
        /// </remarks>
        [Route("geracao/salvarLog")]
        [HttpPut]
        public ActionResult PutPrvt116(int cdAg, int numCc, string dataRef, string txtChave, string arquivo)
        {

            Prvt116ChvCript prvt116 = _geracaoService.ObterLog116(cdAg,numCc,dataRef,txtChave,arquivo);

            _context.Add(prvt116);
            _context.SaveChanges();
           
            return Ok();
        }

        [Route("geracao/envioFila")]
        [HttpPut]
        public ActionResult SendToQueue(string data, string tipo)
        {
            try
            {
                Dictionary<String, int> tipos = new Dictionary<string, int>();
                tipos.Add("private", 1);
                tipos.Add("safraInvest", 2);
                tipos.Add("outros", 3);

                _geracaoService.verifyTosend(data, tipos[tipo]);
                return Ok("Sucesso no envio para a fila!");
            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }
    }
}
