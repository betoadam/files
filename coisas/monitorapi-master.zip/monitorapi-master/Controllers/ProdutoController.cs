using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using MonitorAPI.Models;
using MonitorAPI.Services;
using MonitorAPI.DTO;


namespace MonitorAPI.Controllers
{
    [ApiController]
    public class ProdutoController : ControllerBase
    {
        private readonly DatabaseContext _context;
        private readonly ProdutoService _produtoService;
        private readonly IConfiguration _configuration;
        private readonly HomeService _homeService;
        private readonly BackofficeService _backofficeService;


        public ProdutoController(
            DatabaseContext context,
            IConfiguration configuration,
            ProdutoService produtoService,
            HomeService homeService,
            BackofficeService backofficeService)
        {
            _context = context;
            _configuration = configuration;
            _produtoService = produtoService;
            _homeService = homeService;
            _backofficeService = backofficeService;
        }

        /// <summary>
        ///     GERAÇÃO DE AMOSTRAS / APROVAR 
        /// </summary>
        /// <remarks>
        ///     Sample request:
        ///
        ///     PUT /produtos/aprovar
        ///     {
        ///         "data": 03/2020,
        ///         "tipo": "PRIVATE",
        ///         "role": "TI"
        ///     }
        /// </remarks>
        //tipo = Private/Safrainvest/Outros
        [Route("produtos/aprovar")]
        [HttpPut]
        public ActionResult<RelatorioBackofficeDTO> PutProdutosAprovar([FromBody]JsonDTO obs, string data, string tipo, string role)
        {
            role = role.ToUpper();
            var auth = _produtoService.auth(role);

            if (auth)
            {
                try
                {
                    tipo = tipo.ToUpper();
                    //var service = new HomeService(_context);

                    var descCoe = new DescricaoProcessoDTO(tipo, "TSD");
                    var descFundos = new DescricaoProcessoDTO(tipo, "FUNDOS");
                    var descPrevidencia = new DescricaoProcessoDTO(tipo, "RDF");

                    List<string> listaValidacao = new List<string>
                    {
                        descCoe.RelatorioValidacaoDados,
                        descFundos.RelatorioValidacaoDados,
                        descPrevidencia.RelatorioValidacaoDados,
                        descCoe.RelatorioUploadImagensCE,
                        descCoe.RelatorioUploadImagensIS,
                        descCoe.RelatorioUploadImagensRF
                    };

                    var validaRelatorios = _homeService.ObterListaT064(data, listaValidacao);

                    if (validaRelatorios.Where(x => x.IdSitEtap == 'C').Count() < 6)
                    {
                        return Ok(new { Message = "Etapa Geração de Amostra não concluída!" });
                    }

                    var consulta = _homeService.ObterT064(data, descCoe.RelatorioGerarAmostra);

                    consulta.IdSitEtap = 'C';
                    consulta.TxtObs = obs.Obs;
                    _context.Update(consulta);
                    var prvt113 = _produtoService.ObterLog(tipo);
                    prvt113.TxtDescFlux = "APROVACAO TOTAL PRODUTOS";
                    _context.Add(prvt113);
                    _context.SaveChanges();

                    return Ok(new {Message="Sucesso na aprovacao produtos"});
                }
                catch (Exception ex)
                {
                    return BadRequest(ex);
                }
            }
            return BadRequest(new {Message="Usuário não autorizado"});
        }

        /// <summary>
        ///     GERAÇÃO DE AMOSTRAS / REPROVAR
        /// </summary>
        /// <remarks>
        ///     Sample request:
        ///
        ///     PUT /produtos/reprovar
        ///     {
        ///         "data": 03/2020,
        ///         "tipo": "PRIVATE",
        ///         "role": "TI"
        ///     }
        /// </remarks>
        //tipo = Private/Safrainvest/Outros
        [Route("produtos/reprovar")]
        [HttpPut]
        public ActionResult<RelatorioBackofficeDTO> PutProdutosReprovar([FromBody]JsonDTO obs, string data, string tipo, string role)
        {
            role = role.ToUpper();
            var auth = _produtoService.auth(role);

            if (auth)
            {
                try
                {
                    tipo = tipo.ToUpper();
                    //var homeService = new HomeService(_context);
                    //var backofficeService = new BackofficeService(_context);

                    var descCoe = new DescricaoProcessoDTO(tipo, "TSD");
                    var descFundos = new DescricaoProcessoDTO(tipo, "FUNDOS");
                    var descPrevidencia = new DescricaoProcessoDTO(tipo, "RDF");

                    List<string> listaTipo = new List<string>
                    {
                        descCoe.RelatorioValidacaoDados,
                        descFundos.RelatorioValidacaoDados,
                        descPrevidencia.RelatorioValidacaoDados
                    };

                    var consulta = _homeService.ObterListaT064(data, listaTipo);

                    foreach (var item in consulta)
                    {
                        item.IdSitEtap = 'P';
                        _context.Set<Prvt064LgProm>().Attach(item);
                        _context.Entry(item).Property(x => x.IdSitEtap).IsModified = true;
                    }
                    _context.SaveChanges();
                    
                    var consultaTipo = _homeService.ObterT064(data, descCoe.RelatorioGerarAmostra);
                    consultaTipo.TxtObs = obs.Obs;
                    _context.Update(consultaTipo);
                    
                    _context.SaveChanges();
                    var prvt113 = _produtoService.ObterLog(tipo);
                    prvt113.TxtDescFlux = "REPROVACAO TOTAL PRODUTOS";
                    _context.Add(prvt113);

                    _context.SaveChanges();

                    RelatorioBackofficeDTO retorno = _backofficeService.ConsultaBackoffice(data, tipo);

                    return retorno;
                }
                catch (Exception ex)
                {
                    return BadRequest(ex);
                }
            }
            return BadRequest(new {Message="Usuário não autorizado"});
        }
    
        /// <summary>
        ///     VALIDAÇÃO DE AMOSTRAS E RELATÓRIOS / APROVAR PRODUTO
        /// </summary>
        /// <remarks>
        ///     Sample request:
        ///
        ///     PUT /validacao/aprovar/produtos
        ///     {
        ///         "data": 03/2020,
        ///         "tipo": "PRIVATE",
        ///         "role": "TI"
        ///     }
        /// </remarks>
        //tipo = Private/Safrainvest/Outros
        [Route("validacao/aprovar/produtos")]
        [HttpPut]
        public ActionResult PutValidacaoAprovarProdutos([FromBody]JsonDTO obs, string data, string tipo, string role)
        {
            role = role.ToUpper();
            var auth = _produtoService.auth(role);

            if (auth)
            {
                try
                {
                    tipo = tipo.ToUpper();
                    //var service = new HomeService(_context);
                    var descProc = new DescricaoProcessoDTO(tipo, "");

                    var validacao = _homeService.ObterT064(data, descProc.RelatorioGerarAmostra);

                    if (validacao.IdSitEtap != 'C')
                    {
                        return Ok(new { Message = "Etapa Geração de Amostra não concluída!" });
                    }

                    var consulta = _homeService.ObterT064(data, descProc.RelatorioValidaAmostraPF);

                    consulta.IdSitEtap = 'C';
                    consulta.TxtObs = obs.Obs;
                    _context.Update(consulta);
                    var prvt113 = _produtoService.ObterLog(tipo);
                    prvt113.TxtDescFlux = "APROVACAO TOTAL PRODUTOS";
                    _context.Add(prvt113);
                    _context.SaveChanges();

                    return Ok(new {Message="Sucesso na validacao aprovar produtos"});
                }
                catch (Exception ex)
                {
                    return BadRequest(ex);
                }
            }

            return BadRequest(new {Message="Usuário não autorizado"});
        }

        /// <summary>
        ///     VALIDAÇÃO DE AMOSTRAS E RELATÓRIOS / REPROVAR PRODUTO
        /// </summary>
        /// <remarks>
        ///     Sample request:
        ///
        ///     PUT /validacao/reprovar/produtos
        ///     {
        ///         "data": 03/2020,
        ///         "tipo": "PRIVATE",
        ///         "step": "dados processados",
        ///         "role": "TI"
        ///     }
        /// </remarks>
        //tipo = Private/Safrainvest/Outros
        //step = "geracao amostras"/ "dados processados" / "arquivo lamina"
        [Route("validacao/reprovar/produtos")]
        [HttpPut]
        public ActionResult PutValidacaoReprovarProdutos([FromBody]JsonDTO obs, string data, string tipo, string step, string role)
        {
            role = role.ToUpper();
            var auth = _produtoService.auth(role);

            if (auth)
            {
                try
                {
                    tipo = tipo.ToUpper();
                    step = step.ToUpper();
                    //var service = new HomeService(_context);

                    var descCoe = new DescricaoProcessoDTO(tipo, "TSD");
                    var descFundos = new DescricaoProcessoDTO(tipo, "FUNDOS");
                    var descPrevidencia = new DescricaoProcessoDTO(tipo, "RDF");

                    var validacao = _homeService.ObterT064(data, descCoe.RelatorioGerarAmostra);

                    if (validacao.IdSitEtap != 'C')
                    {
                        
                        return Ok(new { Message = "Etapa Geração de Amostra não concluída!" });
                    }

                    List<string> listaTipo = new List<string>
                    {
                        descCoe.RelatorioGerarAmostra,
                        descCoe.RelatorioValidaAmostraPF,
                        descCoe.RelatorioValidaAmostraMKT
                    };

                    if (step == "VALIDACAODADOS")
                    {
                        listaTipo.Add(descCoe.RelatorioValidacaoDados);
                        listaTipo.Add(descFundos.RelatorioValidacaoDados);
                        listaTipo.Add(descPrevidencia.RelatorioValidacaoDados);
                   
                    }

                    if (step == "GERACAOAMOSTRA")
                    {
                        listaTipo.Add(descCoe.RelatorioGerarAmostra);
                    }

                   

                    var consulta = _homeService.ObterListaT064(data, listaTipo);

                    foreach (var item in consulta)
                    {
                        item.IdSitEtap = 'P';
                        _context.Set<Prvt064LgProm>().Attach(item);
                        _context.Entry(item).Property(x => x.IdSitEtap).IsModified = true;
                    }
                    validacao.TxtObs = obs.Obs;
                    _context.Update(validacao);
                    var prvt113 = _produtoService.ObterLog(tipo);
                    prvt113.TxtDescFlux = "REPROVACAO TOTAL PRODUTOS";
                    _context.Add(prvt113);
                    _context.SaveChanges();

                    return Ok(new { Message = "Sucesso na reprovacao produto" });
                }
                catch (Exception ex)
                {
                    return BadRequest(ex);
                }
            }
            return BadRequest(new {Message="Usuário não autorizado"});
        }

        /// <summary>
        ///    VALIDAÇÃO DE AMOSTRAS E RELATÓRIOS / VOLTAR FLUXO PRODUTO
        /// </summary>
        /// <remarks>
        ///     Sample request:
        ///
        ///     PUT /produto/revisaoAprovacao
        ///     {
        ///         "data": 03/2020,
        ///         "tipo": "PRIVATE",
        ///         "step": "VALIDACAO DE DADOS",
        ///         "role": "TI"
        ///     }
        /// </remarks>
        [Route("produto/revisaoAprovacao")]
        [HttpPut]
        public ActionResult PutRevisaoAprovacao(string data, string tipo, string step, string role)
        {
            role = role.ToUpper();
            var auth = _produtoService.auth(role);

            if (auth)
            {
                try
                {
                    if (step == "GERAR AMOSTRAS")
                    {
                        _homeService.GerarAmostra(data, tipo);

                    }
                    else if (step == "VALIDACAO DE DADOS")
                    {
                        _homeService.GerarAmostra(data, tipo);
                        _homeService.ValidacaoDados(data, tipo);
                    }

                    return Ok(new {Message="Voltando para o fluxo " + step});
                }
                catch (Exception ex)
                {
                    return BadRequest(ex);
                }
            }

            return BadRequest(new {Message="Usuário não autorizado"});

        }



        [Route("download/amostra")]
        [HttpGet]
        public ActionResult<List<RetornoAmostraContasDTO>> GetDownloadAmostra(string data)
        {
            try
            {
                var retorno = new List<RetornoAmostraContasDTO>();
                //var service = new HomeService(_context);

                retorno = _homeService.ObterListaT112(data);

                return retorno;//_context.Users.ToListAsync();
            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }


    }
}
