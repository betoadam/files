using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using MonitorAPI.Models;
using MonitorAPI.Services;
using MonitorAPI.DTO;


namespace MonitorAPI.Controllers
{
    [ApiController]
    public class TiController : ControllerBase
    {
        private readonly DatabaseContext _context;
        private readonly IConfiguration _configuration;
        private readonly TiService _tiService;
        private readonly HomeService _homeService;
        public TiController(
            DatabaseContext context,
            IConfiguration configuration,
            TiService tiService,
            HomeService homeService)
        {
            _context = context;
            _configuration = configuration;
            _tiService = tiService;
            _homeService = homeService;
        }

        /// <summary>
        ///    RESETAR FLUXO
        /// </summary>
        /// <remarks>
        ///     Sample request:
        ///
        ///     PUT /resetar
        ///     {
        ///         "data": 03/2020,
        ///         "tipo": "PRIVATE"
        ///     }
        /// </remarks>
        [Route("resetar")]
        [HttpPut]
        public ActionResult Putreset(string data, string tipo)
        {
            try
            {
                tipo = tipo.ToUpper();
                //var service = new HomeService(_context);

                var descProc = new DescricaoProcessoDTO(tipo, "");

                var consulta = _homeService.ObterT064(data, descProc.IntegraLaminaFundos);
                consulta.IdSitEtap = 'P';
                _context.Update(consulta);

                consulta = _homeService.ObterT064(data, descProc.RelatorioGerarAmostra);
                consulta.IdSitEtap = 'P';
                _context.Update(consulta);

                consulta = _homeService.ObterT064(data, descProc.RelatorioGerarPdf);
                consulta.IdSitEtap = 'P';
                _context.Update(consulta);

                consulta = _homeService.ObterT064(data, descProc.RelatorioUploadImagensCE);
                consulta.IdSitEtap = 'P';
                _context.Update(consulta);

                consulta = _homeService.ObterT064(data, descProc.RelatorioUploadImagensIS);
                consulta.IdSitEtap = 'P';
                _context.Update(consulta);

                consulta = _homeService.ObterT064(data, descProc.RelatorioUploadImagensRF);
                consulta.IdSitEtap = 'P';
                _context.Update(consulta);

                consulta = _homeService.ObterT064(data, descProc.RelatorioValidaAmostraMKT);
                consulta.IdSitEtap = 'P';
                _context.Update(consulta);

                consulta = _homeService.ObterT064(data, descProc.RelatorioValidaAmostraPF);
                consulta.IdSitEtap = 'P';
                _context.Update(consulta);

                //operacao = RDF/TSD/FUNDOS
                descProc = new DescricaoProcessoDTO(tipo, "RDF");
                consulta = _homeService.ObterT064(data, descProc.RelatorioValidacaoDados);
                consulta.IdSitEtap = 'P';
                _context.Update(consulta);

                descProc = new DescricaoProcessoDTO(tipo, "FUNDOS");
                consulta = _homeService.ObterT064(data, descProc.RelatorioValidacaoDados);
                consulta.IdSitEtap = 'P';
                _context.Update(consulta);

                descProc = new DescricaoProcessoDTO(tipo, "TSD");
                consulta = _homeService.ObterT064(data, descProc.RelatorioValidacaoDados);
                consulta.IdSitEtap = 'P';
                _context.Update(consulta);

                _context.SaveChanges();

                 var folder = _configuration.GetValue<string>("DefaultConnection:Folder");
                    string[] lisImagens = new string[3] { "CENARIO_ECONOMICO", "INFORME_SAFRA", "RENTABILIDADE_FUNDOS" };
                    string[] tipoArquivo = new string[4] { "pdf", "png", "jpeg", "jpg" };
                    string[] lisimagem = new string[3];
                    for (int i = 0; i < lisImagens.Length; i++)
                    {
                        foreach (string extencao in tipoArquivo)
                        {
                            var nomeImagem = tipo.ToUpper() + "_" + lisImagens[i] + "_" + data.Replace("/", "-") + "." + extencao;
                            if (System.IO.File.Exists(folder + nomeImagem))
                            {

                                System.IO.File.Delete(folder + nomeImagem);
        
                            }
                        }
                    }

                return Ok(new { Message = "Dados retornados com sucesso!" });
            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }

        [Route("ti")]
        [HttpGet]
        public ActionResult<List<StatusDescricaoDTO>> GetTi(string data, string role)
        {
            role = role.ToUpper();
            var auth = _tiService.auth(role);

            if (auth)
            {
                try
                {
                    var retorno = new List<StatusDescricaoDTO>();
                    //var service = new TiService(_context);

                    retorno = _tiService.ListaTi(data);

                    return retorno;//_context.Users.ToListAsync();
                }
                catch (Exception ex)
                {
                    return BadRequest(ex);
                }
            }
            return BadRequest(new {Message="Usuário não autorizado"});
        }

        [Route("ti/mq")]
        [HttpPost]
        public ActionResult PostMq([FromBody]TiMqDTO valores, string role)
        {
            role = role.ToUpper();
            var auth = _tiService.auth(role);
            if (auth)
            {
                return Ok("sucesso" + valores.Usuario + valores.Agencia + valores.Conta + valores.Data);
            }

            return BadRequest(new {Message="Usuário não autorizado"});

        }

        [Route("ti/enviarFila")]
        [HttpPost]
        public ActionResult PostTiEnviarFila(string data, string tipo, string role)
        {
            role = role.ToUpper();
            var auth = _tiService.auth(role);

            if (auth)
            {
                var verifica63 = _homeService.ObterT063(data);

                if (verifica63.IdSitDemd != 'I')
                {
                    return BadRequest("Status da demanda diferente de 'Iniciada'!");
                }

                var descProc = new DescricaoProcessoDTO(tipo, "");

                List<string> listaTipo = new List<string>
                {
                    descProc.RelatorioValidaAmostraPF,
                    descProc.RelatorioValidaAmostraMKT
                };

                var verifica64 = _homeService.ObterListaT064(data, listaTipo);

                if (verifica64.Where(x => x.IdSitEtap == 'C').Count() < 2)
                {
                    return BadRequest("Etapas Anteriores ainda não resolvidas!");
                }

                _tiService.EnviarFila(data, tipo);

                var descCoe = new DescricaoProcessoDTO(tipo, "TSD");
                var descFundos = new DescricaoProcessoDTO(tipo, "FUNDOS");
                var descPrevidencia = new DescricaoProcessoDTO(tipo, "PREVIDENCIA");

                List<string> listaFinal = new List<string>
                {
                    descCoe.RelatorioGerarPdf,
                    descFundos.RelatorioGerarPdf,
                    descPrevidencia.RelatorioGerarPdf,
                };

                var verificaPdf = _homeService.ObterListaT064(data, listaTipo);

                if (verificaPdf.Where(x => x.IdSitEtap == 'C').Count() == 3)
                {
                    verifica63.IdSitDemd = 'C';
                    _context.Update(verifica63);
                    _context.SaveChanges();
                }

                return Ok(new { Message = "Sucesso no envio de fila!" });
            }

            return BadRequest(new {Message="Usuário não autorizado"});
        }
    }
}
