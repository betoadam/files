namespace MonitorAPI.DTO
{
    public class StatusDescricaoDTO {
      public char Status { get; set; }
      public string Descricao { get; set; }
    }
}