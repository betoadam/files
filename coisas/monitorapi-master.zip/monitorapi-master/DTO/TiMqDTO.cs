namespace MonitorAPI.DTO
{
    public class TiMqDTO {
        public string Usuario { get; set; }
        public string Agencia { get; set;}
        public string Conta { get; set;}
        public string Data { get; set;}
    }
}