namespace MonitorAPI.DTO
{
    public class RetornoCharDTO
    {
        public char Retorno { get; set; }
    }
}