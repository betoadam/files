namespace MonitorAPI.DTO
{
    public class RelatorioStatusDTO {
        public char Ti {get; set;}
        public char Backoffice {get; set;}
        public char Marketing1 {get; set;}
        public char Produtos2 {get; set;}
        public char Marketing2 {get; set;}
        public char Marketing3 {get; set;}
        public char Automatico {get; set;}
        public char Produtos { get; set; }
    }
}