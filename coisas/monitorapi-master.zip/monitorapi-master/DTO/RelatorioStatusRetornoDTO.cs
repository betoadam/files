﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MonitorAPI.DTO
{
    public class RelatorioStatusRetornoDTO
    {
        public RelatorioStatusDTO Private { get; set; }
        public RelatorioStatusDTO Safrainvest { get; set; }
        public RelatorioStatusDTO Outros { get; set; }
    }
}
