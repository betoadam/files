using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;

namespace MonitorAPI.DTO
{
    public class RetornoAmostraContasDTO
    {
        [JsonProperty("Sistema")]    
        public string Sistema { get; set; }
        [JsonProperty("Legado")]    
        public string Legado { get; set; }
        [JsonProperty("Agencia")]    
        public string Agencia { get; set; }
        [JsonProperty("Conta")]    
        public string Conta { get; set; }
        [JsonProperty("DataReferencia")]    
        public string DataReferencia { get; set; }
        [JsonProperty("Template")]    
        public string Template { get; set; }
        [JsonProperty("Segmento")]    
        public string Segmento { get; set; }
        [JsonProperty("CodigoCliente")]    
        public string CodigoCliente { get; set; }
        [JsonProperty("CodigoTipoPessoa")]    
        public string CodigoTipoPessoa { get; set;}
        [JsonProperty("UsuarioSolicitante")]    
        public string UsuarioSolicitante { get; set;}

    }
}