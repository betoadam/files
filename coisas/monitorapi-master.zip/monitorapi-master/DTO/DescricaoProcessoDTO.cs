namespace MonitorAPI.DTO
{
    public class DescricaoProcessoDTO
    {
        public string IntegraSaldoContaCorrente { get; private set; }
        public string IntegraMovimentoContaCorrente { get; private set; }
        public string IntegraRelacionamentoCliente { get; private set; }
        public string IntegraListaCliente { get; private set; }
        public string IntegraSaldoPoupanca { get; private set; }
        public string IntegraMovimentoPoupanca { get; private set; }
        public string IntegraSuitability { get; private set; }
        public string IntegraLaminaFundos { get; private set; }
        public string RelatorioDados { get; private set; }
        public string RelatorioValidacaoDados { get; private set; }
        public string RelatorioUploadImagensCE { get; private set; }
        public string RelatorioUploadImagensIS { get; private set; }
        public string RelatorioUploadImagensRF { get; private set; }
        public string RelatorioGerarAmostra { get; private set; }
        public string RelatorioValidaAmostraPF { get; private set; }
        public string RelatorioValidaAmostraMKT { get; private set; }
        public string RelatorioGerarPdf { get; private set; }

        //tipo = PRIVATE/SAFRAINVEST/OUTROS
        //operacao = RDF/TSD/FUNDOS
        public DescricaoProcessoDTO(string tipo, string operacao)
        {
            IntegraSaldoContaCorrente = "INTEGRADOR - SALDOS CONTA CORRENTE";
            IntegraMovimentoContaCorrente = "INTEGRADOR - MOVIMENTOS CONTA CORRENTE";
            IntegraRelacionamentoCliente = "INTEGRADOR - RELACIONAMENTO CLIENTE";
            IntegraListaCliente = "INTEGRADOR - LISTA CLIENTES";
            IntegraSaldoPoupanca = "INTEGRADOR - SALDOS POUPANCA";
            IntegraMovimentoPoupanca = "INTEGRADOR - MOVIMENTOS POUPANCA";
            IntegraSuitability = "INTEGRADOR - SUITABILITY";
            IntegraLaminaFundos = "INTEGRADOR - LAMINA DE FUNDOS";
            RelatorioDados = "RELATORIO - DADOS DO RELATORIO";
            RelatorioValidacaoDados = "RELATORIO - VALIDACAO DE DADOS " + operacao + " " + tipo;
            RelatorioUploadImagensCE = "RELATORIO - UPLOAD IMAGENS " + tipo + " CENARIO ECONOMICO";
            RelatorioUploadImagensIS = "RELATORIO - UPLOAD IMAGENS " + tipo + " INFORME SAFRA";
            RelatorioUploadImagensRF = "RELATORIO - UPLOAD IMAGENS " + tipo + " RENTAB. FUNDOS";
            RelatorioGerarAmostra = "RELATORIO - GERAR AMOSTRAS " + tipo;
            RelatorioValidaAmostraPF = "RELATORIO - VALIDACAO DEOSTRAS PF " + tipo;
            RelatorioValidaAmostraMKT = "RELATORIO - VALIDACAO DEOSTRAS MKT " + tipo;
            RelatorioGerarPdf = "RELATORIO - GERAR RELATORIOS PDF " + tipo;
        }
    }
}