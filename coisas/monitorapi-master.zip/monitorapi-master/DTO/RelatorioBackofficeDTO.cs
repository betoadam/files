namespace MonitorAPI.DTO
{
    public class RelatorioBackofficeDTO {
      public char Backofficeprevidencia { get; set; }
      public char Backofficefundos { get; set; }
      public char Backofficecoe { get; set; }
      public char Backoffice { get; set;}
    }
}