namespace MonitorAPI.DTO

{
    public class RetornoEnvioFilaDTO {
        public bool sucesso { get; set;}
    }
}