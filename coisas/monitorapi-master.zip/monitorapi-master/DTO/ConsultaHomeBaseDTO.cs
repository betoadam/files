namespace MonitorAPI.DTO
{
    public class ConsultaHomeBaseDTO {
        public string TxtDescPro { get; set;}
        public char IdSitDemd { get; set;}
        public char IdSitEtap { get; set;}
    }
}