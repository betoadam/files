using System.Data;
using Microsoft.Extensions.Configuration;
using Oracle.ManagedDataAccess.Client;

namespace MonitorAPI.Oracle
{
    public class OracleConnections
    {
        private readonly IConfiguration _configuration;

        public OracleConnections(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public IDbConnection GetConnection()
        {
            var connectionString = _configuration.GetConnectionString("DefaultConnection");
            var conn = new OracleConnection(connectionString);
            return conn;
        }

    }
}