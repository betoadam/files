# API de dados .NET Core

Api de geração dos dados utilizados no Extrato Private