using Microsoft.Extensions.Configuration;

public static class AppConfig
{
  public static IConfiguration Configuration;
}