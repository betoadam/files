﻿namespace DadosAPI.Models
{
    public class StatusProcessamento
    {
        public int Code { get; set; }

        public string Message { get; set; }
    }
}