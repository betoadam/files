﻿using System.Collections.Generic;

namespace DadosAPI.Models
{
    public class DetalhamentoFundosInvestimento
    {
        public string Fundos { get; set; }
        public string QtdeCotas { get; set; }
        public string ValorCotas { get; set; }
        public string SaldoAplicado { get; set; }
        public string SaldoBruto { get; set; }
        public string ImpostoPrevisto { get; set; }
        public string SaldoLiquido { get; set; }
        public string IsBold { get; set; }

        public StatusSecao StatusSecao { get; set; }
        public List<DetalhamentoFundosInvestimento> DetalhamentoFundosInvestimentoList { get; set; }
    }
}