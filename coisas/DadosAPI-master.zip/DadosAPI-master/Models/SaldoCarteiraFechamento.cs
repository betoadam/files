﻿using System;
using System.Collections.Generic;

namespace DadosAPI.Models
{
    public class SaldoCarteiraFechamento
    {
        public List<SaldoCarteiraFechamentoConteudo> Conteudo { get; set; }

        public StatusProcessamento StatusProcessamento { get; set; }

        public class SaldoCarteiraFechamentoConteudo
        {
            public string SistemaOrigem { get; set; }
            public string Legado { get; set; }
            public int Agencia { get; set; }
            public int Conta { get; set; }
            public string IndProduto { get; set; }
            public string DataSaldo { get; set; }
            public decimal ValorSaldoBruto { get; set; }
            public decimal ValorSaldoLiquido { get; set; }
            public decimal ValorIR { get; set; }
            public decimal ValorIOF { get; set; }
            public string DataRetorno { get; set; }
            public int QuantidadeOcorrencias { get; set; }

            public DateTime dtAnoMesRef { get; set; }
        }
    }
}