using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DadosAPI.Models.DadosAPI
{
    [Table("PRVT073_PAG_EXTT")]
    public class Prvt073
    {
        [Key]
        [Column("CD_PAG")]
        public int CdPag { get; set; }
        
        [Column("NM_PAG")]
        public string NmPag { get; set; }

        [Column("IC_STAT")]
        public char? IcStat { get; set; }
    }
}