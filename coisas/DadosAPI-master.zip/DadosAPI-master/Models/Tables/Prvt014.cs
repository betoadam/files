using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DadosAPI.Models.DadosAPI
{
    [Table("PRVT014_PARAMETRO_S")]
    public class Prvt014
    {
        [Key]
        [Column("CD_PARM")]
        public int CdParm { get; set; }
        
        [Column("NM_PARM")]
        public string NmParm { get; set; }

        [Column("ID_T_PARM")]
        public char? IdTParm { get; set; }

        [Column("ID_NUM_PARM")]
        public int? IdNumParm { get; set; }

        [Column("V_PARM")]
        public DateTime? VParm { get; set; } 

        [Column("TXT_PARM")]
        public string TxtParm { get; set; }

        [Column("DT_PARM")]
        public DateTime? DtParm { get; set; }
    }
}