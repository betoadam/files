using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DadosAPI.Models.DadosAPI
{
    [Table("PRVT086_GR_CT")]
    public class Prvt086
    {
        [Key]
        [Column("CD_T_GR")]
        public int CdTGr { get; set; }

        [Column("CD_AG")]
        public int? CdAg { get; set; }

        [Column("ID_NUM_CC")]
        public int? IdNumCc { get; set; }

        [Column("CD_MRC_CLI")]
        public int? CdMrcCli { get; set; }

        [Column("CD_MRC_ADCN_CLI")]
        public int? CdMrcAdcnCli { get; set; }

        [Column("CD_CORP_CLI")]
        public int? CdCorpCli { get; set; }

        [Column("IC_CLI_FUNC")]
        public char? IcCliFunc { get; set; }

        [Column("CD_SIT_CC")]
        public int? CdSitCc { get; set; }

        [Column("CD_GR_CLI")]
        public int? CdGrCli { get; set; }

        [Column("TXT_REGR")]
        public string TxtRegr { get; set; }

        [Column("AM_REF")]
        public string AmRef { get; set; }
    }
}