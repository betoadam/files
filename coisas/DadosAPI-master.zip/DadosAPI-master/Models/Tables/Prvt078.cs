using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DadosAPI.Models.DadosAPI
{
    [Table("PRVT078_PARM_FNCL")]
    public class Prvt078
    {
        [Key]
        [Column("CD_PARM")]
        public int CdParm { get; set; }

        [Column("CD_FNCL")]
        public int? CdFncl { get; set; }
        
        [Column("SGL_SIST_ORIG")]
        public string SglSistOrig { get; set; }
        
        [Column("CD_SEGM")]
        public int? CdSegm { get; set; }
        
        [Column("ID_PS_MENS")]
        public string IdPsMens { get; set; }
    }
}