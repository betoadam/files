using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DadosAPI.Models.DadosAPI
{
    [Table("PRVT071_MVTO_EXTP")]
    public class Prvt071
    {
        [Key]
        [Column("CD_AG")]
        public int CdAg { get; set; }
        
        [Column("ID_NUM_CT")]
        public int? IdNumCt { get; set; }

        [Column("DT_REF")]
        public DateTime? DtRef { get; set; }

        [Column("Q_PAPL")]
        public float? QPapl { get; set; }

        [Column("V_PU")]
        public float? VPu { get; set; } 

        [Column("V_MVTO_EXTP")]
        public float? VMvtoExtp { get; set; }

        [Column("ID_T_MVTO")]
        public char? IdTMvto { get; set; }

        [Column("ID_OPRC_MVTO")]
        public string IdOprcMvto { get; set; }

        [Column("ID_NUM_SEQ_PROD")]
        public int? IdNumSeqProd { get; set; }
        
        [Column("ID_NUM_SEQ_RNTD_1")]
        public int? IdNumSeqRntd1 { get; set; }
        
        [Column("ID_NUM_SEQ_RNTD_2")]
        public int? IdNumSeqRntd2 { get; set; }
        
    }
}