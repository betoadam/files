using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DadosAPI.Models.DadosAPI
{
    [Table("PRVT075_TMPL_REL")]
    public class Prvt075
    {
        [Key]
        [Column("CD_TMPL")]
        public int CdTmpl { get; set; }
        
        [Column("NM_TMPL")]
        public string NmTmpl { get; set; }

        [Column("IC_STAT")]
        public char? IcStat { get; set; }
    }
}