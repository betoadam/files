using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DadosAPI.Models.DadosAPI
{
    [Table("PRVV071_DTLH_POUPANCA")]
    public class Prvv071
    {
        [Key]
        [Column("AGENCIA")]
        public int Agencia { get; set; }
        
        [Column("CONTA")]
        public int Conta { get; set; }

        [Column("DATAREFERENCIA")]
        public DateTime DataReferencia { get; set; }

        [Column("DATAVENCIMENTO")]
        public DateTime DataVencimento { get; set; }

        [Column("IDC_PROD")]
        public string IdcProd { get; set; } 

        [Column("SLD_BRUTO")]
        public string SldBruto { get; set; } 

        [Column("ID_NUM_SEQ_RNTD_PROD")]
        public float? VMvtoExtp { get; set; }

        [Column("ID_NUM_SEQ_RNTD_NIV_1")]
        public int? IdTMvto { get; set; }

        [Column("ID_NUM_SEQ_RNTD_NIV_2")]
        public int? IdOprcMvto { get; set; }

        [Column("ID_NUM_SEQ_PROD")]
        public int? IdNumSeqProd { get; set; }
    }
}