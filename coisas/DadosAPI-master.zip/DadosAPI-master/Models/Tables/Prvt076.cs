using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DadosAPI.Models.DadosAPI
{
    [Table("PRVT076_REL_GRCL")]
    public class Prvt076
    {
        [Key]
        [Column("CD_TMPL")]
        public int CdTmpl { get; set; }
        
        [Column("CD_PAG")]
        public int? CdPag { get; set; }

        [Column("CD_SECAO")]
        public int? CdSecao { get; set; }

        [Column("ID_NUM_ORDE_PAG")]
        public int? IdNumOrdePag { get; set; }

        [Column("ID_NUM_ORDE_SECAO")]
        public int? IdNumOrdeSecao { get; set; }
    }
}