﻿namespace DadosAPI.Models
{
    public class RentabilidadeFlexivelConteudo
    {
        public string SistemaOrigem { get; set; }
        public string Legado { get; set; }
        public int Agencia { get; set; }
        public int Conta { get; set; }
        public int CodRentabilidadePai { get; set; }
        public string NomeRentabilidade { get; set; }
        public string AnoMesRef { get; set; }
        public decimal PercRentabilidade { get; set; }
        public string IndAcumulado { get; set; }
        public string UltimaConhecida { get; set; }
        public string DataUltimoProcessamento { get; set; }
        public string RentabilidadeOcorrencia { get; set; }
        public int QuantidadeOcorrencias { get; set; }
    }
}