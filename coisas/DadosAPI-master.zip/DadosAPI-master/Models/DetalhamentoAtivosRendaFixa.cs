﻿using System.Collections.Generic;

namespace DadosAPI.Models
{
    public class DetalhamentoAtivosRendaFixa
    {
        public string Ativo { get; set; }
        public string CodigoCetip { get; set; }
        public string EmissorDevedor { get; set; }
        public string Indexador { get; set; }
        public decimal Taxa { get; set; }
        public decimal Percentual { get; set; }
        public string DataAplicacao { get; set; }
        public string VencimentoRepactuacao { get; set; }
        public string SaldoAplicado { get; set; }
        public string SaldoBruto { get; set; }
        public string ImpostoPrevisto { get; set; }
        public string SaldoLiquido { get; set; }

        public StatusSecao StatusSecao { get; set; }
        public List<DetalhamentoAtivosRendaFixa> DetalhamentoAtivosRendaFixaList { get; set; }
    }
}