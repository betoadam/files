﻿using System.Collections.Generic;

namespace DadosAPI.Models
{
    public class DetalhamentoPoupanca
    {
        public string DataVencimento { get; set; }
        public string Sld_Bruto { get; set; }

        public StatusSecao StatusSecao { get; set; }
        public List<DetalhamentoPoupanca> DetalhamentoPoupancaList { get; set; }

    }
}