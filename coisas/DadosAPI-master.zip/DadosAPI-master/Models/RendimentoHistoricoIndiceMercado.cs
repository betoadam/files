﻿using System.Collections.Generic;

namespace DadosAPI.Models
{
    public class RendimentoHistoricoIndiceMercado
    {
        public string Resumo { get; set; }
        public string Mes1 { get; set; }
        public string Mes2 { get; set; }
        public string Mes3 { get; set; }
        public string Mes4 { get; set; }
        public string Mes5 { get; set; }
        public string Mes6 { get; set; }
        public string Mes7 { get; set; }
        public string Mes8 { get; set; }
        public string Mes9 { get; set; }
        public string Mes10 { get; set; }
        public string Mes11 { get; set; }
        public string Mes12 { get; set; }
        public string AcumAno { get; set; }
        public string Acum12Meses { get; set; }
        public string Acum24Meses { get; set; }
        public string Acum36Meses { get; set; }
        public string CodIndice { get; set; }


        public StatusSecao StatusSecao { get; set; }

        public List<RendimentoHistoricoIndiceMercado> RendimentoHistoricoIndiceMercadoList { get; set; }

    }
}