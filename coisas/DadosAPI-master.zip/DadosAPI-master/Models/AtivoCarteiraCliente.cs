﻿using System.Collections.Generic;

namespace DadosAPI.Models
{
    public class AtivoCarteiraCliente
    {
        public string TipoLayout { get; set; }

        public List<EmissaoTerceiroModel> LstEmissaoTerceiro { get; set; }
        public List<FundoInvestimentoModel> LstFundoInvestimento { get; set; }
        public List<TesouroDiretoRendaFixaModel> LstTesouroDiretoRendaFixa { get; set; }
        public List<TituloPublicoRendaFixaModel> LstTituloPublicoRendaFixa { get; set; }
        public List<PrevidenciaModel> LstPrevidencia { get; set; }
        public List<BovespaCorretoraModel> LstBovespaCorretora { get; set; }
        public List<DerivativoEstruturadaModel> LstDerivativoEstruturada { get; set; }
        public List<COEModel> LstCOE { get; set; }
        public StatusProcessamento StatusProcessamento { get; set; }


        public class EmissaoTerceiroModel
        {
            public string SistemaOrigem { get; set; }
            public string Legado { get; set; }
            public int Agencia { get; set; }
            public int Conta { get; set; }
            public string DataReferencia { get; set; }
            public string TipoLayout { get; set; }
            public string TipoLayoutApresentar { get; set; }
            public string NomeGrupo { get; set; }
            public string NomeSubGrupo { get; set; }
            public string Ativo { get; set; }
            public string Emissor { get; set; }
            public string Indexador { get; set; }
            public decimal TaxaNegociada { get; set; }
            public decimal PercentualIndexador { get; set; }
            public string DataAplicacao { get; set; }
            public string DataRepactuacao { get; set; }
            public string DataVencimento { get; set; }
            public decimal SaldoAplicado { get; set; }
            public decimal SaldoBruto { get; set; }
            public decimal ImpostoPrevisto { get; set; }
            public decimal SaldoLiquido { get; set; }
            public int IdentSeqProduto { get; set; }
            public int IdentSeqGrupoProduto { get; set; }
            public int IdentSeqFamilia { get; set; }
            public string DataRetorno { get; set; }
            public int QuantidadeOcorrencias { get; set; }
            public string StatusRetorno { get; set; }

        }
        public class FundoInvestimentoModel
        {
            public string SistemaOrigem { get; set; }
            public string Legado { get; set; }
            public int Agencia { get; set; }
            public int Conta { get; set; }
            public string DataReferencia { get; set; }
            public string TipoLayout { get; set; }
            public string TipoLayoutApresentar { get; set; }
            public string NomeGrupo { get; set; }
            public string NomeSubGrupo { get; set; }
            public string NomeFundo { get; set; }
            public string Ativo { get; set; }
            public string Emissor { get; set; }
            public string Indexador { get; set; }
            public string DataAplicacao { get; set; }
            public string DataVencimento { get; set; }
            public decimal QtdCotas { get; set; }
            public decimal ValorCota { get; set; }
            public decimal SaldoAplicado { get; set; }
            public decimal SaldoBruto { get; set; }
            public decimal ImpostoPrevisto { get; set; }
            public decimal SaldoLiquido { get; set; }
            public int OrdemGrupoProduto { get; set; }
            public int IdentSeqProduto { get; set; }
            public int IdentSeqGrupoProduto { get; set; }
            public int IdentSeqFamilia { get; set; }
            public string DataRetorno { get; set; }
            public int QuantidadeOcorrencias { get; set; }
            public string StatusRetorno { get; set; }

        }
        public class TesouroDiretoRendaFixaModel
        {
            public string SistemaOrigem { get; set; }
            public string Legado { get; set; }
            public int Agencia { get; set; }
            public int Conta { get; set; }
            public string DataReferencia { get; set; }
            public string TipoLayout { get; set; }
            public string TipoLayoutApresentar { get; set; }
            public decimal TaxaNegociada { get; set; }
            public decimal PercentualIndexador { get; set; }
            public string NomeGrupo { get; set; }
            public string NomeSubGrupo { get; set; }
            public string NomePapel { get; set; }
            public string IndexadorPapel { get; set; }
            public string DataAplicacao { get; set; }
            public string DataVencimento { get; set; }
            public decimal ValorAplicado { get; set; }
            public decimal ImpostoPrevisto { get; set; }
            public decimal SaldoAtual { get; set; }
            public decimal SaldoLiquido { get; set; }
            public string Emissor { get; set; }
            public int IdentSeqProduto { get; set; }
            public int IdentSeqGrupoProduto { get; set; }
            public int IdentSeqFamilia { get; set; }
            public string DataRetorno { get; set; }
            public int QuantidadeOcorrencias { get; set; }
            public string StatusRetorno { get; set; }


        }
        public class TituloPublicoRendaFixaModel
        {
            public string SistemaOrigem { get; set; }
            public string Legado { get; set; }
            public int Agencia { get; set; }
            public int Conta { get; set; }
            public string DataReferencia { get; set; }
            public string TipoLayout { get; set; }
            public string TipoLayoutApresentar { get; set; }
            public decimal TaxaNegociada { get; set; }
            public decimal PercentualIndexador { get; set; }
            public string NomeGrupo { get; set; }
            public string NomeSubGrupo { get; set; }
            public string NomePapel { get; set; }
            public string IndexadorPapel { get; set; }
            public string DataAplicacao { get; set; }
            public string DataVencimento { get; set; }
            public decimal ValorAplicado { get; set; }
            public decimal ImpostoPrevisto { get; set; }
            public decimal SaldoAtual { get; set; }
            public decimal SaldoLiquido { get; set; }
            public string Emissor { get; set; }
            public int IdentSeqProduto { get; set; }
            public int IdentSeqGrupoProduto { get; set; }
            public int IdentSeqFamilia { get; set; }
            public string DataRetorno { get; set; }
            public int QuantidadeOcorrencias { get; set; }
            public string StatusRetorno { get; set; }

        }
        public class PrevidenciaModel
        {
            public string SistemaOrigem { get; set; }
            public string Legado { get; set; }
            public int Agencia { get; set; }
            public int Conta { get; set; }
            public string DataReferencia { get; set; }
            public string TipoLayout { get; set; }
            public string TipoLayoutApresentar { get; set; }
            public string NomeGrupo { get; set; }
            public string NomeSubGrupo { get; set; }
            public string PlanoPrevidencia { get; set; }
            public string Certificado { get; set; }
            public string Indexador { get; set; }
            public decimal QuantidadeCota { get; set; }
            public decimal ValorCota { get; set; }
            public decimal ValorAplicado { get; set; }
            public decimal SaldoBruto { get; set; }
            public decimal SaldoLiquido { get; set; }
            public decimal ValorImpPrevisto { get; set; }
            public int IdentSeqProduto { get; set; }
            public int IdentSeqGrupoProduto { get; set; }
            public int IdentSeqFamilia { get; set; }
            public string DataRetorno { get; set; }
            public int QuantidadeOcorrencias { get; set; }
            public string StatusRetorno { get; set; }


        }
        public class BovespaCorretoraModel
        {
            public string SistemaOrigem { get; set; }
            public string Legado { get; set; }
            public int Agencia { get; set; }
            public int Conta { get; set; }
            public string DataReferencia { get; set; }
            public string TipoLayout { get; set; }
            public string TipoLayoutApresentar { get; set; }
            public string NomeGrupo { get; set; }
            public string NomeSubGrupo { get; set; }
            public string NomePapel { get; set; }
            public string SubProduto { get; set; }
            public string DescricaoPapel { get; set; }
            public string DataAnterior { get; set; }
            public decimal QuantidadeAtual { get; set; }
            public decimal CotacaoAtual { get; set; }
            public decimal SaldoAtual { get; set; }
            public int IdentSeqProduto { get; set; }
            public int IdentSeqGrupoProduto { get; set; }
            public int IdentSeqFamilia { get; set; }
            public string DataRetorno { get; set; }
            public int QuantidadeOcorrencias { get; set; }
            public string StatusRetorno { get; set; }

        }
        public class DerivativoEstruturadaModel
        {
            public string SistemaOrigem { get; set; }
            public string Legado { get; set; }
            public int Agencia { get; set; }
            public int Conta { get; set; }
            public string DataReferencia { get; set; }
            public string TipoLayout { get; set; }
            public string TipoLayoutApresentar { get; set; }
            public string NomeGrupo { get; set; }
            public string NomeSubGrupo { get; set; }
            public string InvestimentoNomeOperacao { get; set; }
            public string DataInicial { get; set; }
            public string DataFinal { get; set; }
            public decimal ValorNegociado { get; set; }
            public decimal ValorAjusteBruto { get; set; }
            public decimal ImpostoPrevisto { get; set; }
            public decimal ValorAjusteLiquido { get; set; }
            public int IdentSeqProduto { get; set; }
            public int IdentSeqGrupoProduto { get; set; }
            public int IdentSeqFamilia { get; set; }
            public string DataRetorno { get; set; }
            public int QuantidadeOcorrencias { get; set; }
            public string StatusRetorno { get; set; }

        }
        public class COEModel
        {
            public string SistemaOrigem { get; set; }
            public string Legado { get; set; }
            public int Agencia { get; set; }
            public int Conta { get; set; }
            public string DataReferencia { get; set; }
            public string TipoLayout { get; set; }
            public string TipoLayoutApresentar { get; set; }
            public string NomeGrupo { get; set; }
            public string NomeSubGrupo { get; set; }
            public string Label { get; set; }
            public string NomeProduto { get; set; }
            public string DataInicial { get; set; }
            public string DataFinal { get; set; }
            public decimal ValorAplicado { get; set; }
            public decimal ValorAtualizado { get; set; }
            public decimal ImpostoPrevisto { get; set; }
            public decimal SaldoLiquido { get; set; }
            public int IdentSeqProduto { get; set; }
            public int IdentSeqGrupoProduto { get; set; }
            public int IdentSeqFamilia { get; set; }
            public string DataRetorno { get; set; }
            public int QuantidadeOcorrencias { get; set; }
            public string StatusRetorno { get; set; }

        }
    }
}