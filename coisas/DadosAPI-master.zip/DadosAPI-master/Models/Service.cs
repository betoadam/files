﻿namespace DadosAPI.Models
{
    public class Service
    {

        public ResumoConta ResumoConta = new ResumoConta();
        public RentabilidadeFixo RentabilidadeFixo = new RentabilidadeFixo();
        public BenchMarkFixo BenchMarkFixo = new BenchMarkFixo();
        public NotaSessao NotaSessao = new NotaSessao();
        public RentabilidadeFlexivel RentabilidadeFlexivel = new RentabilidadeFlexivel();
        public IndiceEquivalente IndiceEquivalente = new IndiceEquivalente();
        public IndiceAcumulado IndiceAcumulado = new IndiceAcumulado();
        public AtivoCarteiraCliente AtivoCarteiraCliente = new AtivoCarteiraCliente();

    }
}