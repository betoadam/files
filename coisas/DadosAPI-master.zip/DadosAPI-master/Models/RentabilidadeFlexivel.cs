﻿using System;
using System.Collections.Generic;

namespace DadosAPI.Models
{
    public class RentabilidadeFlexivel
    {
        public List<RentabilidadeFlexivelConteudo> Conteudo { get; set; }

        public StatusProcessamento StatusProcessamento { get; set; }

        public class RentabilidadeFlexivelConteudo
        {
            public string SistemaOrigem { get; set; }
            public string Legado { get; set; }
            public int Agencia { get; set; }
            public int Conta { get; set; }
            public int CodRentabilidade { get; set; }
            public string NomeRentabilidade { get; set; }
            public string AnoMesRef { get; set; }
            public decimal PercRentabilidade { get; set; }
            public string IndAcumulado { get; set; }
            public string UltimaConhecida { get; set; }
            public string DataUltimoProcessamento { get; set; }
            public string RentabilidadeOcorrencia { get; set; }
            public int QuantidadeOcorrencias { get; set; }
            public DateTime dtAnoMesRef { get; set; }



            public int? IdentSeqFamilia { get; set; }
            public int? OrdemApresentacaoPai { get; set; }
            public int? IdentSeqGrupoProduto { get; set; }
            public int? OrdemApresentacaoProduto { get; set; }
            public int? IdentSeqProduto { get; set; }

        }
    }
}