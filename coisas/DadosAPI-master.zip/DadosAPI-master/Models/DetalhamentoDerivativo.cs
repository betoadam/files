﻿using System.Collections.Generic;

namespace DadosAPI.Models
{
    public class DetalhamentoDerivativo
    {

        public string NomeAtivo { get; set; }
        public string DataAplicacao { get; set; }
        public string Vencimento { get; set; }
        public string ValorBase { get; set; }
        public string AjusteBruto { get; set; }
        public string ImpostosPrevistos { get; set; }
        public string AjusteLiquido { get; set; }

        public StatusSecao StatusSecao { get; set; }
        public List<DetalhamentoDerivativo> DetalhamentoDerivativoList { get; set; }

    }
}