﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DadosAPI.Models
{
    public class AtributosSecao
    {
        public string Secao { get; set; }
        public string Campo { get; set; }
    }
}
