﻿using System.Collections.Generic;

namespace DadosAPI.Models
{
    public class NotaSessao
    {
        public List<NotaSessaoConteudo> Conteudo { get; set; }

        public StatusProcessamento StatusProcessamento { get; set; }

        public class NotaSessaoConteudo
        {
            public string SistemaOrigem { get; set; }
            public string Legado { get; set; }
            public string Secao { get; set; }
            public string SecaoDisclaimer { get; set; }
            public int OrdemApresentacaoSecao { get; set; }
            public int IdSequenciaTexto { get; set; }
            public string SubTituloDisclaimer { get; set; }
            public string TextoNota { get; set; }
        }
    }
}