﻿using System;
using System.Collections.Generic;

namespace DadosAPI.Models
{
    public class GraficoHistoricoRendimentoCarteira
    {
        public string Tipo { get; set; }
        public string Periodo { get; set; }
        public decimal ValorSaldo { get; set; }
        public decimal ValorCarteira { get; set; }
        public decimal ValorCDI { get; set; }
        public DateTime dtMesAno { get; set; }


        public List<GraficoHistoricoRendimentoCarteira> LstGrafico { get; set; }

        public StatusSecao StatusSecao { get; set; }
    }
}