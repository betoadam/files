﻿using System.Collections.Generic;

namespace DadosAPI.Models
{
    public class DetalhamentoAcoes
    {
        public string Papel { get; set; }
        public string Descricao { get; set; }
        public string Tipo { get; set; }
        public decimal Quantidade { get; set; }
        public string Cotacao { get; set; }
        public string SaldoBruto { get; set; }

        public StatusSecao StatusSecao { get; set; }
        public List<DetalhamentoAcoes> DetalhamentoAcoesList { get; set; }

    }
}