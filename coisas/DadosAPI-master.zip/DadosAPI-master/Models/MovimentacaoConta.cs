﻿using System;
using System.Collections.Generic;

namespace DadosAPI.Models
{
    public class MovimentacaoConta
    {
        public string TipoLayout { get; set; }
        public List<RendaFixa> LstRendaFixa { get; set; }
        public List<Fundo> LstFundo { get; set; }
        public List<Previdencia> LstPrevidencia { get; set; }
        public List<PrevidenciaSintetica> LstPrevidenciaSintetica { get; set; }
        public StatusProcessamento StatusProcessamento { get; set; }

        public class RendaFixa
        {
            public string SistemaOrigem { get; set; }
            public string Legado { get; set; }
            public int Agencia { get; set; }
            public int Conta { get; set; }
            public string DataReferencia { get; set; }
            public string TipoLayout { get; set; }
            public string TipoHistLancamento { get; set; }
            public string TipoMovimento { get; set; }
            public string NomeGrupoLayout { get; set; }
            public string Ativo { get; set; }
            public string Emissor { get; set; }
            public string DataAplicacao { get; set; }
            public string DataVencimento { get; set; }
            public string DataLancamento { get; set; }
            public string Historico { get; set; }
            public decimal SaldoBruto { get; set; }
            public decimal ValorLiquido { get; set; }
            public int IdentSeqProduto { get; set; }
            public int IdentSeqGrupoProduto { get; set; }
            public int IdentSeqFamilia { get; set; }
            public int QuantidadeOcorrencias { get; set; }
            public string StatusRetorno { get; set; }
            public int IdentNumeroOperacao { get; set; }
            public string IdentOperacaoMovimento { get; set; }

        }

        public class Fundo
        {
            public string SistemaOrigem { get; set; }
            public string Legado { get; set; }
            public int Agencia { get; set; }
            public int Conta { get; set; }
            public string DataReferencia { get; set; }
            public string TipoLayout { get; set; }
            public int TipoHistLancamento { get; set; }
            public string TipoMovimento { get; set; }
            public string NomeGrupoLayout { get; set; }
            public string NomeFundo { get; set; }
            public string CnpjFundo { get; set; }
            public string DataLancamento { get; set; }
            public string Historico { get; set; }
            public decimal ValorCota { get; set; }
            public decimal QtdCota { get; set; }
            public decimal ValorBruto { get; set; }
            public decimal ImpostoPrevisto { get; set; }
            public decimal ValorLiquido { get; set; }
            public int IdentSeqProduto { get; set; }
            public int IdentSeqGrupoProduto { get; set; }
            public int IdentSeqFamilia { get; set; }
            public int QuantidadeOcorrencias { get; set; }
            public int StatusRetorno { get; set; }

        }

        public class Previdencia
        {
            public string SistemaOrigem { get; set; }
            public string Legado { get; set; }
            public int Agencia { get; set; }
            public int Conta { get; set; }
            public string NomeFundo { get; set; }
            public string CnpjFundo { get; set; }
            public string DataReferencia { get; set; }
            public string DataMovimento { get; set; }
            public DateTime DtMovimento { get; set; }
            public string TipoLayout { get; set; }
            public string Certificado { get; set; }
            public string ProcessoSusep { get; set; }
            public string RegimeTributacao { get; set; }
            public decimal Premio { get; set; }
            public decimal Resgate { get; set; }
            public decimal ResgateTributavel { get; set; }
            public decimal IRFF { get; set; }
            public decimal ValorLiquido { get; set; }
            public decimal SaldoBrutoAtual { get; set; }
            public int IdentSeqProduto { get; set; }
            public int IdentSeqGrupoProduto { get; set; }
            public int IdentSeqFamilia { get; set; }
            public int QuantidadeOcorrencias { get; set; }
            public int StatusRetorno { get; set; }
        }

        public class PrevidenciaSintetica
        {
            public string SistemaOrigem { get; set; }
            public string Legado { get; set; }
            public int Agencia { get; set; }
            public int Conta { get; set; }
            public string DataReferencia { get; set; }
            public string TipoLayout { get; set; }
            public int IdentSeqProduto { get; set; }
            public int IdentSeqGrupoProduto { get; set; }
            public int IdentSeqFamilia { get; set; }
            public int QuantidadeOcorrencias { get; set; }
            public int StatusRetorno { get; set; }
        }
    }
}
