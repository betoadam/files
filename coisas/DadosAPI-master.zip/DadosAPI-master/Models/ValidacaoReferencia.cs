﻿namespace DadosAPI.Models
{
    public class ValidacaoReferencia
    {
        public int _validaSegmento { get; set; }
        public string _dataReferencia { get; set; }
        public bool _PosicaoDiaria { get; set; }
        public string _UltimoDiaMes { get; set; }
        public bool _MesNaoFechado { get; set; }
        public string _dataAuxilio { get; set; }
        public string _dataRetorno { get; set; }
    }
    
}