﻿namespace DadosAPI.Models
{
    public class StatusSecao
    {
        public int Code { get; set; }
        public string Message { get; set; }
        public string Service { get; set; }
    }
}