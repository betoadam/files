﻿using System;
using System.Collections.Generic;

namespace DadosAPI.Models
{
    public class IndiceEquivalente
    {
        public List<IndiceEquivalenteConteudo> Conteudo { get; set; }

        public StatusProcessamento StatusProcessamento { get; set; }

        public class IndiceEquivalenteConteudo
        {
            public string SistemaOrigem { get; set; }
            public string Legado { get; set; }
            public int Agencia { get; set; }
            public int Conta { get; set; }
            public string CodIndice { get; set; }
            public string NomeIndice { get; set; }
            public string AnoMesIndice { get; set; }
            public decimal PercRentabilidade { get; set; }
            public string IndAcumulado { get; set; }
            //public string UltimaConhecida { get; set; }
            public string DataUltimoProcessamento { get; set; }
            public string RentOcorrencia { get; set; }
            public string DataRetorno { get; set; }
            public int QuantidadeOcorrencias { get; set; }

            public DateTime dtAnoMesRef { get; set; }
        }
    }
}