﻿namespace DadosAPI.Models
{
    public class IndiceAcumuladoConteudo
    {
        public string SistemaOrigem { get; set; }
        public string Legado { get; set; }
        public int Agencia { get; set; }
        public int Conta { get; set; }
        public int CodRentabilidade { get; set; }
        public int QuantidadeOcorrencias { get; set; }
    }
}