﻿using System;

namespace DadosAPI.Models.GerenciamentoSolicitacao
{
    public abstract class Solicitacao
    {

        public string Token { get; }
        public DateTime Expiracao { get; }

        public Solicitacao()
        {
            Token = Guid.NewGuid().ToString("N");
            Expiracao = DateTime.Now;
        }

        public bool Valida => (DateTime.Now - Expiracao).Minutes <= 5;
    }
}