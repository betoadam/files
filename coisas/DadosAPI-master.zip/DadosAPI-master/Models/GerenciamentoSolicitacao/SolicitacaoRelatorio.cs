﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DadosAPI.Models.GerenciamentoSolicitacao
{
    public class SolicitacaoRelatorio : Solicitacao
    {
        public string Sistema { get; set; }
        public string Legado { get; set; }
        public int Agencia { get; set; }
        public int Conta { get; set; }
        public string DataReferencia { get; set; }
        public string Segmento { get; set; }
        public int Template { get; set; }
        public int Batch { get; set; }
        public string CodigoCliente { get; set; }
        public string CodigoTipoPessoa { get; set; }
        public string UsuarioSolicitante { get; set; }
        public bool PosicaoDiaria { get; set; }

    }
}