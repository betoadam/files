﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DadosAPI.Models.GerenciamentoSolicitacao
{
    public class SolicitacaoTemplate
    {
        public string Nm_Tmpl { get; set; }
        public string Tmpl_Stat { get; set; }
        public string Nm_pag { get; set; }
        public string Pag_Stat { get; set; }
        public string txt_desc_secao { get; set; }
        public string Sec_Stat { get; set; }
    }
}