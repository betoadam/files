﻿using System;
using System.Collections.Generic;

namespace DadosAPI.Models
{
    public class BenchMarkFixo
    {
        public List<BenchmarkFixoConteudo> Conteudo { get; set; }

        public StatusProcessamento StatusProcessamento { get; set; }

        public class BenchmarkFixoConteudo
        {
            public string SistemaOrigem { get; set; }
            public string Legado { get; set; }
            public int Agencia { get; set; }
            public int Conta { get; set; }
            public string TipoEquivalencia { get; set; }
            public string CodIndice { get; set; }
            public string NomeIndice { get; set; }
            public string AnoMesRef { get; set; }
            public decimal PercAcumuladoMes { get; set; }
            public string IndOcorrenciaMes { get; set; }
            public decimal PercAcumuladoAno { get; set; }
            public string IndOcorrenciaAno { get; set; }
            public decimal PerAcumulado12M { get; set; }
            public string IndOcorrencia12M { get; set; }
            public decimal PercAcumulado24M { get; set; }
            public string IndOcorrencia24M { get; set; }
            public decimal PercAcumulado36M { get; set; }
            public string IndOcorrencia36M { get; set; }
            public string DataRetorno { get; set; }
            public string DataUltimoProcessamento { get; set; }
            public int QuantidadeOcorrencias { get; set; }

            public DateTime dtAnoMesRef { get; set; }
        }
    }
}