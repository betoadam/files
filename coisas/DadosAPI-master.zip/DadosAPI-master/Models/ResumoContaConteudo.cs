﻿namespace DadosAPI.Models
{
    public class ResumoContaConteudo
    {
        public string SistemaOrigem { get; set; }

        public string Legado { get; set; }

        public int Agencia { get; set; }

        public int Conta { get; set; }

        public string DataReferencia { get; set; }

        public int CodRentabilidadePai { get; set; }

        public int OrdemApresentacaoPai { get; set; }

        public int CodGrupoProduto { get; set; }

        public string NomeGrupoProduto { get; set; }

        public int OrdemApresentacaoProduto { get; set; }

        public string IndTotalizador { get; set; }

        public decimal SaldoBrutoAnterior { get; set; }

        public string DataSaldoAnterior { get; set; }

        public decimal Resgate { get; set; }

        public decimal ImpostoIncorrido { get; set; }

        public decimal Rendimento { get; set; }

        public decimal SaldoBrutoAtual { get; set; }

        public decimal ImpostoPrevisto { get; set; }

        public decimal SaldoLiquido { get; set; }

        public int QuantidadeOcorrencias { get; set; }
    }
}