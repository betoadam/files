﻿using System.Collections.Generic;

namespace DadosAPI.Models
{
    public class GraficoComposicaoCarteira
    {

        public string Familia { get; set; }
        public decimal Amount { get; set; }
        public string CorFamilia { get; set; }

        public decimal Percentual { get; set; }
        public List<GraficoComposicaoCarteira> LstGrafico { get; set;}

        public StatusSecao StatusSecao { get; set; }
    }
}