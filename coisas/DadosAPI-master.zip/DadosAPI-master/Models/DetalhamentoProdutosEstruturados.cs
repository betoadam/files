﻿using System.Collections.Generic;

namespace DadosAPI.Models
{
    public class DetalhamentoProdutosEstruturados
    {
        public string NomeAtivo { get; set; }
        public string DataAplicacao { get; set; }
        public string Vencimento { get; set; }
        public string SaldoAplicado { get; set; }
        public string SaldoBruto { get; set; }
        public string ImpostosPrevistos { get; set; }
        public string SaldoLiquido { get; set; }

        public StatusSecao StatusSecao { get; set; }
        public List<DetalhamentoProdutosEstruturados> DetalhamentoProdutosEstruturadosList { get; set; }

    }
}