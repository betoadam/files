﻿using System.Collections.Generic;

namespace DadosAPI.Models
{
    public class InvestimentoComposicaoDetalhada
    {
        public string DescricaoProduto { get; set; }
        public string SaldoBrutoMesAnterior { get; set; }
        public string Aplicacao { get; set; }
        public string Resgate { get; set; }
        public string ImpostoIncorrido { get; set; }
        public string Rendimento { get; set;}
        public string SaldoBrutoMesAtual { get; set; }
        public string ImpostoPrevisto { get; set; }
        public string SaldoLiquido { get; set; }
        public string DataRetorno { get; set; }
        public string DataSaldoAnterior { get; set; }
        public string DataReferencia { get; set; }
        public int CodGrupoProduto { get; set; }
        public int? IdentSeqFamilia { get; set; }
        public int? IdentSeqGrupoProduto { get; set; }
        public int? IdentSeqProduto { get; set; }
        public string IsBold { get; set; }

        public StatusSecao StatusSecao { get; set; }

        public List<InvestimentoComposicaoDetalhada> InvestimentoComposicaoDetalhadaList { get; set; }

    }
}