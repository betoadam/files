﻿namespace DadosAPI.Models
{
    public class Report
    {
        public ContaCorrente ContaCorrenteExtrato { get; set; }
        public PosicaoInvestimentos PosicaoInvestimentos { get; set; }
        public InvestimentoComposicaoDetalhada InvestimentoComposicaoDetalhada { get; set; }
        public InvestimentoComposicaoDetalhada InvestimentoComposicaoDetalhadaCorretora { get; set; }
        public RendimentoHistoricoCarteira RendimentoHistoricoCarteira { get; set; }
        public RendimentoHistoricoIndiceMercado RendimentoHistoricoIndiceMercado { get; set; }
        public RendimentoHistoricoProdutos RendimentoHistoricoProdutosMercado { get; set; }
        public PosicaoInvestimentosCarteira PosicaoInvestimentosCarteira { get; set; }
        public NotaSessao NotaSessao { get; set; }
        public DetalhamentoFundosInvestimento DetalhamentoFundosInvestimento { get; set; }
        public DetalhamentoAtivosRendaFixa DetalhamentoAtivosRendaFixa { get; set; }
        public DetalhamentoAcoes DetalhamentoAcoes { get; set; }
        public DetalhamentoProdutosEstruturados DetalhamentoProdutosEstruturados { get; set; }
        public DetalhamentoDerivativo DetalhamentoDerivativo { get; set; }
        public DetalhamentoPoupanca DetalhamentoPoupanca { get; set; }
        public string Sistema { get; set; }
        public string Legado { get; set; }
        public string Agencia { get; set; }
        public string Conta { get; set; }
        public string DataReferencia { get; set; }
        public string Segmento { get; set; }
        public string DataPosicao { get; set; }
        public string DataApresentacao { get; set; }
        public string UsuarioSolicitante { get; set; }
        public bool PosicaoDiaria { get; set; }
        public string ReferenciaRelatorio { get; set; }
        public bool ComHeader { get; set; }
        public bool ComFooter { get; set; }
        public string TituloPagina { get; set; }
        public string SubtituloPagina { get; set; }
        public string ContaCorrente { get; set; }
        public int Template { get; set; }
    }
}