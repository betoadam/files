﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using DadosAPI.Models;

namespace DadosAPI.Models
{    
    [Table("PRVT074_SECAO")]

    public class Secao
    {
        [Key]
        [Column("CD_SECAO")]
        public int CD_SECAO { get; set;}
                
        [Column("TXT_DESC_SECAO")]
        public string TXT_DESC_SECAO { get; set; }
        
        [Column("IC_STAT")]
        public string IC_STAT { get; set; }
        
        public List<AtributoSecao> Atributos { get; set; } = new List<AtributoSecao>();

        public bool Ativo => IC_STAT == "A";
    }
}
