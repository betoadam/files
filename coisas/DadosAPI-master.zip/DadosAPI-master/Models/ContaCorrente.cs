using System;
using System.Collections.Generic;

namespace DadosAPI.Models
{
    public class ContaCorrente
    {
        public string TipoLayout { get; set; }
        public List<MovimentacaoContaCorrente> LstMovimentacaoContaCorrente { get; set; }
        public List<RelacionamentoCliente> LstRelacionamentoCliente { get; set; }
        public List<SaldoContaCorrente> LstSaldoContaCorrente { get; set; }
        public StatusProcessamento StatusProcessamento { get; set; }

        public class MovimentacaoContaCorrente
        {
            public string SistemaOrigem { get; set; }
            public string Legado { get; set; }
            public int Agencia { get; set; }
            public int Conta { get; set; }
            public string AnoMesReferencia { get; set; }
            public string TipoLayout { get; set; }
            public string DataMovimento { get; set; }
            public DateTime DtMovimento { get; set; }
            public string DescricaoMovimento { get; set; }
            public string SequenciaApresentacao { get; set; }
            public string AgenciaSegmentada { get; set; }
            public int QuantidadeOcorrencias { get; set; }
            public string StatusRetorno { get; set; }
            public string NumeroDocumento { get; set; }
            public decimal ValorMovimento { get; set; }
            public decimal SaldoAtualizado { get; set; }

        }

        public class RelacionamentoCliente
        {
            public string SistemaOrigem { get; set; }
            public string Legado { get; set; }
            public int Agencia { get; set; }
            public int Conta { get; set; }
            public string AnoMesReferencia { get; set; }
            public string TipoLayout { get; set; }
            public string IdentificadorProdutoCredito { get; set; }
            public string DescricaoProdutoCredito { get; set; }
            public decimal ValorLimite { get; set; }
            public string DataVctoLimite { get; set; }
            public string TaxaEfetivaMes { get; set; }
            public string TaxaEfetivaAno { get; set; }
            public string TaxaCustoEfetivoTotalMes { get; set; }
            public string TaxaCustoEfetivoTotalAno { get; set; }
            public int QuantidadeOcorrencias { get; set; }
            public string StatusRetorno { get; set; }

        }

        public class SaldoContaCorrente
        {
            public string SistemaOrigem { get; set; }
            public string Legado { get; set; }
            public int Agencia { get; set; }
            public int Conta { get; set; }
            public string AnoMesReferencia { get; set; }
            public string TipoLayout { get; set; }
            public string AgenciaSegmentada { get; set; }
            public string TipoSaldo { get; set; }
            public string DescricaoTipoSaldo { get; set; }
            public decimal ValorSaldo { get; set; }
            public int QuantidadeOcorrencias { get; set; }
            public string StatusRetorno { get; set; }

        }
    }
}