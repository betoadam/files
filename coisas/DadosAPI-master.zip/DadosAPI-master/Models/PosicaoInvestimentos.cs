﻿using System.Collections.Generic;

namespace DadosAPI.Models
{
    public class PosicaoInvestimentos
    {
        public string Resumo { get; set; }
        public string SaldoBrutoPatrimonio { get; set; }
        public string ImpostoPatrimonio { get; set; }
        public string SaldoLiquidoPatrimonio { get; set; }
        public decimal PLPercentual { get; set; }
        public string RentMes { get; set; }
        public string RentAno { get; set; }
        public string Rent12Meses { get; set; }
        public string Rent24Meses { get; set; }
        public string Rent36Meses { get; set; }
        public int CodGrupoProduto { get; set; }
        public int? IdentSeqFamilia { get; set; }
        public int? IdentSeqGrupoProduto { get; set; }
        public int? IdentSeqProduto { get; set; }
        public string IsBold { get; set; }

        public StatusSecao StatusSecao { get; set; }

        public List<PosicaoInvestimentos> PosicaoInvestimentosList { get; set; }
    }
}
