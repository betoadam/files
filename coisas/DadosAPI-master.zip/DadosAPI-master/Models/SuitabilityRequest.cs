﻿using System.Text;

namespace DadosAPI.Models {
    public class SuitabilityRequest {
        public string UserId { get; set; } = "";
        public int CodCcl { get; set; }
        public int CodAge { get; set; }
        public int CodCc { get; set; }
        public int CpfCnpj { get; set; }
        public string TipoPes { get; set; } = "";
        public string TipoOper { get; set; } = "A";
        public decimal VlrOper { get; set; } = 1000000;
        public string SinalOper { get; set; } = "+";
        public string Produto { get; set; } = "CSA";
        public string Papel { get; set; } = "";
        public string Idx { get; set; } = "";
        public long CnpjEmir { get; set; }
        public decimal VlrExpos { get; set; }
        public string SinalExpos { get; set; } = "";
        public decimal VlrMtm { get; set; }
        public string SinalMtm { get; set; } = "";
        public int CodProd { get; set; }
        public int CodIdxr { get; set; }

        public string ObterSerializacao () {
            var sb = new StringBuilder ();

            sb.Append ("2048");
            sb.Append ("GCA");
            sb.Append (UserId.PadRight (8, ' '));
            sb.Append (CodCcl.ToString ().PadLeft (9, '0'));
            sb.Append (CodAge.ToString ().PadLeft (5, '0'));
            sb.Append (CodCc.ToString ().PadLeft (7, '0'));
            sb.Append (CpfCnpj.ToString ().PadLeft (15, '0'));
            sb.Append (TipoPes.PadRight (1, ' '));
            sb.Append (TipoOper.PadRight (1, ' '));
            sb.Append (VlrOper.ToString ().PadLeft (17, '0'));
            sb.Append (SinalOper);
            sb.Append (Produto.PadRight (3, ' '));
            sb.Append (Papel.PadRight (20, ' '));
            sb.Append (Idx.PadRight (20, ' '));
            sb.Append (CnpjEmir.ToString ().PadLeft (15, '0'));
            sb.Append (VlrExpos.ToString ().PadLeft (17, '0'));
            sb.Append (SinalExpos.PadRight (1, ' '));
            sb.Append (VlrMtm.ToString ().PadLeft (17, '0'));
            sb.Append (SinalMtm.PadRight (1, ' '));
            sb.Append (CodProd.ToString ().PadLeft (9, '0'));
            sb.Append (CodIdxr.ToString ().PadLeft (9, '0'));
            sb.Append ("".PadLeft (126, ' '));

            return sb.ToString ();
        }

    }
}