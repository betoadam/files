﻿using System;

namespace DadosAPI.Models
{
    public class Suitability
    {
        public string DescricaoPerfilCliente { get; set; }
        public string DescricaoPerfilPortfolio { get; set; }
        public string IndicadorPerfilCliente { get; set; }
        public string IndicadorPerfilPortfolio { get; set; }
        public string Enquadramento { get; set; }
        public DateTime? DataVencimentoCadastro { get; set; }
    }
}
