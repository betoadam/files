﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DadosAPI.Models
{
    [Table("PRVT079_CE_ATRI_SECAO")]
    public class AtributoSecao
    {
        // [Key]
        [Column("CD_SECAO")]
        public int CD_SECAO { get; set; }

        // [Key]
        [Column("SGL_SIST_ORIG")]
        public string SGL_SIST_ORIG { get; set; }

        // [Key]
        [Column("ID_ATRI_SECAO")]
        public string ID_ATRI_SECAO { get; set; }

        [Column("IC_STAT_ATRI_SECAO")]
        public string IC_STAT_ATRI_SECAO { get; set; }

        public bool Ativo => IC_STAT_ATRI_SECAO == "A";
    }
}
