﻿namespace DadosAPI.Models
{
    public class PosicaoInvestimentosCarteira
    {
        public string Resumo { get; set; }
        public string SaldoBrutoPatrimonio { get; set; }
        public string ImpostoPatrimonio { get; set; }
        public string ImpostoPrevisto { get; set; }
        public string SaldoLiquidoPatrimonio { get; set; }
        public string PLPercentual { get; set; }
        public string RendMes { get; set; }
        public string RentMes { get; set; }
        public string CDIMes { get; set; }
        public string RendAno { get; set; }
        public string RentAno { get; set; }
        public string CDIAno { get; set; }
        public string Rend12Meses { get; set; }
        public string Rent12Meses { get; set; }
        public string CDI12Meses { get; set; }
        public string Rend24Meses { get; set; }
        public string Rent24Meses { get; set; }
        public string CDI24Meses { get; set; }
        public string Rend36Meses { get; set; }
        public string Rent36Meses { get; set; }
        public string CDI36Meses { get; set; }
        public string IndElegivelAno { get; set; }
        public string IndElegivel12M { get; set; }
        public string IndElegivel24M { get; set; }
        public string IndElegivel36M { get; set; }
        public string DtInicio { get; set; }
        public string DtTermino { get; set; }
        public string DtPosicao { get; set; }
        public StatusSecao StatusSecao { get; set; }

        //public List<PosicaoInvestimentosCarteira> PosicaoInvestimentosCarteiralList { get; set; }


        public bool ApresentarANO => Equals(IndElegivelAno, "S");
        public bool Apresentar24Meses => Equals(IndElegivel24M, "S");
        public bool Apresentar36Meses => Equals(IndElegivel36M, "S");

        // public bool Apresentar24Meses => PosicaoInvestimentosCarteiralList.FirstOrDefault(x => bool.Parse(x.IndElegivel24M))?.IndElegivel24M == "S";
        //  public bool Apresentar36Meses => PosicaoInvestimentosCarteiralList.FirstOrDefault(x => bool.Parse(x.IndElegivel36M))?.IndElegivel36M == "S";


    }
}