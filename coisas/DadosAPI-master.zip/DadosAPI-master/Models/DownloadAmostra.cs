namespace DadosAPI.Models
{
    public class DownloadAmostra
    {
        public string Sistema { get; set; }
        public string Legado { get; set; }
        public string Agencia { get; set; }
        public double Conta { get; set; }
        public string DataReferencia { get; set; }
        public string Template { get; set; }
        public double Segmento { get; set; }
        public string CodigoCliente { get; set; }
        public string CodigoTipoPessoa { get; set; }
        public double UsuarioSolicitacao { get; set; }

    }
}