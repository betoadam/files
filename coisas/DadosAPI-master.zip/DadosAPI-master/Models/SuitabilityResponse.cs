﻿using System;
using System.Text;

namespace DadosAPI.Models {
    public class SuitabilityResponse {
        public string PerfilCliente { get; set; }
        public string PerfilPortfolio { get; set; }
        public string SituacaoSuitability { get; set; }
        public string SituacaoCadastro { get; set; }
        public string DataVencimentoCadastro { get; set; }
        public string IndicadorCliente { get; set; }
        public string IndicadorPortfolio { get; set; }

        public void Preencher (string mensagem) {

            Func<int, string> slice = (length) => {
                var sb = new StringBuilder ();

                while (sb.Length < length) {
                    sb.Append (mensagem[0]);
                    mensagem = mensagem.Remove (0, 1);
                }

                return sb.ToString ().Trim ();
            };

            string t = "";

            PerfilCliente = slice (50);
            PerfilPortfolio = slice (50);
            SituacaoSuitability = slice (50);
            SituacaoCadastro = slice (50);
            DataVencimentoCadastro = slice (10);
            IndicadorCliente = slice (1);
            t = slice (1);
            IndicadorPortfolio = slice (1);
        }

    }
}