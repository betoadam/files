using System;
using System.IO;
using System.Reflection;
using DadosAPI.Oracle;
using DadosAPI.Services;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.OpenApi.Models;

namespace DadosAPI {
    public class Startup {
        public Startup (IConfiguration configuration) {
            Configuration = configuration;
            AppConfig.Configuration = configuration;
        }
        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.

        public void ConfigureServices (IServiceCollection services) {
            services.AddCors (options => {
                options.AddPolicy ("Default", builder => {
                    builder.AllowAnyOrigin ();
                    builder.AllowAnyMethod ();
                    builder.AllowAnyHeader ();
                });
            });

            services.AddDbContext<DatabaseContext> (opt =>
                opt.UseOracle (
                    Configuration.GetConnectionString ("DefaultConnection"),
                    options => options
                    .UseOracleSQLCompatibility ("11")));

            services.AddMvc ();
            services.AddSingleton<IConfiguration> (Configuration);
            services.AddScoped<RelatorioService> ();
            services.AddScoped<PrivateService> ();

            services.AddScoped<ContaCorrenteService> ();
            services.AddScoped<ValidaReferenciaService> ();
            services.AddScoped<ComposicaoCarteiraService> ();
            services.AddScoped<DetalhamentoAcoesService> ();
            services.AddScoped<DetalhamentoAtivosRendaFixaService> ();
            services.AddScoped<DetalhamentoFundosInvestimentoService> ();
            services.AddScoped<DetalhamentoProdutosEstruturadosService> ();
            services.AddScoped<DetalharPoupancaService> ();
            services.AddScoped<InvestimentoComposicaoDetalhadaService> ();
            services.AddScoped<InvestimentoComposicaoDetalhadaCorretoraService> ();
            services.AddScoped<PosicaoInvestimentosService> ();
            services.AddScoped<RendimentoHistoricoCarteiraService> ();
            services.AddScoped<RendimentoHistoricoIndiceMercadoService> ();
            services.AddScoped<RendimentoHistoricoProdutosService> ();

            services.AddScoped<GraficoCompCarteiraService> ();
            services.AddScoped<GraficoRendHistoricoService> ();
            services.AddScoped<GraficoSuitabilityService> ();

            services.AddSwaggerGen (c => {
                c.SwaggerDoc ("v1", new OpenApiInfo {
                    Version = "v1",
                        Title = "API de Dados",
                        Description = "API de Dados Utilizada para gerar os Relatórios de Extrato Private"
                });

                var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
                var xmlPath = Path.Combine (AppContext.BaseDirectory, xmlFile);
                c.IncludeXmlComments (xmlPath);
            });
        }

        public void Configure (IApplicationBuilder app, IHostingEnvironment env) {
            if (env.IsDevelopment ()) {
                app.UseDeveloperExceptionPage ();
            }

            app.UseSwagger ();

            // Enable middleware to serve swagger-ui (HTML, JS, CSS, etc.),
            // specifying the Swagger JSON endpoint.
            app.UseSwaggerUI (c => {
                c.SwaggerEndpoint ("/swagger/v1/swagger.json", "My API V1");
            });

            //app.UseCors("Default");
            app.UseCors (x => x
                .AllowAnyOrigin ()
                .AllowAnyMethod ()
                .AllowAnyHeader ());
            app.UseMvc ();
        }
    }
}