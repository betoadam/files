﻿using System;

namespace DadosAPI.Extensions
{
    public static class FunctionalExtensions
    {
        public static TResult ReduceIf<T, TResult>(this T obj, Func<T, bool> predicate, Func<T, TResult> selector)
        {

            return ReduceIf(obj, predicate.Invoke(obj), selector);
        }

        public static TResult ReduceIf<T, TResult>(this T obj, bool condition, Func<T, TResult> selector)
        {
            if (!condition)
                return default(TResult);

            return Reduce(obj, selector);
        }

        public static TResult Reduce<T, TResult>(this T obj, Func<T, TResult> selector)
        {
            return selector.Invoke(obj);
        }

    }
}
