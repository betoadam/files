﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DadosAPI.Extensions
{
    public static class LinqExtensions
    {
        public static bool In<T>(this T obj, params T[] values)
        {
            return values.Any(x => x.Equals(obj));
        }
    }
}
