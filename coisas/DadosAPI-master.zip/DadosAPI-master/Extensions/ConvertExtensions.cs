﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DadosAPI.Extensions
{
    public static class ConvertExtensions
    {
        public static DateTime? ToDateTime(this string value, string format = "dd/MM/yyyy")
        {
            if (string.IsNullOrEmpty(value) || string.IsNullOrWhiteSpace(value))
                return default(DateTime?);

            var r = default(DateTime);
            DateTime.TryParseExact(value, format, CultureInfo.InvariantCulture, DateTimeStyles.None, out r);
            return r;
        }
    }
}
