﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DadosAPI.Extensions
{
    public static class InlineExtensions
    {
        public static T OutIf<T>(this T value, Func<T, bool> predicate, T newValue)
        {
            return OutIf(value, predicate.Invoke(value), newValue);
        }

        public static TInput RunIf<TInput>(this TInput input, bool condition, Action<TInput> thenAction, Action<TInput> elseAction = null)
        {
            if (input == null)
                return input;

            if (condition)
                thenAction.Invoke(input);
            else
                elseAction?.Invoke(input);

            return input;
        }

        public static TInput RunIf<TInput>(this TInput input, Func<TInput, bool> predicate, Action<TInput> thenAction, Action<TInput> elseAction = null)
        {
            if (input == null)
                return input;

            return RunIf(input, predicate.Invoke(input), thenAction, elseAction);
        }

        public static TInput Run<TInput>(this TInput input, Action<TInput> transformation)
        {
            if (input == null)
                return input;

            transformation.Invoke(input);

            return input;
        }

        public static T OutIf<T>(this T value, Func<T, bool> predicate, Func<T, T> newValue)
        {
            return OutIf(value, predicate.Invoke(value), newValue.Invoke(value));
        }

        public static T OutIf<T>(this T value, bool condition, T newValue)
        {
            if (condition)
                return newValue;

            return value;
        }

        public static T SetIf<T>(this T value, T valueComparer, T newValue)
        {
            if (value == null)
                return value;

            return OutIf(value, value.Equals(valueComparer), newValue);
        }
    }
}
