﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;
using System.Threading.Tasks;

namespace DadosAPI.Extensions
{
    public static class StringExtensions
    {
        public static string Slice(this string input, int length)
        {
            var charsList = input.ToList();
            var sb = new StringBuilder();

            while (sb.Length < length)
            {
                sb.Append(charsList[0]);
                charsList.RemoveAt(0);
            }

            return sb.ToString();
        }

        public static bool InValue<T>(this T item, params T[] items)
        {
            if (items == null)
                throw new ArgumentNullException("items");

            return items.Contains(item);
        }

        public enum DataFormat
        {
            UsFormat,
            BRFormat,
            MesBarraAno,
            AnoMes,
            AnoMesDia
        }

        public static string FormatDataString(this string strData, DataFormat dataFormato)
        {
            string strRetorno = "Data inválida!";

            try
            {
                DateTime date = DateTime.Parse(strData);

                if (dataFormato == DataFormat.BRFormat)
                    strRetorno = date.Date.ToString("dd/MM/yyyy");
                else if (dataFormato == DataFormat.UsFormat)
                    strRetorno = date.Date.ToString("MM/dd/yyyy");
                else if (dataFormato == DataFormat.MesBarraAno)
                    strRetorno = date.Date.ToString("MM/yyyy");
                else if (dataFormato == DataFormat.AnoMes)
                    strRetorno = date.Date.ToString("yyyyMM");
                else if (dataFormato == DataFormat.AnoMesDia)
                    strRetorno = date.Date.ToString("yyyyMMdd");
            }
            catch
            {
                return strRetorno;
            }
            return strRetorno;
        }

        /// <summary>
        /// Levenshtein distance
        /// </summary>
        public static int GetDistanceFrom(this string s, string t)
        {
            //Normalize
            s = s.ToLower().Trim().Replace(" ", "");
            t = t.ToLower().Trim().Replace(" ", "");

            //Remove accents
            s = new string(s.Normalize(NormalizationForm.FormD).Where(ch => char.GetUnicodeCategory(ch) != UnicodeCategory.NonSpacingMark).ToArray());

            t = new string(t.Normalize(NormalizationForm.FormD).Where(ch => char.GetUnicodeCategory(ch) != UnicodeCategory.NonSpacingMark).ToArray());

            int n = s.Length;
            int m = t.Length;
            int[,] d = new int[n + 1, m + 1];

            // Step 1
            if (n == 0)
            {
                return m;
            }

            if (m == 0)
            {
                return n;
            }

            // Step 2
            for (int i = 0; i <= n; d[i, 0] = i++)
            {
            }

            for (int j = 0; j <= m; d[0, j] = j++)
            {
            }

            // Step 3
            for (int i = 1; i <= n; i++)
            {
                //Step 4
                for (int j = 1; j <= m; j++)
                {
                    // Step 5
                    int cost = (t[j - 1] == s[i - 1]) ? 0 : 1;

                    // Step 6
                    d[i, j] = Math.Min(
                        Math.Min(d[i - 1, j] + 1, d[i, j - 1] + 1),
                        d[i - 1, j - 1] + cost);
                }
            }
            // Step 7
            return d[n, m];
        }

    }
}
