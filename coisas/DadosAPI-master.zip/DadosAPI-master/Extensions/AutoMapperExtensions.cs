﻿
namespace DadosAPI.Extensions
{
    public static class AutoMapperExtensions
    {
        // private static readonly IMapper _mapper;

        // static AutoMapperExtensions()
        // {
        //     var config = new MapperConfiguration(cfg =>
        //     {
        //         cfg.CreateMissingTypeMaps = true;
        //     });

        //     _mapper = config.CreateMapper();
        // }

        // public static TDestination MapTo<TDestination>(this object obj)
        // {
        //     return _mapper.Map<TDestination>(obj);
        // }
    }
}
