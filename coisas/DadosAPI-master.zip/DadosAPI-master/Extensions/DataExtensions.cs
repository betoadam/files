﻿using System;
using System.Data;

namespace DadosAPI.Extensions
{
    public static class DataExtensions
    {
        public static DbType ToDbType(this object obj)
        {
            if (obj == null)        return DbType.String;
            if (obj is string)      return DbType.String;
            if (obj is DateTime)    return DbType.Date;
            if (obj is long)        return DbType.Int64;
            if (obj is int)         return DbType.Int32;
            if (obj is short)       return DbType.Int16;
            if (obj is sbyte)       return DbType.Byte;
            if (obj is decimal)     return DbType.Decimal;
            if (obj is float)       return DbType.Single;
            if (obj is double)      return DbType.Double;
            if (obj is byte[])      return DbType.Byte;

            return DbType.String;
        }
    }
}
