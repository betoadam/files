﻿using System.Collections.Generic;
using System.Linq;

namespace DadosAPI.Dtos
{
    public class TransferRow<T1, T2>
    {
        public List<KeyValuePair<T1, T2>> Members { get; private set; } = new List<KeyValuePair<T1, T2>>();

        public TransferRow<T1, T2> Set(T1 key, T2 value)
        {
            var i = Members.FindIndex(x => x.Key.Equals(key));

            var v = new KeyValuePair<T1, T2>(key, value);

            if (i == -1)
                Members.Add(v);
            else
                Members[i] = v;

            return this;
        }

        public T2 Get(T1 key)
        {
            return Members.FirstOrDefault(x => x.Key.Equals(key)).Value;
        }
    }
}
