using System;
using DadosAPI.Models;
using DadosAPI.Models.DadosAPI;
using Microsoft.EntityFrameworkCore;

namespace DadosAPI.Oracle
{
    public class DatabaseContext : DbContext
    {
        public DatabaseContext(DbContextOptions<DatabaseContext> options)
            : base(options)
        {
        }

        public DbSet<Prvt014> Prvt014 { get; set; }
        public DbSet<Prvt071> Prvt071 { get; set; }
        public DbSet<Prvv071> Prvv071 { get; set; }
        public DbSet<Prvt073> Prvt073 { get; set; }
        public DbSet<Secao> Secao { get; set; }
        public DbSet<Prvt075> Prvt075 { get; set; }
        public DbSet<Prvt076> Prvt076 { get; set; }
        public DbSet<Prvt078> Prvt078 { get; set; }
        public DbSet<AtributoSecao> AtributoSecao { get; set; }
        public DbSet<Prvt086> Prvt086 { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder) {
            modelBuilder.HasDefaultSchema("SYSTEM");

            modelBuilder.Entity<AtributoSecao>()
                .HasKey(c => new { c.CD_SECAO, c.SGL_SIST_ORIG, c.ID_ATRI_SECAO });

            // modelBuilder.Entity<Prvt112CeProm>()
            //     .HasKey(c => new { c.CdAg, c.IdNumCc, c.AmRef });

            // modelBuilder.Entity<Prvt115ClienteExtrato>()
            //     .HasKey(c => new { c.CdAg, c.IdNumCc, c.CdAgSeg, c.CdCclCli });

            // modelBuilder.Entity<Prvt116ChvCript>()
            //     .HasKey(c => new { c.CdAg, c.IdNumCc, c.NmArq, c.IdVsDoc });
            //modelBuilder.Entity<User>().ToTable("USER_LOGINS","SYSTEM");

            // modelBuilder.Entity<User>().HasKey(x=> new{x.id});
            // modelBuilder.Entity<User>().Property("Login").HasColumnName("LOGIN");
            // modelBuilder.Entity<User>().Property("Grupo").HasColumnName("GRUPO");
            // modelBuilder.Entity<User>().Property("id").HasColumnName("ID");
        }

        [DbFunction("PRVPF_CALC_DATA_UTIL")]
        public static string PrvpfCalcDataUtil(string dataFechamento, int? qtd)
        {
            throw new Exception("Falha na execução da função");
        }
    }
}