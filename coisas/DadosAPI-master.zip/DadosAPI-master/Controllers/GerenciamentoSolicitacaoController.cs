using System;
using DadosAPI.Common;
using DadosAPI.Models.GerenciamentoSolicitacao;
using Microsoft.AspNetCore.Mvc;

namespace DadosAPI.Controllers {
    public class GerenciamentoSolicitacaoController : ControllerBase {
        [HttpPost]
        public ActionResult SolicitarRelatorio (SolicitacaoRelatorio model) {
            try {
                //Armazaena a solicitação na Session
                GerenciamentoSolicitacao.RegistrarSolicitacao (model);

                //Retorna o token para a aplicação cliente
                return Ok (new { token = model.Token });
            } catch (Exception e) {
                return BadRequest (e);
            }
        }

        [HttpPost]
        public ActionResult ValidarSolicitacao (string token) {
            try {
                //Armazaena a solicitação na Session
                var solicitacao = GerenciamentoSolicitacao.ValidarSolicitacao (token);

                //Retorna o token para a aplicação cliente
                return Ok (solicitacao);
            } catch (Exception e) {
                return BadRequest (e);
            }
        }

        public ActionResult View () {
            try {
                SolicitacaoRelatorio obj = new SolicitacaoRelatorio ();

                return Ok (obj);
            } catch (Exception e) {
                return BadRequest (e);
            }
        }
    }
}