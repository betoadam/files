﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using DadosAPI.Extensions;
using DadosAPI.Models;
using DadosAPI.Models.GerenciamentoSolicitacao;
using DadosAPI.Oracle;
using DadosAPI.Services;
using DadosAPI.Common;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace DadosAPI.Controllers {

    [ApiController]
    [Route ("api/report")]
    public class ReportController : ControllerBase {

        private readonly IConfiguration _configuration;
        private readonly DatabaseContext _context;
        private readonly ILogger<ReportController> _logger;
        private readonly RelatorioService _service;
        private readonly ComposicaoCarteiraService _composicaoCarteiraService;
        private readonly DetalhamentoAcoesService _detalhamentoAcoesService;
        private readonly DetalhamentoAtivosRendaFixaService _detalhamentoAtivosRendaFixaService;
        private readonly DetalhamentoFundosInvestimentoService _detalhamentoFundosInvestimentoService;
        private readonly DetalhamentoProdutosEstruturadosService _detalhamentoProdutosEstruturadosService;
        private readonly DetalharPoupancaService _detalharPoupancaService;
        private readonly InvestimentoComposicaoDetalhadaService _investimentoComposicaoDetalhadaService;
        private readonly InvestimentoComposicaoDetalhadaCorretoraService _investimentosComposicaoDetalhadaCorretora;
        private readonly PosicaoInvestimentosService _posicaoInvestimentosService;
        private readonly PrivateService _privateService;
        private readonly RelatorioService _relatorioService;
        private readonly RendimentoHistoricoCarteiraService _rendimentoHistoricoCarteiraService;
        private readonly RendimentoHistoricoIndiceMercadoService _rendimentoHistoricoIndiceMercadoService;
        private readonly RendimentoHistoricoProdutosService _rendimentoHistoricoProdutosService;
        private readonly ValidaReferenciaService _validaReferenciaService;
        private readonly GraficoCompCarteiraService _graficoCompCarteiraService;
        private readonly GraficoRendHistoricoService _graficoRendHistoricoService;
        private readonly GraficoSuitabilityService _graficoSuitabilityService;
        private readonly ContaCorrenteService _contaCorrenteService;

        public ReportController (
            DatabaseContext context,
            ILogger<ReportController> logger,
            IConfiguration configuration,
            RelatorioService service,
            PrivateService privateService,
            ComposicaoCarteiraService composicaoCarteiraService,
            DetalhamentoAcoesService detalhamentoAcoesService,
            DetalhamentoAtivosRendaFixaService detalhamentoAtivosRendaFixaService,
            DetalhamentoFundosInvestimentoService detalhamentoFundosInvestimentoService,
            DetalhamentoProdutosEstruturadosService detalhamentoProdutosEstruturadosService,
            DetalharPoupancaService detalharPoupancaService,
            InvestimentoComposicaoDetalhadaService investimentoComposicaoDetalhadaService,
            InvestimentoComposicaoDetalhadaCorretoraService investimentosComposicaoDetalhadaCorretora,
            PosicaoInvestimentosService posicaoInvestimentosService,
            RelatorioService relatorioService,
            RendimentoHistoricoCarteiraService rendimentoHistoricoCarteiraService,
            RendimentoHistoricoIndiceMercadoService rendimentoHistoricoIndiceMercadoService,
            RendimentoHistoricoProdutosService rendimentoHistoricoProdutosService,
            ValidaReferenciaService validaReferenciaService,
            GraficoCompCarteiraService graficoCompCarteiraService,
            GraficoRendHistoricoService graficoRendHistoricoService,
            GraficoSuitabilityService graficoSuitabilityService,
            ContaCorrenteService contaCorrenteService
        ) {
            _context = context;
            _configuration = configuration;
            _logger = logger;
            _service = service;
            _privateService = privateService;
            _composicaoCarteiraService = composicaoCarteiraService;
            _detalhamentoAcoesService = detalhamentoAcoesService;
            _detalhamentoAtivosRendaFixaService = detalhamentoAtivosRendaFixaService;
            _detalhamentoFundosInvestimentoService = detalhamentoFundosInvestimentoService;
            _detalhamentoProdutosEstruturadosService = detalhamentoProdutosEstruturadosService;
            _detalharPoupancaService = detalharPoupancaService;
            _investimentoComposicaoDetalhadaService = investimentoComposicaoDetalhadaService;
            _investimentosComposicaoDetalhadaCorretora = investimentosComposicaoDetalhadaCorretora;
            _posicaoInvestimentosService = posicaoInvestimentosService;
            _relatorioService = relatorioService;
            _rendimentoHistoricoCarteiraService = rendimentoHistoricoCarteiraService;
            _rendimentoHistoricoIndiceMercadoService = rendimentoHistoricoIndiceMercadoService;
            _rendimentoHistoricoProdutosService = rendimentoHistoricoProdutosService;
            _validaReferenciaService = validaReferenciaService;
            _contaCorrenteService = contaCorrenteService;
            _graficoCompCarteiraService = graficoCompCarteiraService;
            _graficoRendHistoricoService = graficoRendHistoricoService;
            _graficoSuitabilityService = graficoSuitabilityService;
        }

        private string MascararConta (string str) {
            str = str.Replace ("-", "");

            var sb = new StringBuilder ();

            for (var i = 0; i < str.Length; i++) {
                if (str.Length - i <= 3)
                    sb.Append (str[i]);
                else
                    sb.Append ('X');
            }

            str = sb.ToString ();

            return str.ToUpper ().Insert (str.Length - 1, "-");
        }

        /// <summary>
        /// Gera todos os dados utilizados no relatório.
        /// </summary>
        /// <remarks>
        /// Sample request:
        ///
        ///     POST /api/report
        ///     {
        ///         "sistema": "EXT",
        ///         "legado": "EXT",
        ///         "agencia": 11500,
        ///         "conta": 51385,
        ///         "dataReferencia": "20191024",
        ///         "Template": "1",
        ///         "segmento": "22",
        ///         "CodigoCliente": "4135305",
        ///         "CodigoTipoPessoa": "0007",
        ///         "UsuarioSolicitante": "AUTOMAT"
        ///     }
        ///
        /// </remarks>
        [HttpPost]
        public async Task<ActionResult> Post (SolicitacaoRelatorio solicitacao) {
            try {
                NotaSessao _NotaSessao;

                if (solicitacao == null)
                    throw (new Exception ("Solicitação não encontrada."));

                var _cdTmpl = solicitacao.Template;
                // var _cdTmpl = 1;

                List<SolicitacaoTemplate> lstSolicitacao = new List<SolicitacaoTemplate> ();

                lstSolicitacao = _service.ObterPaginasTemplate (_cdTmpl);

                #region ValidaDataReferencia
                var retornoValidaDataReferencia = _validaReferenciaService.GetData (solicitacao);

                var _validaSegmento = retornoValidaDataReferencia._validaSegmento;

                solicitacao.PosicaoDiaria = retornoValidaDataReferencia._PosicaoDiaria;
                var _dataRetorno = retornoValidaDataReferencia._dataRetorno;
                #endregion

                Report report = new Report ();
                List<NotaSessao.NotaSessaoConteudo> lstNotas = new List<NotaSessao.NotaSessaoConteudo> ();

                report.Sistema = solicitacao.Sistema;
                report.Legado = solicitacao.Legado;
                report.Agencia = solicitacao.Agencia.ToString ();
                report.Conta = solicitacao.Conta.ToString ();
                report.DataReferencia = retornoValidaDataReferencia._dataReferencia;
                report.Segmento = solicitacao.Segmento;
                report.Template = solicitacao.Template;

                foreach (var item in lstSolicitacao) {
                    if (item.Nm_pag == "Composição da Carteira") {
                        if (item.txt_desc_secao == "Resumo Carteira") {
                            report.PosicaoInvestimentosCarteira = await _composicaoCarteiraService.GetData (solicitacao);

                            NotaSessao nota;

                            #region SecNotaCompCarteira
                            if (solicitacao.PosicaoDiaria)
                                nota = await _privateService.ObterNotaSessao (solicitacao.Sistema, solicitacao.Legado, "16");
                            else
                                nota = await _privateService.ObterNotaSessao (solicitacao.Sistema, solicitacao.Legado, "11");

                            if (nota.StatusProcessamento.Code == 550) {
                                throw (new Exception (string.Format ("Erro no Serviço: {0} - {1}", "NotaSecao", nota.StatusProcessamento.Message)));
                            }
                            #endregion

                            lstNotas.Add (nota.Conteudo[0]);
                        }
                    }

                    if (item.Nm_pag == "Rendimento da Carteira") {

                        if (item.txt_desc_secao == "Rendimento histórico da carteira") {
                            report.RendimentoHistoricoCarteira = await _rendimentoHistoricoCarteiraService.GetData (solicitacao);
                        }
                        if (item.txt_desc_secao == "Índice de Mercado") {
                            report.RendimentoHistoricoIndiceMercado = await _rendimentoHistoricoIndiceMercadoService.GetData (solicitacao);
                        }
                    }

                    if (item.Nm_pag == "Rendimento de Produtos") {
                        if (item.txt_desc_secao == "Rendimento histórico de produtos") {
                            report.RendimentoHistoricoProdutosMercado = await _rendimentoHistoricoProdutosService.GetData (solicitacao);

                            var nota = await _privateService.ObterNotaSessao (solicitacao.Sistema, solicitacao.Legado, "11");

                            if (nota.StatusProcessamento.Code == 550) {
                                throw (new Exception (string.Format ("Erro no Serviço: {0} - {1}", "NotaSecao", nota.StatusProcessamento.Message)));
                            }
                            lstNotas.Add (nota.Conteudo[0]);
                        }
                    }

                    if (item.Nm_pag == "Posição de Investimentos") {
                        if (item.txt_desc_secao == "Posição de Investimentos") {
                            _NotaSessao = await _privateService.ObterNotaSessao (solicitacao.Sistema, solicitacao.Legado, "15");
                            lstNotas.Add (_NotaSessao.Conteudo[0]);

                            report.PosicaoInvestimentos = await _posicaoInvestimentosService.GetData (solicitacao);
                        }
                    }

                    if (item.Nm_pag == "Investimentos Composição") {
                        if (item.txt_desc_secao == "Investimentos Composição") {
                            if (_validaSegmento > 0) {
                                report.InvestimentoComposicaoDetalhadaCorretora = await _investimentosComposicaoDetalhadaCorretora.GetData (solicitacao);
                                report.InvestimentoComposicaoDetalhada = await _investimentoComposicaoDetalhadaService.GetData (solicitacao);
                            }
                        }
                    }

                    if (item.Nm_pag == "Detalhamento de Fundos") {
                        if (item.txt_desc_secao == "Detalhamento de Fundos") {
                            report.DetalhamentoFundosInvestimento = await _detalhamentoFundosInvestimentoService.GetData (solicitacao);
                        }
                    }

                    if (item.Nm_pag == "Detalhamento Renda Fixa") {
                        if (item.txt_desc_secao == "Detalhamento Renda Fixa") {
                            report.DetalhamentoAtivosRendaFixa = await _detalhamentoAtivosRendaFixaService.GetData (solicitacao);
                        }
                    }

                    if (item.Nm_pag == "Detalhamento Ações") {
                        if (item.txt_desc_secao == "Detalhamento Ações") {
                            report.DetalhamentoAcoes = await _detalhamentoAcoesService.GetData (solicitacao);
                        }
                    }

                    if (item.Nm_pag == "Detalhamento Produtos Estruturados") {
                        if (item.txt_desc_secao == "Detalhamento Produtos Estruturados") {
                            report.DetalhamentoProdutosEstruturados = await _detalhamentoProdutosEstruturadosService.GetData (solicitacao);
                        }
                    }

                    if (item.Nm_pag == "Detalhamento de Poupança") {
                        if (item.txt_desc_secao == "Detalhamento de Poupança") {
                            report.DetalhamentoPoupanca = _detalharPoupancaService.GetData (solicitacao);
                        }
                    }

                    if (item.Nm_pag == "Notas") {
                        if (item.txt_desc_secao == "Notas") {
                            #region SecNotas
                            _NotaSessao = await _privateService.ObterNotaSessao (solicitacao.Sistema, solicitacao.Legado, "13");
                            if (_NotaSessao.StatusProcessamento.Code == 550) {
                                throw (new Exception (string.Format ("Erro no Serviço: {0} - {1}", "NotaSecao", _NotaSessao.StatusProcessamento.Message)));
                            }
                            foreach (var itemNotas in _NotaSessao.Conteudo) {
                                lstNotas.Add (itemNotas);
                            }
                            #endregion
                        }
                    }

                    if (item.Nm_pag == "Extrato de Conta Corrente") {
                        if (item.txt_desc_secao == "Extrato de Conta Corrente") {
                            report.ContaCorrenteExtrato = await _contaCorrenteService.GetData (solicitacao);
                        }
                    }
                }

                _NotaSessao = await _privateService.ObterNotaSessao (solicitacao.Sistema, solicitacao.Legado, "14");
                if (_NotaSessao.StatusProcessamento.Code == 550) {
                    throw (new Exception (string.Format ("Erro no Serviço: {0} - {1}", "NotaSecao", _NotaSessao.StatusProcessamento.Message)));
                }
                lstNotas.Add (_NotaSessao.Conteudo[0]);

                report.NotaSessao = new NotaSessao ();
                report.NotaSessao.Conteudo = lstNotas;
                report.DataPosicao = string.Format ("{0}/{1}/{2}", _dataRetorno.Substring (6, 2), _dataRetorno.Substring (4, 2), _dataRetorno.Substring (0, 4));
                report.DataApresentacao = string.Format ("{0}/{1}/{2}", _dataRetorno.Substring (6, 2), _dataRetorno.Substring (4, 2), _dataRetorno.Substring (2, 2));

                var dr = _dataRetorno.ToDateTime ("yyyyMMdd").Value;

                report.ReferenciaRelatorio = $"{dr.MonthName()} de {dr.Year}";

                //var Title = $"RelatorioMensal_{dr.ToString("MM")}_{dr.Year}_{Model.Agencia}_{MascararConta(Model.Conta)}";
                report.UsuarioSolicitante = solicitacao.UsuarioSolicitante;
                report.Conta = MascararConta (report.Conta);

                return Ok (report);
            } catch (Exception ex) {
                return BadRequest (ex);
            }
        }



        /// <summary>
        /// Gera todos os dados utilizados no relatório.
        /// </summary>
        /// <remarks>
        /// Sample request:
        ///
        ///     POST /api/report
        ///     {
        ///         "sistema": "EXT",
        ///         "legado": "EXT",
        ///         "agencia": 11500,
        ///         "conta": 51385,
        ///         "dataReferencia": "20191024",
        ///         "Template": "1",
        ///         "segmento": "22",
        ///         "CodigoCliente": "4135305",
        ///         "CodigoTipoPessoa": "0007",
        ///         "UsuarioSolicitante": "AUTOMAT"
        ///     }
        ///
        /// </remarks>

        [HttpGet]
        public ActionResult Get (string token) {
            try {
                var solicitacao = GerenciamentoSolicitacao.ValidarSolicitacao(token);

                return Ok (solicitacao);
            } catch (Exception ex) {
                return BadRequest (ex);
            }
        }

        /// <summary>
        /// Valida a data de referencia da solicitação.
        /// </summary>
        /// <remarks>
        /// Sample request:
        ///
        ///     POST /api/report/ValidaDataReferencia
        ///     {
        ///         "sistema": "EXT",
        ///         "legado": "EXT",
        ///         "agencia": 11500,
        ///         "conta": 51385,
        ///         "dataReferencia": "20191024",
        ///         "Template": "1",
        ///         "segmento": "22",
        ///         "CodigoCliente": "4135305",
        ///         "CodigoTipoPessoa": "0007",
        ///         "UsuarioSolicitante": "AUTOMAT"
        ///     }
        ///
        /// </remarks>
        [Route ("validaDataReferencia")]
        [HttpPost]
        public ActionResult ValidaDataReferencia (SolicitacaoRelatorio solicitacao) {
            try {
                var dado = _validaReferenciaService.GetData (solicitacao);

                return Ok (dado);
            } catch (Exception ex) {
                return BadRequest (ex);
            }
        }

        /// <summary>
        /// Gera dados sobre a composição da carteira do cliente.
        /// </summary>
        /// <remarks>
        /// Sample request:
        ///
        ///     POST /api/report/ComposicaoCarteira
        ///     {
        ///         "sistema": "EXT",
        ///         "legado": "EXT",
        ///         "agencia": 11500,
        ///         "conta": 51385,
        ///         "dataReferencia": "20191024",
        ///         "Template": "1",
        ///         "segmento": "22",
        ///         "CodigoCliente": "4135305",
        ///         "CodigoTipoPessoa": "0007",
        ///         "UsuarioSolicitante": "AUTOMAT"
        ///     }
        ///
        /// </remarks>
        [Route ("composicaoCarteira")]
        [HttpPost]
        public async Task<ActionResult> ComposicaoCarteira (SolicitacaoRelatorio solicitacao) {
            try {
                var dado = await _composicaoCarteiraService.GetData (solicitacao);

                return Ok (dado);
            } catch (Exception ex) {
                return BadRequest (ex);
            }
        }

        /// <summary>
        /// Gera dados detalhados das ações do cliente.
        /// </summary>
        /// <remarks>
        /// Sample request:
        ///
        ///     POST /api/report/DetalhamentoAcoes
        ///     {
        ///         "sistema": "EXT",
        ///         "legado": "EXT",
        ///         "agencia": 11500,
        ///         "conta": 51385,
        ///         "dataReferencia": "20191024",
        ///         "Template": "1",
        ///         "segmento": "22",
        ///         "CodigoCliente": "4135305",
        ///         "CodigoTipoPessoa": "0007",
        ///         "UsuarioSolicitante": "AUTOMAT"
        ///     }
        ///
        /// </remarks>
        [Route ("detalhamentoAcoes")]
        [HttpPost]
        public async Task<ActionResult> DetalhamentoAcoes (SolicitacaoRelatorio solicitacao) {
            try {
                var dado = await _detalhamentoAcoesService.GetData (solicitacao);

                return Ok (dado);
            } catch (Exception ex) {
                return BadRequest (ex);
            }
        }

        /// <summary>
        /// Gera dados detalhados de ativos do cliente.
        /// </summary>
        /// <remarks>
        /// Sample request:
        ///
        ///     POST /api/report/DetalhamentoAtivos
        ///     {
        ///         "sistema": "EXT",
        ///         "legado": "EXT",
        ///         "agencia": 11500,
        ///         "conta": 51385,
        ///         "dataReferencia": "20191024",
        ///         "Template": "1",
        ///         "segmento": "22",
        ///         "CodigoCliente": "4135305",
        ///         "CodigoTipoPessoa": "0007",
        ///         "UsuarioSolicitante": "AUTOMAT"
        ///     }
        ///
        /// </remarks>
        [Route ("detalhamentoAtivos")]
        [HttpPost]
        public async Task<ActionResult> DetalhamentoAtivos (SolicitacaoRelatorio solicitacao) {
            try {
                var dado = await _detalhamentoAtivosRendaFixaService.GetData (solicitacao);

                return Ok (dado);
            } catch (Exception ex) {
                return BadRequest (ex);
            }
        }

        /// <summary>
        /// Gera dados detalhados de fundos de investimento do cliente.
        /// </summary>
        /// <remarks>
        /// Sample request:
        ///
        ///     POST /api/report/DetalhamentoFundos
        ///     {
        ///         "sistema": "EXT",
        ///         "legado": "EXT",
        ///         "agencia": 11500,
        ///         "conta": 51385,
        ///         "dataReferencia": "20191024",
        ///         "Template": "1",
        ///         "segmento": "22",
        ///         "CodigoCliente": "4135305",
        ///         "CodigoTipoPessoa": "0007",
        ///         "UsuarioSolicitante": "AUTOMAT"
        ///     }
        ///
        /// </remarks>
        [Route ("detalhamentoFundos")]
        [HttpPost]
        public async Task<ActionResult> DetalhamentoFundos (SolicitacaoRelatorio solicitacao) {
            try {
                var dado = await _detalhamentoFundosInvestimentoService.GetData (solicitacao);

                return Ok (dado);
            } catch (Exception ex) {
                return BadRequest (ex);
            }
        }

        /// <summary>
        /// Gera dados detalhados de produtos estruturados do cliente.
        /// </summary>
        /// <remarks>
        /// Sample request:
        ///
        ///     POST /api/report/DetalhamentoProdutosEstruturados
        ///     {
        ///         "sistema": "EXT",
        ///         "legado": "EXT",
        ///         "agencia": 11500,
        ///         "conta": 51385,
        ///         "dataReferencia": "20191024",
        ///         "Template": "1",
        ///         "segmento": "22",
        ///         "CodigoCliente": "4135305",
        ///         "CodigoTipoPessoa": "0007",
        ///         "UsuarioSolicitante": "AUTOMAT"
        ///     }
        ///
        /// </remarks>
        [Route ("detalhamentoProdutosEstruturados")]
        [HttpPost]
        public async Task<ActionResult> DetalhamentoProdutosEstruturados (SolicitacaoRelatorio solicitacao) {
            try {
                var dado = await _detalhamentoProdutosEstruturadosService.GetData (solicitacao);

                return Ok (dado);
            } catch (Exception ex) {
                return BadRequest (ex);
            }
        }

        /// <summary>
        /// Gera dados detalhados da poupança do cliente.
        /// </summary>
        /// <remarks>
        /// Sample request:
        ///
        ///     POST /api/report/DetalhamentoPoupanca
        ///     {
        ///         "sistema": "EXT",
        ///         "legado": "EXT",
        ///         "agencia": 11500,
        ///         "conta": 51385,
        ///         "dataReferencia": "20191024",
        ///         "Template": "1",
        ///         "segmento": "22",
        ///         "CodigoCliente": "4135305",
        ///         "CodigoTipoPessoa": "0007",
        ///         "UsuarioSolicitante": "AUTOMAT"
        ///     }
        ///
        /// </remarks>
        [Route ("detalhamentoPoupanca")]
        [HttpPost]
        public ActionResult DetalhamentoPoupanca (SolicitacaoRelatorio solicitacao) {
            try {
                var dado = _detalharPoupancaService.GetData (solicitacao);

                return Ok (dado);
            } catch (Exception ex) {
                return BadRequest (ex);
            }
        }

        /// <summary>
        /// Gera dados da composicao dos investimentos do cliente.
        /// </summary>
        /// <remarks>
        /// Sample request:
        ///
        ///     POST /api/report/InvestimentoComposicao
        ///     {
        ///         "sistema": "EXT",
        ///         "legado": "EXT",
        ///         "agencia": 11500,
        ///         "conta": 51385,
        ///         "dataReferencia": "20191024",
        ///         "Template": "1",
        ///         "segmento": "22",
        ///         "CodigoCliente": "4135305",
        ///         "CodigoTipoPessoa": "0007",
        ///         "UsuarioSolicitante": "AUTOMAT"
        ///     }
        ///
        /// </remarks>
        [Route ("investimentoComposicao")]
        [HttpPost]
        public async Task<ActionResult> InvestimentoComposicao (SolicitacaoRelatorio solicitacao) {
            try {
                var dado = await _investimentoComposicaoDetalhadaService.GetData (solicitacao);

                return Ok (dado);
            } catch (Exception ex) {
                return BadRequest (ex);
            }
        }

        /// <summary>
        /// Gera dados da posição dos investimentos do cliente.
        /// </summary>
        /// <remarks>
        /// Sample request:
        ///
        ///     POST /api/report/PosicaoInvestimentos
        ///     {
        ///         "sistema": "EXT",
        ///         "legado": "EXT",
        ///         "agencia": 11500,
        ///         "conta": 51385,
        ///         "dataReferencia": "20191024",
        ///         "Template": "1",
        ///         "segmento": "22",
        ///         "CodigoCliente": "4135305",
        ///         "CodigoTipoPessoa": "0007",
        ///         "UsuarioSolicitante": "AUTOMAT"
        ///     }
        ///
        /// </remarks>
        [Route ("posicaoInvestimentos")]
        [HttpPost]
        public async Task<ActionResult> PosicaoInvestimentos (SolicitacaoRelatorio solicitacao) {
            try {
                var dado = await _posicaoInvestimentosService.GetData (solicitacao);

                return Ok (dado);
            } catch (Exception ex) {
                return BadRequest (ex);
            }
        }

        /// <summary>
        /// Gera dados do rendimento histórico da carteira do cliente.
        /// </summary>
        /// <remarks>
        /// Sample request:
        ///
        ///     POST /api/report/RendimentoCarteira
        ///     {
        ///         "sistema": "EXT",
        ///         "legado": "EXT",
        ///         "agencia": 11500,
        ///         "conta": 51385,
        ///         "dataReferencia": "20191024",
        ///         "Template": "1",
        ///         "segmento": "22",
        ///         "CodigoCliente": "4135305",
        ///         "CodigoTipoPessoa": "0007",
        ///         "UsuarioSolicitante": "AUTOMAT"
        ///     }
        ///
        /// </remarks>
        [Route ("rendimentoCarteira")]
        [HttpPost]
        public async Task<ActionResult> RendimentoCarteira (SolicitacaoRelatorio solicitacao) {
            try {
                var dado = await _rendimentoHistoricoCarteiraService.GetData (solicitacao);

                return Ok (dado);
            } catch (Exception ex) {
                return BadRequest (ex);
            }
        }

        /// <summary>
        /// Gera dados de rendimento histórico sobre índices de mercado do cliente.
        /// </summary>
        /// <remarks>
        /// Sample request:
        ///
        ///     POST /api/report/RendimentoIndiceMercado
        ///     {
        ///         "sistema": "EXT",
        ///         "legado": "EXT",
        ///         "agencia": 11500,
        ///         "conta": 51385,
        ///         "dataReferencia": "20191024",
        ///         "Template": "1",
        ///         "segmento": "22",
        ///         "CodigoCliente": "4135305",
        ///         "CodigoTipoPessoa": "0007",
        ///         "UsuarioSolicitante": "AUTOMAT"
        ///     }
        ///
        /// </remarks>
        [Route ("rendimentoIndiceMercado")]
        [HttpPost]
        public async Task<ActionResult> RendimentoIndiceMercado (SolicitacaoRelatorio solicitacao) {
            try {
                var dado = await _rendimentoHistoricoIndiceMercadoService.GetData (solicitacao);

                return Ok (dado);
            } catch (Exception ex) {
                return BadRequest (ex);
            }
        }

        /// <summary>
        /// Gera dados de rendimento histórico sobre produtos do cliente.
        /// </summary>
        /// <remarks>
        /// Sample request:
        ///
        ///     POST /api/report/RendimentoProdutos
        ///     {
        ///         "sistema": "EXT",
        ///         "legado": "EXT",
        ///         "agencia": 11500,
        ///         "conta": 51385,
        ///         "dataReferencia": "20191024",
        ///         "Template": "1",
        ///         "segmento": "22",
        ///         "CodigoCliente": "4135305",
        ///         "CodigoTipoPessoa": "0007",
        ///         "UsuarioSolicitante": "AUTOMAT"
        ///     }
        ///
        /// </remarks>
        [Route ("rendimentoProdutos")]
        [HttpPost]
        public async Task<ActionResult> RendimentoProdutos (SolicitacaoRelatorio solicitacao) {
            try {
                var dado = await _rendimentoHistoricoProdutosService.GetData (solicitacao);

                return Ok (dado);
            } catch (Exception ex) {
                return BadRequest (ex);
            }
        }

        /// <summary>
        /// Gera dados do gráfico de composição de carteira.
        /// </summary>
        /// <remarks>
        /// Sample request:
        ///
        ///     POST /api/report/graficoCompCarteira
        ///     {
        ///         "sistema": "EXT",
        ///         "legado": "EXT",
        ///         "agencia": 11500,
        ///         "conta": 51385,
        ///         "dataReferencia": "20191024",
        ///         "Template": "1",
        ///         "segmento": "22",
        ///         "CodigoCliente": "4135305",
        ///         "CodigoTipoPessoa": "0007",
        ///         "UsuarioSolicitante": "AUTOMAT"
        ///     }
        ///
        /// </remarks>
        [HttpPost]
        [Route ("graficoCompCarteira")]
        public async Task<ActionResult> GraficoCompCarteira ([FromBody] SolicitacaoRelatorio solicitacao) {
            try {
                var dado = await _graficoCompCarteiraService.GetData (solicitacao);

                return Ok (dado);
            } catch (Exception ex) {
                return BadRequest (ex);
            }
        }

        /// <summary>
        /// Gera dados do gráfico de rendimento histórico.
        /// </summary>
        /// <remarks>
        /// Sample request:
        ///
        ///     POST /api/report/graficoRendHistorico
        ///     {
        ///         "sistema": "EXT",
        ///         "legado": "EXT",
        ///         "agencia": 11500,
        ///         "conta": 51385,
        ///         "dataReferencia": "20191024",
        ///         "Template": "1",
        ///         "segmento": "22",
        ///         "CodigoCliente": "4135305",
        ///         "CodigoTipoPessoa": "0007",
        ///         "UsuarioSolicitante": "AUTOMAT"
        ///     }
        ///
        /// </remarks>
        [HttpPost]
        [Route ("graficoRendHistorico")]
        public async Task<ActionResult> GraficoRendHistorico ([FromBody] SolicitacaoRelatorio solicitacao) {
            try {
                var dado = await _graficoRendHistoricoService.GetData (solicitacao);
                return Ok (dado);
            } catch (Exception ex) {
                return BadRequest (ex);
            }
        }


        /// <summary>
        /// Gera dados do gráfico de suitability.
        /// </summary>
        /// <remarks>
        /// Sample request:
        ///
        ///     POST /api/report/graficoSuitability
        ///     {
        ///         "sistema": "EXT",
        ///         "legado": "EXT",
        ///         "agencia": 11500,
        ///         "conta": 51385,
        ///         "dataReferencia": "20191024",
        ///         "Template": "1",
        ///         "segmento": "22",
        ///         "CodigoCliente": "4135305",
        ///         "CodigoTipoPessoa": "0007",
        ///         "UsuarioSolicitante": "AUTOMAT"
        ///     }
        ///
        /// </remarks>
        [HttpPost]
        [Route ("graficoSuitability")]
        public async Task<ActionResult> GraficoSuitability ([FromBody] SolicitacaoRelatorio solicitacao) {
            try {
                var dado = await _graficoSuitabilityService.GetData (solicitacao);
                return Ok (dado);
            } catch (Exception ex) {
                return BadRequest (ex);
            }
        }
    }
}