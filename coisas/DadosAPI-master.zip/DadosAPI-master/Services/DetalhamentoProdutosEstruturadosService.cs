using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using DadosAPI.Models;
using DadosAPI.Models.GerenciamentoSolicitacao;

namespace DadosAPI.Services {
    public class DetalhamentoProdutosEstruturadosService {
        private readonly RelatorioService _service;
        private readonly PrivateService _privateService;

        public DetalhamentoProdutosEstruturadosService (
            RelatorioService service,
            PrivateService privateService
        ) {
            _service = service;
            _privateService = privateService;
        }
        public async Task<DetalhamentoProdutosEstruturados> GetData (SolicitacaoRelatorio solicitacao) {

            DetalhamentoProdutosEstruturados oDetProd = new DetalhamentoProdutosEstruturados ();
            List<DetalhamentoProdutosEstruturados> oDetProdList = new List<DetalhamentoProdutosEstruturados> ();

            string _tipoLayout = "00";

            var _ativo = await _privateService.ObterAtivoCarteiraCliente (
                solicitacao.Sistema,
                solicitacao.Legado,
                solicitacao.Agencia.ToString (),
                solicitacao.Conta.ToString (),
                solicitacao.DataReferencia,
                _tipoLayout,
                solicitacao.Segmento);

            if (_ativo != null) {
                if (_ativo.StatusProcessamento.Code != 200) {
                    throw (new Exception (string.Format ("Erro no Serviço: {0} - {1}", "AtivoCarteira", _ativo.StatusProcessamento.Message)));
                }

                if (_ativo.LstCOE[0].QuantidadeOcorrencias != -1) {
                    _ativo.LstCOE = _ativo.LstCOE.Where (x => x.IdentSeqGrupoProduto != 0 && x.IdentSeqProduto != 0).ToList ();
                    foreach (var itemCOE in _ativo.LstCOE) {
                        DetalhamentoProdutosEstruturados oDet = new DetalhamentoProdutosEstruturados ();
                        oDet.NomeAtivo = itemCOE.NomeProduto;
                        oDet.DataAplicacao = string.Format ("{0}/{1}/{2}", itemCOE.DataInicial.Substring (6, 2), itemCOE.DataInicial.Substring (4, 2), itemCOE.DataInicial.Substring (0, 4));
                        oDet.Vencimento = string.Format ("{0}/{1}/{2}", itemCOE.DataFinal.Substring (6, 2), itemCOE.DataFinal.Substring (4, 2), itemCOE.DataFinal.Substring (0, 4));
                        oDet.SaldoAplicado = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N2}", itemCOE.ValorAplicado);
                        oDet.SaldoBruto = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N2}", itemCOE.ValorAtualizado);
                        oDet.ImpostosPrevistos = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N2}", itemCOE.ImpostoPrevisto);
                        oDet.SaldoLiquido = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N2}", itemCOE.SaldoLiquido);

                        oDetProdList.Add (oDet);
                    }
                }

                if (_ativo.LstDerivativoEstruturada[0].QuantidadeOcorrencias != -1) {
                    _ativo.LstDerivativoEstruturada = _ativo.LstDerivativoEstruturada.Where (x => x.IdentSeqFamilia != 0).ToList ();
                    foreach (var itemDer in _ativo.LstDerivativoEstruturada) {
                        DetalhamentoProdutosEstruturados oDet = new DetalhamentoProdutosEstruturados ();
                        oDet.NomeAtivo = itemDer.InvestimentoNomeOperacao;
                        oDet.DataAplicacao = string.Format ("{0}/{1}/{2}", itemDer.DataInicial.Substring (6, 2), itemDer.DataInicial.Substring (4, 2), itemDer.DataInicial.Substring (0, 4));
                        oDet.Vencimento = string.Format ("{0}/{1}/{2}", itemDer.DataFinal.Substring (6, 2), itemDer.DataFinal.Substring (4, 2), itemDer.DataFinal.Substring (0, 4));
                        oDet.SaldoAplicado = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N2}", itemDer.ValorNegociado);
                        oDet.SaldoBruto = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N2}", itemDer.ValorAjusteBruto);
                        oDet.ImpostosPrevistos = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N2}", itemDer.ImpostoPrevisto);
                        oDet.SaldoLiquido = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N2}", itemDer.ValorAjusteLiquido);

                        oDetProdList.Add (oDet);
                    }
                }
            }

            oDetProd.DetalhamentoProdutosEstruturadosList = oDetProdList;
            return oDetProd;
        }
    }
}