using System;
using DadosAPI.Extensions;
using DadosAPI.Models;
using DadosAPI.Models.GerenciamentoSolicitacao;

namespace DadosAPI.Services {
    public class ValidaReferenciaService {
        private readonly RelatorioService _service;

        public ValidaReferenciaService (RelatorioService service) {
            _service = service;
        }
        public ValidacaoReferencia GetData (SolicitacaoRelatorio solicitacao) {

            string _agencia = solicitacao.Agencia.ToString ();
            string _conta = solicitacao.Conta.ToString ();
            string _dataReferencia = solicitacao.DataReferencia;
            string _segmento = solicitacao.Segmento;
            string _usuarioSolicitante = solicitacao.UsuarioSolicitante;
            bool _PosicaoDiaria = false;
            bool _MesNaoFechado = false;
            string _UltimoDiaMes = "";
            int _validaSegmento = 0;

            //Indisponibilizar relatório ou uma relação de meses.
            string _indisponivel = _service.IndisponibilizarRelatorio ();
            string _dataValidar = "";

            _validaSegmento = _service.ValidarSegmento (int.Parse (_segmento), solicitacao.Sistema);

            if (_dataReferencia.Length > 6) {
                _dataValidar = _dataReferencia.Substring (6, 2) + "/" + _dataReferencia.Substring (4, 2) + "/" + _dataReferencia.Substring (0, 4);
                _PosicaoDiaria = true;
            } else {
                _dataValidar = "28/" + _dataReferencia.Substring (4, 2) + "/" + _dataReferencia.Substring (0, 4);
                _UltimoDiaMes = _service.ObterExtremosMes (_dataValidar);
                _dataValidar = _UltimoDiaMes;
                _dataReferencia = _dataReferencia + _UltimoDiaMes.Substring (0, 2);
            }

            if (_indisponivel.ToUpper ().Contains ("S") || _indisponivel.Contains (_dataValidar.FormatDataString (StringExtensions.DataFormat.MesBarraAno))) {
                throw (new Exception ($"Indisponibilidade - Desculpe: Relatório não disponível para a referência solicitada."));
            }

            //Verifica a data de corte da Nova Rentabilidade
            var _dataCorte = _service.ObterDataCorte ();

            int _iDataCorte = int.Parse (_dataCorte.Substring (6, 4) + _dataCorte.Substring (3, 2) + _dataCorte.Substring (0, 2));
            int _idataReferencia = int.Parse (_dataReferencia.Substring (0, 4) + _dataReferencia.Substring (4, 2) + _dataReferencia.Substring (6, 2));
            if (_idataReferencia < _iDataCorte) {
                //if (!_segmento.InValue("22", "23", "77", "78")) //Segmento Private
                if (_validaSegmento < 1) {
                    throw (new Exception ($"Cod:01 - Desculpe: Relatório não disponível para a referência solicitada."));
                } else {
                    _UltimoDiaMes = _service.ObterExtremosMes (_dataValidar);
                    _dataValidar = _UltimoDiaMes;
                    _dataReferencia = _dataReferencia.Substring (0, 4) + _dataReferencia.Substring (4, 2) + _UltimoDiaMes.Substring (0, 2);
                }
            }

            // ------------- Validar a liberação do relatório para 5º dia útil -------------

            var mesReferencia = _dataReferencia.Substring (0, 4) + _dataReferencia.Substring (4, 2);
            var _dataNow = DateTime.Now.Year.ToString () + DateTime.Now.Month.ToString ().PadLeft (2, '0') + DateTime.Now.Day.ToString ().PadLeft (2, '0');
            var mesVigente = _service.ObterRegraMes (_dataNow);
            var _iMesVigente = mesVigente.Substring (6, 4) + mesVigente.Substring (3, 2);

            if (int.Parse (_iMesVigente) <= int.Parse (mesReferencia)) {
                var _dataInicial = _service.ObterLiberarDia ();
                int _dataLiberar = int.Parse (_dataInicial.Substring (6, 4) + _dataInicial.Substring (3, 2) + _dataInicial.Substring (0, 2));
                int _dataHoje = int.Parse (DateTime.Now.Year.ToString () + DateTime.Now.Month.ToString ().PadLeft (2, '0') + DateTime.Now.Day.ToString ().PadLeft (2, '0'));
                if (_dataHoje < _dataLiberar) {
                    if (!_PosicaoDiaria) {
                        throw (new Exception ("Desculpe: O relatório para o mês solicitado estará disponível a partir do 5º dia útil."));
                    } else {
                        _MesNaoFechado = true;
                    }
                }
            }

            if (_PosicaoDiaria)
                _UltimoDiaMes = _service.ObterExtremosMes (_dataValidar);

            if (!_MesNaoFechado && _PosicaoDiaria && (_UltimoDiaMes.FormatDataString (StringExtensions.DataFormat.AnoMesDia) == _dataReferencia)) {
                _PosicaoDiaria = false;
            }

            // --------------------------------------------------Contas em quarentena
            if (_service.ObterRestricaoConta (_agencia, _conta, mesReferencia) > 0) {
                throw (new Exception ("Desculpe: Para este cliente o Relatório não está disponível para a referência solicitada. Favor contactar a área responsável."));
            }

            if (_service.ObterRestricaoContaPiloto (_agencia, _conta) < 1) {
                throw (new Exception ("Desculpe: Funcionalidade em validação piloto. Somente contas previamente selecionadas estão disponíveis para consulta. Em breve esta funcionalidade será disponibilizada para toda a rede de agências."));
            }

            string _dataRetorno = "";
            string diaAuxilio = _dataReferencia.Substring (6, 2);
            string mesAuxilio = _dataReferencia.Substring (4, 2);
            string anoAuxilio = _dataReferencia.Substring (0, 4);
            var _dataAuxilio = diaAuxilio + "/" + (mesAuxilio.Length == 1 ? "0" + mesAuxilio : mesAuxilio) + "/" + anoAuxilio;

            string _mesAtual = DateTime.Now.Month.ToString ().Length == 1 ? "0" + DateTime.Now.Month.ToString () : DateTime.Now.Month.ToString ();
            string _anoAtual = DateTime.Now.Year.ToString ();

            if (!_PosicaoDiaria && _dataReferencia.Substring (4, 2) == _mesAtual && _dataReferencia.Substring (0, 4) == _anoAtual) {
                throw (new Exception ("Cod:02 - Desculpe: Relatório não disponível para a referência solicitada."));
            } else {
                var dt = _dataAuxilio.ToDateTime ("dd/MM/yyyy");
                _dataRetorno = _service.ObterRetornoDataPosicao (_dataAuxilio, _segmento);

                if (_dataRetorno == null) {
                    throw (new Exception ("Cod:03 - Desculpe: Relatório não disponível para a referência solicitada."));
                }

                if (_dataRetorno.Substring (3, 2) + _dataReferencia.Substring (0, 4) != _dataReferencia.Substring (4, 2) + _dataRetorno.Substring (6, 4)) {
                    throw (new Exception ("Cod:04 - Desculpe: Relatório não disponível para a referência solicitada."));
                }
            }

            _dataAuxilio = _dataReferencia;
            _dataRetorno = _dataRetorno.Substring (6, 4) + _dataRetorno.Substring (3, 2) + _dataRetorno.Substring (0, 2);

            var dado = new ValidacaoReferencia () {
                _validaSegmento = _validaSegmento,
                _dataReferencia = _dataReferencia,
                _PosicaoDiaria = _PosicaoDiaria,
                _UltimoDiaMes = _UltimoDiaMes,
                _MesNaoFechado = _MesNaoFechado,
                _dataAuxilio = _dataAuxilio,
                _dataRetorno = _dataRetorno
            };

            return dado;
        }
    }
}