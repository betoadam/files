using System;
using System.Net.Http;
using System.Threading.Tasks;
using DadosAPI.Models;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;

namespace DadosAPI.Services {
    public class PrivateService {

        public PrivateService () {

        }

        //Serviço 1 - Serviço de retorno de Rentabilidade Acumulada por períodos fixos (RentabilidadeFixo)
        public async Task<RentabilidadeFixo> ObterRentabilidadeFixo (
            string _sistema,
            string _legado,
            string _agencia,
            string _conta,
            string _datareferencia,
            string _codRent,
            string _segmento,
            string _retocorr
        ) {
            string urlPrefix = AppConfig.Configuration.GetValue<string> ("UrlPrvService");

            string baseUrl = string.Format ("{0}/PrvServiceRentabilidadeFixo.svc/RentabilidadeFixo", urlPrefix);
            //The 'using' will help to prevent memory leaks.
            //Create a new instance of HttpClient
            var stringContent = new StringContent (new {
                sistema = _sistema,
                    legado = _legado,
                    agencia = _agencia,
                    conta = _conta,
                    dataReferencia = _datareferencia,
                    codRent = _codRent,
                    segmento = _segmento,
                    retocorr = _retocorr
            }.ToString ());

            using (HttpClient client = new HttpClient ())
            using (HttpResponseMessage res = await client.PostAsync (baseUrl, stringContent))
            using (HttpContent content = res.Content) {
                string data = await content.ReadAsStringAsync ();
                RentabilidadeFixo oRentabilidadeFixo = JsonConvert.DeserializeObject<RentabilidadeFixo> (data);
                // RentabilidadeFixo oRentabilidadeFixo = await content.ReadAsStringAsync()

                if (oRentabilidadeFixo != null) {
                    if (oRentabilidadeFixo.Conteudo[0].QuantidadeOcorrencias != -1) {
                        foreach (var item in oRentabilidadeFixo.Conteudo) {
                            item.dtAnoMesRef = Convert.ToDateTime (string.Format ("01/{0}/{1}", item.AnoMesRef.Substring (4, 2), item.AnoMesRef.Substring (0, 4)));
                        }
                    }
                }
                return oRentabilidadeFixo;
            }
        }

        //Serviço 2 - Serviço de Retorno de % do Benchmark (BenchmarkFixo)
        public async Task<BenchMarkFixo> ObterBenchmarkFixo (
            string _sistema,
            string _legado,
            string _agencia,
            string _conta,
            string _datareferencia,
            string _codIndice,
            string _indiceEquivalente,
            string _segmento,
            string _retocorr
        ) {
            string urlPrefix = AppConfig.Configuration.GetValue<string> ("UrlPrvService");

            string baseUrl = string.Format ("{0}/PrvServiceBenchmarkFixo.svc/BenchmarkFixo", urlPrefix);
            //The 'using' will help to prevent memory leaks.
            //Create a new instance of HttpClient
            var stringContent = new StringContent (new {
                sistema = _sistema,
                    legado = _legado,
                    agencia = _agencia,
                    conta = _conta,
                    dataReferencia = _datareferencia,
                    codIndice = _codIndice,
                    indiceEquivalente = _indiceEquivalente,
                    segmento = _segmento,
                    retocorr = _retocorr
            }.ToString ());

            using (HttpClient client = new HttpClient ())
            using (HttpResponseMessage res = await client.PostAsync (baseUrl, stringContent))
            using (HttpContent content = res.Content) {
                string data = await content.ReadAsStringAsync ();
                var oBenchmarkFixo = JsonConvert.DeserializeObject<BenchMarkFixo> (data);

                if (oBenchmarkFixo != null) {
                    if (oBenchmarkFixo.Conteudo[0].QuantidadeOcorrencias != -1) {
                        foreach (var item in oBenchmarkFixo.Conteudo) {
                            item.dtAnoMesRef = Convert.ToDateTime (string.Format ("01/{0}/{1}", item.AnoMesRef.Substring (4, 2), item.AnoMesRef.Substring (0, 4)));
                        }
                    }
                }

                return oBenchmarkFixo;
            }
        }

        //Serviço 3 - Serviço de Retorno de Rentabilidade acumulada ou não por períodos flexíveis (mensal) (RentabilidadeFlexivel)
        public async Task<RentabilidadeFlexivel> ObterRentabilidadeFlexivel (
            string _sistema,
            string _legado,
            string _agencia,
            string _conta,
            string _datareferencia,
            string _codRent,
            int _qtdmes,
            string _indAcumulado,
            string _segmento,
            string _retocorr
        ) {
            string urlPrefix = AppConfig.Configuration.GetValue<string> ("UrlPrvService");

            string baseUrl = string.Format ("{0}/PrvServiceRentabilidadeFlexivel.svc/RentabilidadeFlexivel", urlPrefix);
            //The 'using' will help to prevent memory leaks.
            //Create a new instance of HttpClient
            var stringContent = new StringContent (new {
                sistema = _sistema,
                    legado = _legado,
                    agencia = _agencia,
                    conta = _conta,
                    dataReferencia = _datareferencia,
                    codRent = _codRent,
                    qtdmes = _qtdmes,
                    indAcumulado = _indAcumulado,
                    segmento = _segmento,
                    retocorr = _retocorr
            }.ToString ());

            using (HttpClient client = new HttpClient ())
            using (HttpResponseMessage res = await client.PostAsync (baseUrl, stringContent))
            using (HttpContent content = res.Content) {
                string data = await content.ReadAsStringAsync ();
                var oRentabilidadeFlexivel = JsonConvert.DeserializeObject<RentabilidadeFlexivel> (data);

                if (oRentabilidadeFlexivel.Conteudo[0].QuantidadeOcorrencias != -1) {
                    foreach (var item in oRentabilidadeFlexivel.Conteudo) {
                        item.dtAnoMesRef = Convert.ToDateTime (string.Format ("01/{0}/{1}", item.AnoMesRef.Substring (4, 2), item.AnoMesRef.Substring (0, 4)));
                    }
                }
                return oRentabilidadeFlexivel;
            }
        }

        //Serviço 4 - Serviço de Retorno de Índices acumulados ou não por períodos flexíveis (mensal) (IndiceAcumulado)
        public async Task<IndiceAcumulado> ObterIndiceAcumulado (
            string _sistema,
            string _legado,
            string _agencia,
            string _conta,
            string _datareferencia,
            string _codIndice,
            int _qtdmes,
            string _indAcumulado,
            string _segmento
        ) {

            string urlPrefix = AppConfig.Configuration.GetValue<string> ("UrlPrvService");

            string baseUrl = string.Format ("{0}/PrvServiceIndiceAcumulado.svc/IndiceAcumulado", urlPrefix);
            //The 'using' will help to prevent memory leaks.
            //Create a new instance of HttpClient
            var stringContent = new StringContent (new {
                sistema = _sistema,
                    legado = _legado,
                    agencia = _agencia,
                    conta = _conta,
                    dataReferencia = _datareferencia,
                    codIndice = _codIndice,
                    qtdmes = _qtdmes,
                    indAcumulado = _indAcumulado,
                    segmento = _segmento
            }.ToString ());

            using (HttpClient client = new HttpClient ())
            using (HttpResponseMessage res = await client.PostAsync (baseUrl, stringContent))
            using (HttpContent content = res.Content) {
                string data = await content.ReadAsStringAsync ();
                var oIndiceAcumulado = JsonConvert.DeserializeObject<IndiceAcumulado> (data);

                if (oIndiceAcumulado.Conteudo[0].QuantidadeOcorrencias != -1) {
                    foreach (var item in oIndiceAcumulado.Conteudo) {
                        item.dtAnoMesRef = Convert.ToDateTime (string.Format ("01/{0}/{1}", item.AnoMesIndice.Substring (4, 2), item.AnoMesIndice.Substring (0, 4)));
                    }
                }
                return oIndiceAcumulado;
            }
        }

        //Serviço 5 - Serviço de Retorno de Índices Equivalentes por períodos flexíveis (mensal) (IndiceEquivalente)
        public async Task<IndiceEquivalente> ObterIndiceEquivalente (
            string _sistema,
            string _legado,
            string _agencia,
            string _conta,
            string _datareferencia,
            string _codIndice,
            int _qtdmes,
            string _indAcumulado,
            string _segmento,
            string _retocorr
        ) {
            string urlPrefix = AppConfig.Configuration.GetValue<string> ("UrlPrvService");

            string baseUrl = string.Format ("{0}/PrvServiceIndiceEquivalente.svc/IndiceEquivalente", urlPrefix);
            //The 'using' will help to prevent memory leaks.
            //Create a new instance of HttpClient
            var stringContent = new StringContent (new {
                sistema = _sistema,
                    legado = _legado,
                    agencia = _agencia,
                    conta = _conta,
                    dataReferencia = _datareferencia,
                    codIndice = _codIndice,
                    qtdmes = _qtdmes,
                    indAcumulado = _indAcumulado,
                    segmento = _segmento,
                    retocorr = _retocorr
            }.ToString ());

            using (HttpClient client = new HttpClient ())
            using (HttpResponseMessage res = await client.PostAsync (baseUrl, stringContent))
            using (HttpContent content = res.Content) {
                string data = await content.ReadAsStringAsync ();
                var oIndiceEquivalente = JsonConvert.DeserializeObject<IndiceEquivalente> (data);

                if (oIndiceEquivalente.Conteudo[0].QuantidadeOcorrencias != -1) {
                    foreach (var item in oIndiceEquivalente.Conteudo) {
                        item.dtAnoMesRef = Convert.ToDateTime (string.Format ("01/{0}/{1}", item.AnoMesIndice.Substring (4, 2), item.AnoMesIndice.Substring (0, 4)));
                    }
                }
                return oIndiceEquivalente;
            }
        }

        //Serviço 6 - Serviço de Retorno de Notas por seção
        public async Task<NotaSessao> ObterNotaSessao (
            string _sistema,
            string _legado,
            string _secao
        ) {
            string urlPrefix = AppConfig.Configuration.GetValue<string> ("UrlPrvService");

            string baseUrl = string.Format ("{0}/PrvServiceNotaSessao.svc/NotaSessao", urlPrefix);
            //The 'using' will help to prevent memory leaks.
            //Create a new instance of HttpClient
            var stringContent = new StringContent (new {
                sistema = _sistema,
                    legado = _legado,
                    secao = _secao
            }.ToString ());

            using (HttpClient client = new HttpClient ())
            using (HttpResponseMessage res = await client.PostAsync (baseUrl, stringContent))
            using (HttpContent content = res.Content) {
                string data = await content.ReadAsStringAsync ();
                var oNotaSessao = JsonConvert.DeserializeObject<NotaSessao> (data);

                return oNotaSessao;
            }
        }

        //Serviço 7 - Serviço de Retorno de informações resumo da conta (InformacaoResumoConta)
        public async Task<ResumoConta> ObterInformacaoResumoConta (
            string _sistema,
            string _legado,
            string _agencia,
            string _conta,
            string _datareferencia,
            string _segmento
        ) {
            string urlPrefix = AppConfig.Configuration.GetValue<string> ("UrlPrvService");

            string baseUrl = string.Format ("{0}/PrvServiceResumoConta.svc/InformacaoResumoConta", urlPrefix);
            //The 'using' will help to prevent memory leaks.
            //Create a new instance of HttpClient
            var stringContent = new StringContent (new {
                sistema = _sistema,
                    legado = _legado,
                    agencia = _agencia,
                    conta = _conta,
                    dataReferencia = _datareferencia,
                    segmento = _segmento
            }.ToString ());

            using (HttpClient client = new HttpClient ())
            using (HttpResponseMessage res = await client.PostAsync (baseUrl, stringContent))
            using (HttpContent content = res.Content) {
                string data = await content.ReadAsStringAsync ();
                var oResumoConta = JsonConvert.DeserializeObject<ResumoConta> (data);

                return oResumoConta;
            }
        }

        //Serviço 8 - Serviço de Retorno de informações de movimentação da conta (MovimentacaoConta)
        public async Task<MovimentacaoConta> ObterMovimentacaoConta (string _sistema, string _legado, string _agencia, string _conta, string _datareferencia, string _tipoLayout, string _segmento) {
            string urlPrefix = AppConfig.Configuration.GetValue<string> ("UrlPrvService");

            string baseUrl = string.Format ("{0}/PrvServiceMovimentacaoConta.svc/MovimentacaoConta", urlPrefix);
            //The 'using' will help to prevent memory leaks.
            //Create a new instance of HttpClient
            var stringContent = new StringContent (new {
                sistema = _sistema,
                    legado = _legado,
                    agencia = _agencia,
                    conta = _conta,
                    dataReferencia = _datareferencia,
                    tipoLayout = _tipoLayout,
                    segmento = _segmento
            }.ToString ());

            using (HttpClient client = new HttpClient ())
            using (HttpResponseMessage res = await client.PostAsync (baseUrl, stringContent))
            using (HttpContent content = res.Content) {
                string data = await content.ReadAsStringAsync ();
                var oMovimentacaoConta = JsonConvert.DeserializeObject<MovimentacaoConta> (data);

                return oMovimentacaoConta;
            }
        }

        //Serviço 9 - Serviço de Retorno de detalhe dos ativos da carteira do cliente
        public async Task<AtivoCarteiraCliente> ObterAtivoCarteiraCliente (
            string _sistema,
            string _legado,
            string _agencia,
            string _conta,
            string _datareferencia,
            string _tipoLayout,
            string _segmento
        ) {
            string urlPrefix = AppConfig.Configuration.GetValue<string> ("UrlPrvService");

            string baseUrl = string.Format ("{0}/PrvServiceAtivoCarteiraCliente.svc/AtivoCarteiraCliente", urlPrefix);
            //The 'using' will help to prevent memory leaks.
            //Create a new instance of HttpClient
            var stringContent = new StringContent (new {
                sistema = _sistema,
                    legado = _legado,
                    agencia = _agencia,
                    conta = _conta,
                    dataReferencia = _datareferencia,
                    tipoLayout = _tipoLayout,
                    segmento = _segmento
            }.ToString ());

            using (HttpClient client = new HttpClient ())
            using (HttpResponseMessage res = await client.PostAsync (baseUrl, stringContent))
            using (HttpContent content = res.Content) {
                string data = await content.ReadAsStringAsync ();
                var oAtivoCarteiraCliente = JsonConvert.DeserializeObject<AtivoCarteiraCliente> (data);

                return oAtivoCarteiraCliente;
            };
        }

        //Serviço 10 - Serviço de Retorno de Saldos da carteira de fechamento por período
        public async Task<SaldoCarteiraFechamento> ObterSaldoCarteiraFechamento (
            string _sistema,
            string _legado,
            string _agencia,
            string _conta,
            string _datareferencia,
            int _qtdmes,
            string _indProduto,
            string _segmento
        ) {
            try {
                string urlPrefix = AppConfig.Configuration.GetValue<string> ("UrlPrvService");

                string baseUrl = string.Format ("{0}/PrvServiceSaldoCarteiraFechamento.svc/SaldoCarteiraFechamento", urlPrefix);
                //The 'using' will help to prevent memory leaks.
                //Create a new instance of HttpClient
                var stringContent = new StringContent (new {
                    sistema = _sistema,
                        legado = _legado,
                        agencia = _agencia,
                        conta = _conta,
                        dataReferencia = _datareferencia,
                        qtdmes = _qtdmes,
                        indProduto = _indProduto,
                        segmento = _segmento
                }.ToString ());

                using (HttpClient client = new HttpClient ())
                using (HttpResponseMessage res = await client.PostAsync (baseUrl, stringContent))
                using (HttpContent content = res.Content) {
                    string data = await content.ReadAsStringAsync ();
                    var oSaldoCarteiraFechamento = JsonConvert.DeserializeObject<SaldoCarteiraFechamento> (data);

                    if (oSaldoCarteiraFechamento.Conteudo[0].QuantidadeOcorrencias != -1) {
                        foreach (var item in oSaldoCarteiraFechamento.Conteudo) {
                            item.dtAnoMesRef = Convert.ToDateTime (string.Format ("01/{0}/{1}", item.DataSaldo.Substring (4, 2), item.DataSaldo.Substring (0, 4)));
                        }
                    }

                    return oSaldoCarteiraFechamento;
                }
            } catch (Exception ex) {
                throw new Exception ("Falha ao buscar dados do Serviço de Retorno de Saldos da carteira de fechamento por período." + ex.Message);
            }
        }


        public async Task<ContaCorrente> ObterContaCorrente(string _sistema, string _legado, string _agencia, string _conta, string _tipoLayout, string _anomesref)
        {

            try {
                string urlPrefix = AppConfig.Configuration.GetValue<string> ("UrlPrvService");

                string baseUrl = string.Format ("{0}/PrvServiceContaCorrente.svc/ContaCorrente", urlPrefix);
                //The 'using' will help to prevent memory leaks.
                //Create a new instance of HttpClient
                var stringContent = new StringContent (new {
                    sistema = _sistema,
                    legado = _legado,
                    agencia = _agencia,
                    conta = _conta,
                    tipoLayout = _tipoLayout,
                    anomesref = _anomesref
                }.ToString ());

                using (HttpClient client = new HttpClient ())
                using (HttpResponseMessage res = await client.PostAsync (baseUrl, stringContent))
                using (HttpContent content = res.Content) {
                    string data = await content.ReadAsStringAsync ();
                    var oContaCorrente = JsonConvert.DeserializeObject<ContaCorrente> (data);


                    return oContaCorrente;
                }
            } catch (Exception ex) {
                throw new Exception ("Falha ao buscar dados do Serviço de Retorno de Saldos da carteira de fechamento por período." + ex.Message);
            }
        }
    }
}