using System;
using System.Collections.Generic;
using System.Globalization;
using DadosAPI.Extensions;
using DadosAPI.Models;
using DadosAPI.Models.GerenciamentoSolicitacao;

namespace DadosAPI.Services {
    public class DetalharPoupancaService {
        private readonly RelatorioService _service;
        private readonly PrivateService _privateService;

        public DetalharPoupancaService (
            RelatorioService service,
            PrivateService privateService
        ) {
            _service = service;
            _privateService = privateService;
        }

        private string GetDataRetorno (SolicitacaoRelatorio solicitacao) {
            string _dataReferencia = solicitacao.DataReferencia;
            string _dataRetorno = "";
            string diaAuxilio = _dataReferencia.Substring (6, 2);
            string mesAuxilio = _dataReferencia.Substring (4, 2);
            string anoAuxilio = _dataReferencia.Substring (0, 4);
            var _dataAuxilio = diaAuxilio + "/" + (mesAuxilio.Length == 1 ? "0" + mesAuxilio : mesAuxilio) + "/" + anoAuxilio;

            string _mesAtual = DateTime.Now.Month.ToString ().Length == 1 ? "0" + DateTime.Now.Month.ToString () : DateTime.Now.Month.ToString ();
            string _anoAtual = DateTime.Now.Year.ToString ();

            if (!solicitacao.PosicaoDiaria && _dataReferencia.Substring (4, 2) == _mesAtual && _dataReferencia.Substring (0, 4) == _anoAtual) {
                throw (new Exception ("Cod:02 - Desculpe: Relatório não disponível para a referência solicitada."));
            } else {
                var dt = _dataAuxilio.ToDateTime ("dd/MM/yyyy");
                _dataRetorno = _service.ObterRetornoDataPosicao (_dataAuxilio, solicitacao.Segmento);

                if (_dataRetorno == null) {
                    throw (new Exception ("Cod:03 - Desculpe: Relatório não disponível para a referência solicitada."));
                }

                if (_dataRetorno.Substring (3, 2) + _dataReferencia.Substring (0, 4) != _dataReferencia.Substring (4, 2) + _dataRetorno.Substring (6, 4)) {
                    throw (new Exception ("Cod:04 - Desculpe: Relatório não disponível para a referência solicitada."));
                }
            }

            _dataAuxilio = _dataReferencia;
            _dataRetorno = _dataRetorno.Substring (6, 4) + _dataRetorno.Substring (3, 2) + _dataRetorno.Substring (0, 2);

            return _dataRetorno;
        }

        public DetalhamentoPoupanca GetData (SolicitacaoRelatorio solicitacao) {

            var _dataRetorno = GetDataRetorno (solicitacao);
            DetalhamentoPoupanca oDetPoup = new DetalhamentoPoupanca ();
            var _dtRef = string.Format ("{2}-{1}-{0}", _dataRetorno.Substring (6, 2), _dataRetorno.Substring (4, 2), _dataRetorno.Substring (0, 4));
            IEnumerable<DetalhamentoPoupanca> oDetPoupList;
            oDetPoupList = _service.ObterDetalhamentoPoupanca (solicitacao.Agencia.ToString (), solicitacao.Conta.ToString (), _dtRef);

            DetalhamentoPoupanca oPoup = new DetalhamentoPoupanca ();
            oDetPoup.DetalhamentoPoupancaList = new List<DetalhamentoPoupanca> ();
            foreach (var itemPoup in oDetPoupList) {
                DetalhamentoPoupanca oDPoup = new DetalhamentoPoupanca ();
                oDPoup.DataVencimento = string.Format ("{0}", itemPoup.DataVencimento.Substring (0, 10));
                oDPoup.Sld_Bruto = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N2}", itemPoup.Sld_Bruto);
                oDetPoup.DetalhamentoPoupancaList.Add (oDPoup);
            }

            return oDetPoup;
        }
    }
}