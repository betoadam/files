using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using DadosAPI.Models;
using DadosAPI.Models.GerenciamentoSolicitacao;

namespace DadosAPI.Services {
    public class DetalhamentoAcoesService {
        private readonly RelatorioService _service;
        private readonly PrivateService _privateService;

        public DetalhamentoAcoesService (
            RelatorioService service,
            PrivateService privateService
        ) {
            _service = service;
            _privateService = privateService;
        }
        public async Task<DetalhamentoAcoes> GetData (SolicitacaoRelatorio solicitacao) {

            DetalhamentoAcoes oDetAcao = new DetalhamentoAcoes ();
            List<DetalhamentoAcoes> oDetalhamentoAcaoList = new List<DetalhamentoAcoes> ();

            string _tipoLayout = "00";

            var _ativo = await _privateService.ObterAtivoCarteiraCliente (
                solicitacao.Sistema,
                solicitacao.Legado,
                solicitacao.Agencia.ToString (),
                solicitacao.Conta.ToString (),
                solicitacao.DataReferencia,
                _tipoLayout,
                solicitacao.Segmento);

            if (_ativo != null) {
                if (_ativo.StatusProcessamento.Code != 200) {
                    throw (new Exception (string.Format ("Erro no Serviço: {0} - {1}", "AtivoCarteira", _ativo.StatusProcessamento.Message)));
                }

                if (_ativo.LstBovespaCorretora[0].QuantidadeOcorrencias != -1) {
                    _ativo.LstBovespaCorretora = _ativo.LstBovespaCorretora.Where (x => x.IdentSeqFamilia != 0 && x.SaldoAtual > 0).ToList ();
                    foreach (var itemBov in _ativo.LstBovespaCorretora) {
                        DetalhamentoAcoes oDet = new DetalhamentoAcoes ();
                        oDet.Papel = itemBov.NomePapel;
                        oDet.Descricao = itemBov.DescricaoPapel;
                        oDet.Quantidade = itemBov.QuantidadeAtual;
                        oDet.Tipo = itemBov.SubProduto;
                        oDet.Cotacao = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N2}", itemBov.CotacaoAtual);
                        oDet.SaldoBruto = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N2}", itemBov.SaldoAtual);

                        oDetalhamentoAcaoList.Add (oDet);
                    }
                }
            }

            oDetAcao.DetalhamentoAcoesList = oDetalhamentoAcaoList;

            return oDetAcao;
        }
    }
}