using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using DadosAPI.Models;
using DadosAPI.Models.GerenciamentoSolicitacao;

namespace DadosAPI.Services {
    public class ContaCorrenteService {
        private readonly RelatorioService _service;
        private readonly PrivateService _privateService;

        public ContaCorrenteService (
            RelatorioService service,
            PrivateService privateService
        ) {
            _service = service;
            _privateService = privateService;
        }

        public async Task<ContaCorrente> GetData (SolicitacaoRelatorio solicitacao) {

            var oContaCorr = new ContaCorrente ();
            var oMovimentacaoContaCorrenteList = new List<ContaCorrente.MovimentacaoContaCorrente> ();
            var oMovRelCliList = new List<ContaCorrente.RelacionamentoCliente> ();

            string diaAuxilio = solicitacao.DataReferencia.Substring (6, 2);
            string mesAuxilio = solicitacao.DataReferencia.Substring (4, 2);
            string anoAuxilio = solicitacao.DataReferencia.Substring (0, 4);
            var _dataAuxilio = diaAuxilio + "/" + (mesAuxilio.Length == 1 ? "0" + mesAuxilio : mesAuxilio) + "/" + anoAuxilio;

            string _mesAtual = DateTime.Now.Month.ToString ().Length == 1 ? "0" + DateTime.Now.Month.ToString () : DateTime.Now.Month.ToString ();
            string _anoAtual = DateTime.Now.Year.ToString ();

            var _anomesref = anoAuxilio + mesAuxilio;

            string _tipoLayout = "00";

            var _contaCorrente = await _privateService.ObterContaCorrente (
                solicitacao.Sistema,
                solicitacao.Legado,
                solicitacao.Agencia.ToString (),
                solicitacao.Conta.ToString (),
                _tipoLayout,
                _anomesref);

            if (_contaCorrente != null) {
                if (_contaCorrente.StatusProcessamento.Code != 200) {
                    throw new Exception (string.Format ("Erro no Serviço: {0} - {1}", "ContaCorrente", _contaCorrente.StatusProcessamento.Message));
                }

                #region MovimentacaoContaCorrente
                if (_contaCorrente.LstMovimentacaoContaCorrente[0].QuantidadeOcorrencias != -1) {

                    foreach (var itemMovCC in _contaCorrente.LstMovimentacaoContaCorrente) {
                        var oDet = new ContaCorrente.MovimentacaoContaCorrente ();
                        oDet.SistemaOrigem = itemMovCC.SistemaOrigem;
                        oDet.Legado = itemMovCC.Legado;
                        oDet.Agencia = itemMovCC.Agencia;
                        oDet.Conta = itemMovCC.Conta;
                        oDet.AnoMesReferencia = itemMovCC.AnoMesReferencia;
                        oDet.TipoLayout = itemMovCC.TipoLayout;
                        oDet.DataMovimento = itemMovCC.DataMovimento != "" ? itemMovCC.DataMovimento.Substring (6, 2) + "/" + itemMovCC.DataMovimento.Substring (4, 2) + "/" + itemMovCC.DataMovimento.Substring (0, 4) : itemMovCC.DataMovimento;
                        oDet.DtMovimento = itemMovCC.DataMovimento != "" ? DateTime.ParseExact(itemMovCC.DataMovimento, "yyyyMMdd", System.Globalization.CultureInfo.InvariantCulture) : itemMovCC.DtMovimento;
                        oDet.DescricaoMovimento = itemMovCC.DescricaoMovimento;
                        oDet.SequenciaApresentacao = itemMovCC.SequenciaApresentacao;
                        oDet.AgenciaSegmentada = itemMovCC.AgenciaSegmentada;
                        oDet.QuantidadeOcorrencias = itemMovCC.QuantidadeOcorrencias;
                        oDet.StatusRetorno = itemMovCC.StatusRetorno;
                        oDet.NumeroDocumento = string.IsNullOrEmpty (itemMovCC.NumeroDocumento) ? "" : itemMovCC.NumeroDocumento;
                        oDet.ValorMovimento = itemMovCC.ValorMovimento;
                        oDet.SaldoAtualizado = itemMovCC.SaldoAtualizado;

                        oMovimentacaoContaCorrenteList.Add (oDet);
                    }

                }
                #endregion

                #region RelacionamentoCliente
                if (_contaCorrente.LstRelacionamentoCliente[0].QuantidadeOcorrencias != -1) {

                    foreach (var itemRCli in _contaCorrente.LstRelacionamentoCliente) {
                        var oDet = new ContaCorrente.RelacionamentoCliente ();
                        oDet.SistemaOrigem = itemRCli.SistemaOrigem;
                        oDet.Legado = itemRCli.Legado;
                        oDet.Agencia = itemRCli.Agencia;
                        oDet.Conta = itemRCli.Conta;
                        oDet.AnoMesReferencia = itemRCli.AnoMesReferencia;
                        oDet.TipoLayout = itemRCli.TipoLayout;
                        oDet.IdentificadorProdutoCredito = itemRCli.IdentificadorProdutoCredito;
                        oDet.DescricaoProdutoCredito = itemRCli.DescricaoProdutoCredito;
                        oDet.ValorLimite = itemRCli.ValorLimite;
                        oDet.DataVctoLimite = !string.IsNullOrEmpty (itemRCli.DataVctoLimite) ? itemRCli.DataVctoLimite.Substring (6, 2) + "/" + itemRCli.DataVctoLimite.Substring (4, 2) + "/" + itemRCli.DataVctoLimite.Substring (0, 4) : itemRCli.DataVctoLimite;
                        oDet.TaxaEfetivaMes = string.IsNullOrEmpty (itemRCli.TaxaEfetivaMes) ? "0" : itemRCli.TaxaEfetivaMes.Replace (".", ",");
                        oDet.TaxaEfetivaAno = string.IsNullOrEmpty (itemRCli.TaxaEfetivaAno) ? "0" : itemRCli.TaxaEfetivaAno.Replace (".", ",");
                        oDet.TaxaCustoEfetivoTotalMes = string.IsNullOrEmpty (itemRCli.TaxaCustoEfetivoTotalMes) ? "0" : itemRCli.TaxaCustoEfetivoTotalMes.Replace (".", ",");
                        oDet.TaxaCustoEfetivoTotalAno = string.IsNullOrEmpty (itemRCli.TaxaCustoEfetivoTotalAno) ? "0" : itemRCli.TaxaCustoEfetivoTotalAno.Replace (".", ",");

                        oMovRelCliList.Add (oDet);
                    }

                }

                #endregion

                #region SaldoContaCorrente
                if (_contaCorrente.LstSaldoContaCorrente[0].QuantidadeOcorrencias != -1) {
                    var oSldList = new List<ContaCorrente.SaldoContaCorrente> ();

                    foreach (var itemSld in _contaCorrente.LstSaldoContaCorrente) {
                        var oDet = new ContaCorrente.SaldoContaCorrente ();
                        oDet.SistemaOrigem = itemSld.SistemaOrigem;
                        oDet.Legado = itemSld.Legado;
                        oDet.Agencia = itemSld.Agencia;
                        oDet.Conta = itemSld.Conta;
                        oDet.AnoMesReferencia = itemSld.AnoMesReferencia;
                        oDet.TipoLayout = itemSld.TipoLayout;
                        oDet.AgenciaSegmentada = itemSld.AgenciaSegmentada;
                        oDet.TipoSaldo = itemSld.TipoSaldo;
                        oDet.DescricaoTipoSaldo = itemSld.DescricaoTipoSaldo;
                        oDet.ValorSaldo = itemSld.ValorSaldo;

                        oSldList.Add (oDet);
                    }
                    oContaCorr.LstSaldoContaCorrente = oSldList;
                }
                #endregion
            }

            oContaCorr.LstMovimentacaoContaCorrente = oMovimentacaoContaCorrenteList.OrderBy (x => x.DtMovimento).ToList ();
            oContaCorr.LstRelacionamentoCliente = oMovRelCliList;
            return oContaCorr;
        }
    }
}