using System;
using System.Collections.Generic;
using System.Linq;
using DadosAPI.Models;
using DadosAPI.Models.GerenciamentoSolicitacao;
using DadosAPI.Oracle;
using Microsoft.EntityFrameworkCore;
using Oracle.ManagedDataAccess.Client;

namespace DadosAPI.Services {
    public class RelatorioService {
        private readonly DatabaseContext _context;

        public RelatorioService (DatabaseContext context) {
            _context = context;
        }

        public string IndisponibilizarRelatorio () {
            var result = _context.Prvt014
                .Where (t014 => t014.CdParm == 55)
                .FirstOrDefault ();
            return result.TxtParm;
        }

        public int ValidarSegmento (int segmento, string sistema) {
            var result = _context.Prvt078
                .Where (t078 => t078.SglSistOrig.ToUpper () == sistema.ToUpper ())
                .Where (t078 => t078.CdSegm > 1)
                .Where (t078 => t078.CdSegm == segmento)
                .Count ();

            return result;
        }

        public string ObterExtremosMes (string _dtRef) {
            try {
                var year = _dtRef.Substring (6, 4);
                var month = _dtRef.Substring (3, 2);
                var days = DateTime.DaysInMonth (int.Parse (year), int.Parse (month));

                return days.ToString () + "/" + month + "/" + year;
            } catch (System.Exception ex) {
                throw new Exception ("Falha ao obter a data final: " + ex.Message);
            }
        }

        public string ObterDataCorte () {
            var result = _context.Prvt014
                .Where (t014 => t014.CdParm == 27)
                .FirstOrDefault ();

            return result.DtParm?.ToString ("dd/MM/yyyy");
        }

        public string ObterRegraMes (string dataReferencia) {
            var dataFechamento = "01" + "/" +
                dataReferencia.Substring (4, 2) + "/" +
                dataReferencia.Substring (0, 4);

            var result = _context.Prvt014
                .Select (f => DatabaseContext.PrvpfCalcDataUtil (dataFechamento, -1))
                .FirstOrDefault ();

            return result;
        }

        public string ObterLiberarDia () {
            var qtd = _context.Prvt014
                .Where (t014 => t014.CdParm == 28)
                .FirstOrDefault ()?.IdNumParm;

            var dataFechamento = "01" + "/" +
                DateTime.Now.Month.ToString ().PadLeft (2, '0') +
                int.Parse (DateTime.Now.Year.ToString ());

            var result = _context.Prvt014
                .Select (f => DatabaseContext.PrvpfCalcDataUtil (dataFechamento, qtd))
                .FirstOrDefault ();

            return result;
        }

        public int ObterRestricaoContaPiloto (string _agencia, string _conta) {
            var tbFiltro = _context.Prvt086
                .Where (t086 => t086.CdTGr == 2)
                .Count ();

            if (tbFiltro == 0) {
                return 1;
            } else {
                var cc = _context.Prvt086
                    .Where (t086 =>
                        (
                            t086.CdAg.ToString () == _agencia &&
                            t086.IdNumCc.ToString () == _conta &&
                            t086.CdAg == 2 &&
                            t086.IdNumCc != 0
                        ) ||
                        (
                            t086.CdAg.ToString () == _agencia &&
                            t086.CdTGr == 2 &&
                            t086.IdNumCc != 0
                        ) ||
                        (
                            t086.CdAg == 0 &&
                            t086.IdNumCc == 0 &&
                            t086.CdTGr == 2
                        )
                    )
                    .Count ();

                return cc;
            }
        }

        public int ObterRestricaoConta (string _agencia, string _conta, string mesReferencia) {
            var result = _context.Prvt086
                .Where (t086 => t086.CdTGr == 1002)
                .Where (t086 => t086.CdAg.ToString () == _agencia)
                .Where (t086 => t086.IdNumCc.ToString () == _conta)
                .Where (t086 => t086.AmRef == mesReferencia)
                .Count ();

            return result;
        }

        public string ObterRetornoDataPosicao (string _dtRef, string segmento) {
            //TODO: executar a maravilhosa procedure na m do oracle
            //   var pSistOrig = new OracleParameter("pSistOrig", OracleDbType.Varchar2);
            //   pSistOrig.Value = "EXT";
            //   var pDtRef = new OracleParameter("pDtRef", OracleDbType.Varchar2);
            //   pDtRef.Value = _dtRef;
            //   var pFuncionalidade = new OracleParameter("pFuncionalidade", OracleDbType.Varchar2);
            //   pFuncionalidade.Value = "InformacaoResumoConta";
            //   var pSegmento = new OracleParameter("pSegmento", OracleDbType.Varchar2);
            //   pSegmento.Value = segmento;
            //   var pRetorno = new OracleParameter("pRetorno", OracleDbType.Varchar2);
            //   pRetorno.Direction = ParameterDirection.InputOutput;

            //   _context.Database.ExecuteSqlCommand("prvpp_data_calculada ( @pSistOrig , @pDtRef , @pFuncionalidade , @pSegmento , @pRetorno )",
            //       pSistOrig,
            //       pDtRef,
            //       pFuncionalidade,
            //       pSegmento,
            //       pRetorno
            //   );

            //   return pRetorno.Value.ToString();
            return _dtRef;
        }

        public List<SolicitacaoTemplate> ObterPaginasTemplate (int _cdTmpl) {
            List<SolicitacaoTemplate> result = (
                from t076 in _context.Prvt076 
                join t075 in _context.Prvt075 on t076.CdTmpl equals t075.CdTmpl 
                join t073 in _context.Prvt073 on t076.CdPag equals t073.CdPag 
                join t074 in _context.Secao on t076.CdSecao equals t074.CD_SECAO where t073.IcStat == 'A' &&
                t074.IC_STAT == "A" &&
                t075.CdTmpl == _cdTmpl select new SolicitacaoTemplate {
                    Nm_Tmpl = t075.NmTmpl,
                    Tmpl_Stat = t075.IcStat.ToString (),
                    Nm_pag = t073.NmPag,
                    Pag_Stat = t073.IcStat.ToString (),
                    txt_desc_secao = t074.TXT_DESC_SECAO,
                    Sec_Stat = t074.TXT_DESC_SECAO
                }
            ).ToList ();

            return result;
        }

        public IEnumerable<DetalhamentoPoupanca> ObterDetalhamentoPoupanca (
            string _agencia,
            string _conta,
            string _datareferencia
        ) {
            List<DetalhamentoPoupanca> result = (
                from t071 in _context.Prvv071 where t071.Agencia.ToString () == _agencia &&
                t071.Conta.ToString () == _conta &&
                t071.DataVencimento.ToString ("yyyy-MM-dd") == _datareferencia select new DetalhamentoPoupanca {
                    DataVencimento = t071.DataVencimento.ToString ("yyyy-MM-dd"),
                        Sld_Bruto = t071.SldBruto
                }
            ).ToList ();

            return result;
        }

        public List<Secao> ObterSecoes () {
            List<Secao> secoes = _context.Secao.ToList ();

            var atributos = _context.AtributoSecao.ToList ();

            foreach (var secao in secoes)
                secao.Atributos = atributos.Where (x => x.CD_SECAO == secao.CD_SECAO).ToList ();

            return secoes;
        }

        public List<AtributoSecao> ObterAtributosSecao (int? codigoSecao = default (int?)) {
            if (codigoSecao == null)
                return _context.AtributoSecao.ToList ();

            return _context.AtributoSecao.Where (x => x.CD_SECAO == codigoSecao).ToList ();
        }

        public IEnumerable<AtributosSecao> ObterAtributosSecao () {
            var result = (
                from t079 in _context.AtributoSecao join t074 in _context.Secao on t079.CD_SECAO equals t074.CD_SECAO where t079.IC_STAT_ATRI_SECAO == "A" && t074.IC_STAT == "A"
                select new AtributosSecao {
                    Secao = t074.TXT_DESC_SECAO,
                        Campo = t079.ID_ATRI_SECAO
                }
            );

            return result;
        }

        public void RegistraLogRelatorio (string Agencia, string Conta, string UsuarioSolicitante, string mesSolicitado) {
            var pCodigoLog = new OracleParameter ("@pCodigoLog", "29");
            var pAgencia = new OracleParameter ("@pAgencia", Agencia);
            var pConta = new OracleParameter ("@pConta", Conta);
            var pTextAcao = new OracleParameter ("@pTextAcao", "RELATORIO_MENSAL");
            var pDataMvto = new OracleParameter ("@pDataMvto", DateTime.Now.ToString ("dd/MM/yyyy"));
            var pTextoDetalhe = new OracleParameter ("@pTextoDetalhe", "Relatório mensal gerado com sucesso, mês de referência: " + mesSolicitado);
            var pUsuario = new OracleParameter ("@pUsuario", UsuarioSolicitante);
            var pSglSistOrig = new OracleParameter ("@pSglSistOrig", "EXT");
            var pDataHoraAtu = new OracleParameter ("@pDataHoraAtu", DateTime.Now.ToString ("dd/MM/yyyy HH:mm:ss"));

            _context.Database.ExecuteSqlCommand ("PRVPI_T085_LOG_PRIVATE @pCodigoLog @pAgencia @pConta @pTextAcao @pDataMvto @pTextoDetalhe @pUsuario @pSglSistOrig @pDataHoraAtu",
                pCodigoLog,
                pAgencia,
                pConta,
                pTextAcao,
                pDataMvto,
                pTextoDetalhe,
                pUsuario,
                pSglSistOrig,
                pDataHoraAtu
            );
        }
    }
}