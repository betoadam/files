using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using DadosAPI.Models;
using DadosAPI.Models.GerenciamentoSolicitacao;

namespace DadosAPI.Services {
    public class DetalhamentoAtivosRendaFixaService {
        private readonly RelatorioService _service;
        private readonly PrivateService _privateService;

        public DetalhamentoAtivosRendaFixaService (
            RelatorioService service,
            PrivateService privateService
        ) {
            _service = service;
            _privateService = privateService;
        }

        public async Task<DetalhamentoAtivosRendaFixa> GetData (SolicitacaoRelatorio solicitacao) {
            DetalhamentoAtivosRendaFixa oDetRendaFixa = new DetalhamentoAtivosRendaFixa ();
            List<DetalhamentoAtivosRendaFixa> oDetalhamentoRendaFixaList = new List<DetalhamentoAtivosRendaFixa> ();

            string _tipoLayout = "00";

            var _ativo = await _privateService.ObterAtivoCarteiraCliente (
                solicitacao.Sistema,
                solicitacao.Legado,
                solicitacao.Agencia.ToString (),
                solicitacao.Conta.ToString (),
                solicitacao.DataReferencia,
                _tipoLayout,
                solicitacao.Segmento);

            if (_ativo != null) {
                if (_ativo.StatusProcessamento.Code != 200) {
                    throw (new Exception (string.Format ("Erro no Serviço: {0} - {1}", "AtivoCarteira", _ativo.StatusProcessamento.Message)));
                }

                if (_ativo.LstEmissaoTerceiro[0].QuantidadeOcorrencias != -1) {
                    _ativo.LstEmissaoTerceiro = _ativo.LstEmissaoTerceiro.Where (x => x.IdentSeqFamilia != 0).ToList ();

                    foreach (var itemEmissao in _ativo.LstEmissaoTerceiro) {
                        DetalhamentoAtivosRendaFixa oDet = new DetalhamentoAtivosRendaFixa ();
                        oDet.Ativo = itemEmissao.Ativo;
                        oDet.EmissorDevedor = itemEmissao.Emissor;
                        oDet.Indexador = itemEmissao.Indexador;
                        oDet.Taxa = itemEmissao.TaxaNegociada;
                        oDet.Percentual = itemEmissao.PercentualIndexador;
                        oDet.DataAplicacao = string.Format ("{0}/{1}/{2}", itemEmissao.DataAplicacao.Substring (6, 2), itemEmissao.DataAplicacao.Substring (4, 2), itemEmissao.DataAplicacao.Substring (0, 4));
                        oDet.VencimentoRepactuacao = string.IsNullOrEmpty (itemEmissao.DataRepactuacao) ? string.Format ("{0}/{1}/{2}", itemEmissao.DataVencimento.Substring (6, 2), itemEmissao.DataVencimento.Substring (4, 2), itemEmissao.DataVencimento.Substring (0, 4)) : string.Format ("{0}/{1}/{2}", itemEmissao.DataRepactuacao.Substring (6, 2), itemEmissao.DataRepactuacao.Substring (4, 2), itemEmissao.DataRepactuacao.Substring (0, 4));
                        oDet.SaldoAplicado = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N2}", itemEmissao.SaldoAplicado);
                        oDet.SaldoBruto = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N2}", itemEmissao.SaldoBruto);
                        oDet.ImpostoPrevisto = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N2}", itemEmissao.ImpostoPrevisto);
                        oDet.SaldoLiquido = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N2}", itemEmissao.SaldoLiquido);

                        oDetalhamentoRendaFixaList.Add (oDet);
                    }
                }

                if (_ativo.LstTesouroDiretoRendaFixa[0].QuantidadeOcorrencias != -1) {
                    _ativo.LstTesouroDiretoRendaFixa = _ativo.LstTesouroDiretoRendaFixa.Where (x => x.IdentSeqFamilia != 0).ToList ();

                    foreach (var itemTesouro in _ativo.LstTesouroDiretoRendaFixa) {
                        DetalhamentoAtivosRendaFixa oDet = new DetalhamentoAtivosRendaFixa ();
                        oDet.Ativo = itemTesouro.NomePapel;
                        oDet.EmissorDevedor = itemTesouro.Emissor;
                        oDet.Indexador = itemTesouro.IndexadorPapel;
                        oDet.Taxa = itemTesouro.TaxaNegociada;
                        oDet.Percentual = itemTesouro.PercentualIndexador;
                        oDet.DataAplicacao = string.IsNullOrEmpty (itemTesouro.DataAplicacao) ? "" : string.Format ("{0}/{1}/{2}", itemTesouro.DataAplicacao.Substring (6, 2), itemTesouro.DataAplicacao.Substring (4, 2), itemTesouro.DataAplicacao.Substring (0, 4));
                        oDet.VencimentoRepactuacao = string.Format ("{0}/{1}/{2}", itemTesouro.DataVencimento.Substring (6, 2), itemTesouro.DataVencimento.Substring (4, 2), itemTesouro.DataVencimento.Substring (0, 4));
                        oDet.SaldoAplicado = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N2}", itemTesouro.ValorAplicado);
                        oDet.SaldoBruto = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N2}", itemTesouro.SaldoAtual);
                        oDet.ImpostoPrevisto = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N2}", itemTesouro.ImpostoPrevisto);
                        oDet.SaldoLiquido = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N2}", itemTesouro.SaldoLiquido);

                        oDetalhamentoRendaFixaList.Add (oDet);
                    }
                }

                if (_ativo.LstTituloPublicoRendaFixa[0].QuantidadeOcorrencias != -1) {
                    _ativo.LstTituloPublicoRendaFixa = _ativo.LstTituloPublicoRendaFixa.Where (x => x.IdentSeqFamilia != 0).ToList ();

                    foreach (var itemRenda in _ativo.LstTituloPublicoRendaFixa) {
                        DetalhamentoAtivosRendaFixa oDet = new DetalhamentoAtivosRendaFixa ();
                        oDet.Ativo = itemRenda.NomePapel;
                        oDet.EmissorDevedor = itemRenda.Emissor;
                        oDet.Indexador = itemRenda.IndexadorPapel;
                        oDet.Taxa = itemRenda.TaxaNegociada;
                        oDet.Percentual = itemRenda.PercentualIndexador;
                        oDet.DataAplicacao = string.Format ("{0}/{1}/{2}", itemRenda.DataAplicacao.Substring (6, 2), itemRenda.DataAplicacao.Substring (4, 2), itemRenda.DataAplicacao.Substring (0, 4));
                        oDet.VencimentoRepactuacao = string.Format ("{0}/{1}/{2}", itemRenda.DataVencimento.Substring (6, 2), itemRenda.DataVencimento.Substring (4, 2), itemRenda.DataVencimento.Substring (0, 4));
                        oDet.SaldoAplicado = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N2}", itemRenda.ValorAplicado);
                        oDet.SaldoBruto = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N2}", itemRenda.SaldoAtual);
                        oDet.ImpostoPrevisto = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N2}", itemRenda.ImpostoPrevisto);
                        oDet.SaldoLiquido = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N2}", itemRenda.SaldoLiquido);

                        oDetalhamentoRendaFixaList.Add (oDet);
                    }
                }
            }
            oDetRendaFixa.DetalhamentoAtivosRendaFixaList = oDetalhamentoRendaFixaList;

            return oDetRendaFixa;
        }
    }
}