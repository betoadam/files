using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using DadosAPI.Models;
using DadosAPI.Models.GerenciamentoSolicitacao;

namespace DadosAPI.Services {
    public class InvestimentoComposicaoDetalhadaCorretoraService {
        private readonly RelatorioService _service;
        private readonly PrivateService _privateService;

        public InvestimentoComposicaoDetalhadaCorretoraService (
            RelatorioService service,
            PrivateService privateService
        ) {
            _service = service;
            _privateService = privateService;
        }
        public async Task<InvestimentoComposicaoDetalhada> GetData (SolicitacaoRelatorio solicitacao) {

            InvestimentoComposicaoDetalhada oInvestimentosComposicaoCorretora = new InvestimentoComposicaoDetalhada ();
            List<InvestimentoComposicaoDetalhada> oInvestimentoCorretoraList = new List<InvestimentoComposicaoDetalhada> ();

            //if (_segmento.InValue("22", "23", "77", "78")) //Segmento Private

            var _resumo = await _privateService.ObterInformacaoResumoConta (
                solicitacao.Sistema,
                solicitacao.Legado,
                solicitacao.Agencia.ToString (),
                solicitacao.Conta.ToString (),
                solicitacao.DataReferencia,
                solicitacao.Segmento);

            var _investimentoComposicao = _resumo;

            if (_investimentoComposicao != null) {
                if (_investimentoComposicao.StatusProcessamento.Code != 200) {
                    throw (new Exception (string.Format ("Erro no Serviço: {0} - {1}", "ResumoConta", _resumo.StatusProcessamento.Message)));
                }

                if (_investimentoComposicao.Conteudo[0].QuantidadeOcorrencias != -1) {
                    //Corretora                                
                    var resConteudoCorretora = _investimentoComposicao.Conteudo.Where (x => x.CodGrupoProduto != 999 &&
                            x.NomeRentabilidadePai == "Corretora" || x.NomeGrupoProduto == "Corretora")
                        .OrderBy (x => x.IdentSeqFamilia)
                        .ThenByDescending (x => x.OrdemApresentacaoPai)
                        .ThenBy (x => x.NomeGrupoProduto)
                        .ThenByDescending (x => x.IdentSeqGrupoProduto)
                        .ThenByDescending (x => x.OrdemApresentacaoProduto)
                        .ToList ();

                    if (resConteudoCorretora.Count () > 0) {
                        foreach (var itemResCorretora in resConteudoCorretora) {
                            InvestimentoComposicaoDetalhada oInvCorretora = new InvestimentoComposicaoDetalhada ();
                            oInvCorretora.DescricaoProduto = itemResCorretora.NomeGrupoProduto;
                            oInvCorretora.SaldoBrutoMesAnterior = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", itemResCorretora.SaldoBrutoAnterior);
                            oInvCorretora.SaldoBrutoMesAtual = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", itemResCorretora.SaldoBrutoAtual);
                            oInvCorretora.DataRetorno = itemResCorretora.DataRetorno.Substring (6, 2) + "/" + itemResCorretora.DataRetorno.Substring (4, 2) + "/" + itemResCorretora.DataRetorno.Substring (0, 4);
                            oInvCorretora.DataSaldoAnterior = itemResCorretora.DataSaldoAnterior.Substring (6, 2) + "/" + itemResCorretora.DataSaldoAnterior.Substring (4, 2) + "/" + itemResCorretora.DataSaldoAnterior.Substring (0, 4);
                            oInvCorretora.IsBold = itemResCorretora.CodRentabilidadePai == 999 ? "S" : "N";
                            oInvestimentoCorretoraList.Add (oInvCorretora);
                        }
                    }
                }
            }
            //Corretora
            oInvestimentosComposicaoCorretora.InvestimentoComposicaoDetalhadaList = oInvestimentoCorretoraList;

            return oInvestimentosComposicaoCorretora;
        }
    }
}