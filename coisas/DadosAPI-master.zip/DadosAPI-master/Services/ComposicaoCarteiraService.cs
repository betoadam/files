using System;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using DadosAPI.Models;
using DadosAPI.Models.GerenciamentoSolicitacao;

namespace DadosAPI.Services {
    public class ComposicaoCarteiraService {
        private readonly RelatorioService _service;
        private readonly PrivateService _privateService;

        public ComposicaoCarteiraService (
            RelatorioService service,
            PrivateService privateService
        ) {
            _service = service;
            _privateService = privateService;
        }

        public async Task<PosicaoInvestimentosCarteira> GetData (SolicitacaoRelatorio solicitacao) {

            PosicaoInvestimentosCarteira oPosicao = new PosicaoInvestimentosCarteira ();

            var _resumo = await _privateService.ObterInformacaoResumoConta (
                solicitacao.Sistema,
                solicitacao.Legado,
                solicitacao.Agencia.ToString (),
                solicitacao.Conta.ToString (),
                solicitacao.DataReferencia,
                solicitacao.Segmento);

            if (_resumo != null) {
                oPosicao.StatusSecao = new StatusSecao ();
                if (_resumo.StatusProcessamento.Code != 200) {
                    throw (new Exception (string.Format ("Erro no Serviço: {0} - {1}", "ResumoConta", _resumo.StatusProcessamento.Message)));
                }

                if (_resumo.Conteudo[0].QuantidadeOcorrencias != -1) {
                    var resumoConteudo = _resumo.Conteudo.Where (x => x.CodGrupoProduto == 999).ToList ();

                    oPosicao.Resumo = resumoConteudo[0].NomeGrupoProduto;
                    oPosicao.SaldoBrutoPatrimonio = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", resumoConteudo[0].SaldoBrutoAtual);
                    oPosicao.ImpostoPatrimonio = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", resumoConteudo[0].ImpostoPrevisto);
                    oPosicao.SaldoLiquidoPatrimonio = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", resumoConteudo[0].SaldoLiquido);

                    oPosicao.DtPosicao = _resumo.Conteudo[0].DataRetorno;
                }
            }

            var _retocorr = "S";
            var _codRent = "0000";
            var _indiceEquiv = "S";
            var _codIndice = "00";

            var _rentabilidadeFixo = await _privateService.ObterRentabilidadeFixo (
                solicitacao.Sistema,
                solicitacao.Legado,
                solicitacao.Agencia.ToString (),
                solicitacao.Conta.ToString (),
                solicitacao.DataReferencia,
                _codRent,
                solicitacao.Segmento,
                _retocorr);

            if (_rentabilidadeFixo != null) {
                if (_rentabilidadeFixo.StatusProcessamento.Code != 200) {
                    throw (new Exception (string.Format ("Erro no Serviço: {0} - {1}", "RentabilidadeFixo", _rentabilidadeFixo.StatusProcessamento.Message)));
                }

                if (_rentabilidadeFixo.Conteudo[0].QuantidadeOcorrencias != -1) {
                    var rentConteudo = _rentabilidadeFixo.Conteudo.Where (x => x.CodRentabilidade == 999).ToList ();

                    oPosicao.RentMes = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", rentConteudo[0].PercAcumuladoMes);
                    oPosicao.RentAno = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", rentConteudo[0].PercAcumuladoAno);
                    oPosicao.Rent12Meses = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", rentConteudo[0].PerAcumulado12M);
                    oPosicao.Rent24Meses = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", rentConteudo[0].PercAcumulado24M);
                    oPosicao.Rent36Meses = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", rentConteudo[0].PercAcumulado36M);
                    oPosicao.IndElegivelAno = rentConteudo[0].IndElegivelAno;
                    oPosicao.IndElegivel24M = rentConteudo[0].IndElegivel24M;
                    oPosicao.IndElegivel36M = rentConteudo[0].IndElegivel36M;

                }
            }

            var _benchMarkFixo = await _privateService.ObterBenchmarkFixo (
                solicitacao.Sistema,
                solicitacao.Legado,
                solicitacao.Agencia.ToString (),
                solicitacao.Conta.ToString (),
                solicitacao.DataReferencia,
                _codIndice,
                _indiceEquiv,
                solicitacao.Segmento,
                _retocorr);

            if (_benchMarkFixo != null) {
                if (_benchMarkFixo.StatusProcessamento.Code != 200) {
                    throw (new Exception (string.Format ("Erro no Serviço: {0} - {1}", "BenchMarkFixo", _benchMarkFixo.StatusProcessamento.Message)));
                }

                if (_benchMarkFixo.Conteudo[0].QuantidadeOcorrencias != -1) {
                    oPosicao.CDIMes = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", _benchMarkFixo.Conteudo[0].PercAcumuladoMes);
                    oPosicao.CDIAno = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", _benchMarkFixo.Conteudo[0].PercAcumuladoAno);
                    oPosicao.CDI12Meses = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", _benchMarkFixo.Conteudo[0].PerAcumulado12M);
                    oPosicao.CDI24Meses = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", _benchMarkFixo.Conteudo[0].PercAcumulado24M);
                    oPosicao.CDI36Meses = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", _benchMarkFixo.Conteudo[0].PercAcumulado36M);

                }
            }

            return oPosicao;
        }
    }
}