using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using DadosAPI.Models;
using DadosAPI.Models.GerenciamentoSolicitacao;

namespace DadosAPI.Services {
    public class RendimentoHistoricoProdutosService {
        private readonly RelatorioService _service;
        private readonly PrivateService _privateService;

        public RendimentoHistoricoProdutosService (
            RelatorioService service,
            PrivateService privateService
        ) {
            _service = service;
            _privateService = privateService;
        }

        public async Task<RendimentoHistoricoProdutos> GetData (SolicitacaoRelatorio solicitacao) {

            RendimentoHistoricoProdutos HistoricoProdutos = new RendimentoHistoricoProdutos ();
            List<RendimentoHistoricoProdutos> oRendHistProdList = new List<RendimentoHistoricoProdutos> ();

            DateTime _dataCompara = Convert.ToDateTime (
                string.Format ("{0}/{1}/{01}", solicitacao.DataReferencia.Substring (0, 4), solicitacao.DataReferencia.Substring (4, 2)));

            var _retocorr = "S";
            var _codRent = "0000";
            int _qtdmes = 12;
            string _indAcumulado = "N";

            var _rentabilidadeFlex = await _privateService.ObterRentabilidadeFlexivel (
                solicitacao.Sistema,
                solicitacao.Legado,
                solicitacao.Agencia.ToString (),
                solicitacao.Conta.ToString (),
                solicitacao.DataReferencia,
                _codRent,
                _qtdmes,
                _indAcumulado,
                solicitacao.Segmento,
                _retocorr);

            if (_rentabilidadeFlex != null) {
                if (_rentabilidadeFlex.StatusProcessamento.Code != 200) {
                    throw (new Exception (string.Format ("Erro no Serviço: {0} - {1}", "RentabilidadeFlexivel", _rentabilidadeFlex.StatusProcessamento.Message)));
                }

                if (_rentabilidadeFlex.Conteudo[0].QuantidadeOcorrencias != -1) {
                    var rentFlexConteudo = _rentabilidadeFlex.Conteudo.Where (x => x.CodRentabilidade != 999 && x.NomeRentabilidade != "ANALITICO" &&
                        (x.IdentSeqFamilia != null && x.IdentSeqGrupoProduto == null &&
                            x.IdentSeqProduto == null || x.IdentSeqFamilia != null &&
                            x.IdentSeqGrupoProduto != null && x.IdentSeqProduto != null)).ToList ();

                    rentFlexConteudo = rentFlexConteudo.OrderBy (x => x.IdentSeqFamilia)
                        .ThenByDescending (x => x.OrdemApresentacaoPai)
                        .ThenBy (x => x.NomeRentabilidade)
                        .ToList ();

                    var indices = rentFlexConteudo.Select (g => g.CodRentabilidade).Distinct ().ToList ();
                    var indice = 0;

                    int month = DateTime.Now.Month;
                    for (int i = 0; i < indices.Count; i++) {
                        indice = indices[i];
                        RendimentoHistoricoProdutos oRendimentoHistorico = new RendimentoHistoricoProdutos ();
                        foreach (var RendFlex in rentFlexConteudo) {
                            if (indice == RendFlex.CodRentabilidade) {
                                oRendimentoHistorico.Resumo = RendFlex.NomeRentabilidade;
                                oRendimentoHistorico.IdentSeqFamilia = RendFlex.IdentSeqFamilia;
                                oRendimentoHistorico.IdentSeqGrupoProduto = RendFlex.IdentSeqGrupoProduto;
                                oRendimentoHistorico.IdentSeqProduto = RendFlex.IdentSeqProduto;
                                if (RendFlex.dtAnoMesRef.Month == _dataCompara.AddMonths (-11).Month && RendFlex.dtAnoMesRef.Year == _dataCompara.AddMonths (-11).Year) {
                                    oRendimentoHistorico.Mes1 = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", RendFlex.PercRentabilidade);
                                }
                                if (RendFlex.dtAnoMesRef.Month == _dataCompara.AddMonths (-10).Month && RendFlex.dtAnoMesRef.Year == _dataCompara.AddMonths (-10).Year) {
                                    oRendimentoHistorico.Mes2 = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", RendFlex.PercRentabilidade);
                                }
                                if (RendFlex.dtAnoMesRef.Month == _dataCompara.AddMonths (-9).Month && RendFlex.dtAnoMesRef.Year == _dataCompara.AddMonths (-9).Year) {
                                    oRendimentoHistorico.Mes3 = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", RendFlex.PercRentabilidade);
                                }
                                if (RendFlex.dtAnoMesRef.Month == _dataCompara.AddMonths (-8).Month && RendFlex.dtAnoMesRef.Year == _dataCompara.AddMonths (-8).Year) {
                                    oRendimentoHistorico.Mes4 = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", RendFlex.PercRentabilidade);
                                }
                                if (RendFlex.dtAnoMesRef.Month == _dataCompara.AddMonths (-7).Month && RendFlex.dtAnoMesRef.Year == _dataCompara.AddMonths (-7).Year) {
                                    oRendimentoHistorico.Mes5 = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", RendFlex.PercRentabilidade);
                                }
                                if (RendFlex.dtAnoMesRef.Month == _dataCompara.AddMonths (-6).Month && RendFlex.dtAnoMesRef.Year == _dataCompara.AddMonths (-6).Year) {
                                    oRendimentoHistorico.Mes6 = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", RendFlex.PercRentabilidade);
                                }
                                if (RendFlex.dtAnoMesRef.Month == _dataCompara.AddMonths (-5).Month && RendFlex.dtAnoMesRef.Year == _dataCompara.AddMonths (-5).Year) {
                                    oRendimentoHistorico.Mes7 = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", RendFlex.PercRentabilidade);
                                }
                                if (RendFlex.dtAnoMesRef.Month == _dataCompara.AddMonths (-4).Month && RendFlex.dtAnoMesRef.Year == _dataCompara.AddMonths (-4).Year) {
                                    oRendimentoHistorico.Mes8 = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", RendFlex.PercRentabilidade);
                                }
                                if (RendFlex.dtAnoMesRef.Month == _dataCompara.AddMonths (-3).Month && RendFlex.dtAnoMesRef.Year == _dataCompara.AddMonths (-3).Year) {
                                    oRendimentoHistorico.Mes9 = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", RendFlex.PercRentabilidade);
                                }
                                if (RendFlex.dtAnoMesRef.Month == _dataCompara.AddMonths (-2).Month && RendFlex.dtAnoMesRef.Year == _dataCompara.AddMonths (-2).Year) {
                                    oRendimentoHistorico.Mes10 = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", RendFlex.PercRentabilidade);
                                }
                                if (RendFlex.dtAnoMesRef.Month == _dataCompara.AddMonths (-1).Month && RendFlex.dtAnoMesRef.Year == _dataCompara.AddMonths (-1).Year) {
                                    oRendimentoHistorico.Mes11 = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", RendFlex.PercRentabilidade);
                                }
                                if (RendFlex.dtAnoMesRef.Month == _dataCompara.Month && RendFlex.dtAnoMesRef.Year == _dataCompara.Year) {
                                    oRendimentoHistorico.Mes12 = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", RendFlex.PercRentabilidade);
                                }
                                oRendimentoHistorico.IsBold = RendFlex.IdentSeqGrupoProduto == null && RendFlex.IdentSeqProduto == null ? "S" : "N";
                            }
                        }
                        oRendHistProdList.Add (oRendimentoHistorico);
                    }
                }
            }

            var _rentabilidadeFixo = await _privateService.ObterRentabilidadeFixo (
                solicitacao.Sistema,
                solicitacao.Legado,
                solicitacao.Agencia.ToString (),
                solicitacao.Conta.ToString (),
                solicitacao.DataReferencia,
                _codRent,
                solicitacao.Segmento,
                _retocorr);

            if (_rentabilidadeFixo != null) {
                if (_rentabilidadeFixo.StatusProcessamento.Code != 200) {
                    throw (new Exception (string.Format ("Erro no Serviço: {0} - {1}", "RentabilidadeFixo", _rentabilidadeFixo.StatusProcessamento.Message)));
                }

                if (_rentabilidadeFixo.Conteudo[0].QuantidadeOcorrencias != -1) {
                    var rentFixoConteudo = _rentabilidadeFixo.Conteudo;

                    foreach (var itemRF in rentFixoConteudo) {
                        foreach (var itemRend in oRendHistProdList) {
                            if (itemRF.IdentSeqFamilia == itemRend.IdentSeqFamilia &&
                                itemRF.IdentSeqGrupoProduto == itemRend.IdentSeqGrupoProduto &&
                                itemRF.IdentSeqProduto == itemRend.IdentSeqProduto
                            ) {
                                itemRend.AcumAno = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", itemRF.PercAcumuladoAno);
                                itemRend.Acum12Meses = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", itemRF.PerAcumulado12M);
                                itemRend.Acum24Meses = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", itemRF.PercAcumulado24M);
                                itemRend.Acum36Meses = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", itemRF.PercAcumulado36M);
                            }
                        }
                    }
                }
            }

            HistoricoProdutos.RendimentoHistoricoProdutosList = oRendHistProdList;

            var total = HistoricoProdutos.RendimentoHistoricoProdutosList.Count + 2; //+2 referente ao header da table

            return HistoricoProdutos;
        }
    }
}