using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using DadosAPI.Models;
using DadosAPI.Models.GerenciamentoSolicitacao;

namespace DadosAPI.Services {
    public class InvestimentoComposicaoDetalhadaService {
        private readonly RelatorioService _service;
        private readonly PrivateService _privateService;

        public InvestimentoComposicaoDetalhadaService (
            RelatorioService service,
            PrivateService privateService
        ) {
            _service = service;
            _privateService = privateService;
        }
        public async Task<InvestimentoComposicaoDetalhada> GetData (SolicitacaoRelatorio solicitacao) {
            InvestimentoComposicaoDetalhada oInvestimentosComposicao = new InvestimentoComposicaoDetalhada ();
            List<InvestimentoComposicaoDetalhada> oInvestimentoList = new List<InvestimentoComposicaoDetalhada> ();

            var _resumo = await _privateService.ObterInformacaoResumoConta (
                solicitacao.Sistema,
                solicitacao.Legado,
                solicitacao.Agencia.ToString (),
                solicitacao.Conta.ToString (),
                solicitacao.DataReferencia,
                solicitacao.Segmento);

            var _investimentoComposicao = _resumo;

            if (_investimentoComposicao != null) {
                if (_investimentoComposicao.StatusProcessamento.Code != 200) {
                    throw (new Exception (string.Format ("Erro no Serviço: {0} - {1}", "ResumoConta", _resumo.StatusProcessamento.Message)));
                }

                if (_investimentoComposicao.Conteudo[0].QuantidadeOcorrencias != -1) {
                    var resConteudo = _investimentoComposicao.Conteudo.Where (x => x.CodGrupoProduto != 999 &&
                            x.NomeGrupoProduto.ToUpper () != "CORRETORA" && x.NomeRentabilidadePai.ToUpper () != "CORRETORA")
                        .OrderBy (x => x.IdentSeqFamilia)
                        .ThenByDescending (x => x.OrdemApresentacaoPai)
                        .ThenBy (x => x.NomeGrupoProduto)
                        .ThenByDescending (x => x.IdentSeqGrupoProduto)
                        .ThenByDescending (x => x.OrdemApresentacaoProduto)
                        .ToList ();

                    foreach (var itemRes in resConteudo) {
                        InvestimentoComposicaoDetalhada oInvComposicao = new InvestimentoComposicaoDetalhada ();
                        oInvComposicao.DescricaoProduto = itemRes.NomeGrupoProduto;
                        oInvComposicao.SaldoBrutoMesAnterior = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", itemRes.SaldoBrutoAnterior);
                        oInvComposicao.Aplicacao = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", itemRes.Aplicacao);
                        oInvComposicao.Resgate = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", itemRes.Resgate);
                        oInvComposicao.ImpostoIncorrido = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", itemRes.ImpostoIncorrido);
                        oInvComposicao.Rendimento = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", itemRes.Rendimento);
                        oInvComposicao.SaldoBrutoMesAtual = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", itemRes.SaldoBrutoAtual);
                        oInvComposicao.ImpostoPrevisto = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", itemRes.ImpostoPrevisto);
                        oInvComposicao.SaldoLiquido = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", itemRes.SaldoLiquido);
                        oInvComposicao.DataRetorno = itemRes.DataRetorno.Substring (6, 2) + "/" + itemRes.DataRetorno.Substring (4, 2) + "/" + itemRes.DataRetorno.Substring (0, 4);
                        oInvComposicao.DataSaldoAnterior = itemRes.DataSaldoAnterior.Substring (6, 2) + "/" + itemRes.DataSaldoAnterior.Substring (4, 2) + "/" + itemRes.DataSaldoAnterior.Substring (0, 4);
                        oInvComposicao.CodGrupoProduto = itemRes.CodGrupoProduto;
                        oInvComposicao.IdentSeqFamilia = itemRes.IdentSeqFamilia;
                        oInvComposicao.IdentSeqGrupoProduto = itemRes.IdentSeqGrupoProduto;
                        oInvComposicao.IdentSeqProduto = itemRes.IdentSeqProduto;
                        oInvComposicao.IsBold = itemRes.CodRentabilidadePai == 999 ? "S" : "N";
                        oInvestimentoList.Add (oInvComposicao);
                    }
                }
            }
            oInvestimentosComposicao.InvestimentoComposicaoDetalhadaList = oInvestimentoList;

            return oInvestimentosComposicao;
        }
    }
}