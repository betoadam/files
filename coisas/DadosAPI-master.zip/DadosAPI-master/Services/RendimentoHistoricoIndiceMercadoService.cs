using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using DadosAPI.Models;
using DadosAPI.Models.GerenciamentoSolicitacao;

namespace DadosAPI.Services {
    public class RendimentoHistoricoIndiceMercadoService {
        private readonly RelatorioService _service;
        private readonly PrivateService _privateService;

        public RendimentoHistoricoIndiceMercadoService (
            RelatorioService service,
            PrivateService privateService
        ) {
            _service = service;
            _privateService = privateService;
        }
        public async Task<RendimentoHistoricoIndiceMercado> GetData (SolicitacaoRelatorio solicitacao) {
            RendimentoHistoricoIndiceMercado IndiceMercado = new RendimentoHistoricoIndiceMercado ();
            List<RendimentoHistoricoIndiceMercado> oRendIndiceList = new List<RendimentoHistoricoIndiceMercado> ();

            var _retocorr = "S";
            var _codIndice = "00";
            int _qtdmes = 12;
            string _indAcumulado = "N";

            RendimentoHistoricoCarteira oRendCart = new RendimentoHistoricoCarteira ();
            List<RendimentoHistoricoCarteira> oRendCartList = new List<RendimentoHistoricoCarteira> ();

            var _indiceAcumulado = await _privateService.ObterIndiceAcumulado (
                solicitacao.Sistema,
                solicitacao.Legado,
                solicitacao.Agencia.ToString (),
                solicitacao.Conta.ToString (),
                solicitacao.DataReferencia,
                _codIndice,
                _qtdmes,
                _indAcumulado,
                solicitacao.Segmento);
            #region RendimentoHistoricoIndiceMercado

            if (_indiceAcumulado != null) {
                if (_indiceAcumulado.StatusProcessamento.Code != 200) {
                    throw (new Exception (string.Format ("Erro no Serviço: {0} - {1}", "IndiceAcumulado", _indiceAcumulado.StatusProcessamento.Message)));
                }

                if (_indiceAcumulado.Conteudo[0].QuantidadeOcorrencias != -1) {
                    var indAcumConteudo = _indiceAcumulado.Conteudo.Where (x => x.CodIndice == "2" || x.CodIndice == "56" || x.CodIndice == "6")
                        .OrderBy (x => x.CodIndice).ToList ();
                    var indices = indAcumConteudo.Select (g => g.CodIndice).Distinct ().ToList ();
                    var indice = "0";

                    DateTime _dataCompara = Convert.ToDateTime (
                        string.Format (
                            "{0}/{1}/01",
                            solicitacao.DataReferencia.Substring (0, 4),
                            solicitacao.DataReferencia.Substring (4, 2)));
                    _dataCompara.AddMonths (1);

                    int month = DateTime.Now.Month;
                    for (int i = 0; i < indices.Count; i++) {
                        indice = indices[i];
                        RendimentoHistoricoIndiceMercado oRendimentoHistorico = new RendimentoHistoricoIndiceMercado ();
                        foreach (var indAcum in indAcumConteudo) {
                            if (indice == indAcum.CodIndice) {
                                oRendimentoHistorico.Resumo = indAcum.NomeIndice;
                                oRendimentoHistorico.CodIndice = indAcum.CodIndice;

                                if (indAcum.dtAnoMesRef.Month == _dataCompara.AddMonths (-11).Month && indAcum.dtAnoMesRef.Year == _dataCompara.AddMonths (-11).Year) {
                                    oRendimentoHistorico.Mes1 = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", indAcum.PercIndice);
                                }
                                if (indAcum.dtAnoMesRef.Month == _dataCompara.AddMonths (-10).Month && indAcum.dtAnoMesRef.Year == _dataCompara.AddMonths (-10).Year) {
                                    oRendimentoHistorico.Mes2 = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", indAcum.PercIndice);
                                }
                                if (indAcum.dtAnoMesRef.Month == _dataCompara.AddMonths (-9).Month && indAcum.dtAnoMesRef.Year == _dataCompara.AddMonths (-9).Year) {
                                    oRendimentoHistorico.Mes3 = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", indAcum.PercIndice);
                                }
                                if (indAcum.dtAnoMesRef.Month == _dataCompara.AddMonths (-8).Month && indAcum.dtAnoMesRef.Year == _dataCompara.AddMonths (-8).Year) {
                                    oRendimentoHistorico.Mes4 = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", indAcum.PercIndice);
                                }
                                if (indAcum.dtAnoMesRef.Month == _dataCompara.AddMonths (-7).Month && indAcum.dtAnoMesRef.Year == _dataCompara.AddMonths (-7).Year) {
                                    oRendimentoHistorico.Mes5 = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", indAcum.PercIndice);
                                }
                                if (indAcum.dtAnoMesRef.Month == _dataCompara.AddMonths (-6).Month && indAcum.dtAnoMesRef.Year == _dataCompara.AddMonths (-6).Year) {
                                    oRendimentoHistorico.Mes6 = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", indAcum.PercIndice);
                                }
                                if (indAcum.dtAnoMesRef.Month == _dataCompara.AddMonths (-5).Month && indAcum.dtAnoMesRef.Year == _dataCompara.AddMonths (-5).Year) {
                                    oRendimentoHistorico.Mes7 = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", indAcum.PercIndice);
                                }
                                if (indAcum.dtAnoMesRef.Month == _dataCompara.AddMonths (-4).Month && indAcum.dtAnoMesRef.Year == _dataCompara.AddMonths (-4).Year) {
                                    oRendimentoHistorico.Mes8 = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", indAcum.PercIndice);
                                }
                                if (indAcum.dtAnoMesRef.Month == _dataCompara.AddMonths (-3).Month && indAcum.dtAnoMesRef.Year == _dataCompara.AddMonths (-3).Year) {
                                    oRendimentoHistorico.Mes9 = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", indAcum.PercIndice);
                                }
                                if (indAcum.dtAnoMesRef.Month == _dataCompara.AddMonths (-2).Month && indAcum.dtAnoMesRef.Year == _dataCompara.AddMonths (-2).Year) {
                                    oRendimentoHistorico.Mes10 = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", indAcum.PercIndice);
                                }
                                if (indAcum.dtAnoMesRef.Month == _dataCompara.AddMonths (-1).Month && indAcum.dtAnoMesRef.Year == _dataCompara.AddMonths (-1).Year) {
                                    oRendimentoHistorico.Mes11 = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", indAcum.PercIndice);
                                }
                                if (indAcum.dtAnoMesRef.Month == _dataCompara.Month && indAcum.dtAnoMesRef.Year == _dataCompara.Year) {
                                    oRendimentoHistorico.Mes12 = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", indAcum.PercIndice);
                                }
                            }
                        }
                        oRendIndiceList.Add (oRendimentoHistorico);
                    }
                }
            }

            var _indiceEquiv = "N";
            var _benchMarkFixo = await _privateService.ObterBenchmarkFixo (
                solicitacao.Sistema,
                solicitacao.Legado,
                solicitacao.Agencia.ToString (),
                solicitacao.Conta.ToString (),
                solicitacao.DataReferencia,
                _codIndice,
                _indiceEquiv,
                solicitacao.Segmento,
                _retocorr
            );
            if (_benchMarkFixo != null) {
                if (_benchMarkFixo.StatusProcessamento.Code != 200) {
                    throw (new Exception (string.Format ("Erro no Serviço: {0} - {1}", "BenchMarkFixo", _benchMarkFixo.StatusProcessamento.Message)));
                }

                if (_benchMarkFixo.Conteudo[0].QuantidadeOcorrencias != -1) {
                    foreach (var RendList in oRendIndiceList) {
                        if (RendList.CodIndice == "2") {
                            RendList.Acum12Meses = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", _benchMarkFixo.Conteudo.Where (x => x.CodIndice == "2").FirstOrDefault ().PerAcumulado12M);
                            RendList.AcumAno = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", _benchMarkFixo.Conteudo.Where (x => x.CodIndice == "2").FirstOrDefault ().PercAcumuladoAno);
                            RendList.Acum24Meses = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", _benchMarkFixo.Conteudo.Where (x => x.CodIndice == "2").FirstOrDefault ().PercAcumulado24M);
                            RendList.Acum36Meses = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", _benchMarkFixo.Conteudo.Where (x => x.CodIndice == "2").FirstOrDefault ().PercAcumulado36M);

                        } else if (RendList.CodIndice == "56") {
                            RendList.Acum12Meses = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", _benchMarkFixo.Conteudo.Where (x => x.CodIndice == "56").FirstOrDefault ().PerAcumulado12M);
                            RendList.AcumAno = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", _benchMarkFixo.Conteudo.Where (x => x.CodIndice == "56").FirstOrDefault ().PercAcumuladoAno);
                            RendList.Acum24Meses = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", _benchMarkFixo.Conteudo.Where (x => x.CodIndice == "56").FirstOrDefault ().PercAcumulado24M);
                            RendList.Acum36Meses = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", _benchMarkFixo.Conteudo.Where (x => x.CodIndice == "56").FirstOrDefault ().PercAcumulado36M);
                        } else if (RendList.CodIndice == "6") {
                            RendList.Acum12Meses = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", _benchMarkFixo.Conteudo.Where (x => x.CodIndice == "6").FirstOrDefault ().PerAcumulado12M);
                            RendList.AcumAno = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", _benchMarkFixo.Conteudo.Where (x => x.CodIndice == "6").FirstOrDefault ().PercAcumuladoAno);
                            RendList.Acum24Meses = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", _benchMarkFixo.Conteudo.Where (x => x.CodIndice == "6").FirstOrDefault ().PercAcumulado24M);
                            RendList.Acum36Meses = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", _benchMarkFixo.Conteudo.Where (x => x.CodIndice == "6").FirstOrDefault ().PercAcumulado36M);
                        }
                    }
                }
            }

            IndiceMercado.RendimentoHistoricoIndiceMercadoList = oRendIndiceList;
            #endregion

            return IndiceMercado;
        }
    }
}