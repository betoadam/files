using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using DadosAPI.Models;
using DadosAPI.Models.GerenciamentoSolicitacao;

namespace DadosAPI.Services {
    public class DetalhamentoFundosInvestimentoService {
        private readonly RelatorioService _service;
        private readonly PrivateService _privateService;

        public DetalhamentoFundosInvestimentoService (
            RelatorioService service,
            PrivateService privateService
        ) {
            _service = service;
            _privateService = privateService;
        }
        public async Task<DetalhamentoFundosInvestimento> GetData (SolicitacaoRelatorio solicitacao) {
            DetalhamentoFundosInvestimento oDetalhamento = new DetalhamentoFundosInvestimento ();
            List<DetalhamentoFundosInvestimento> oDetalhamentoList = new List<DetalhamentoFundosInvestimento> ();

            string _tipoLayout = "00";

            var _ativo = await _privateService.ObterAtivoCarteiraCliente (
                solicitacao.Sistema,
                solicitacao.Legado,
                solicitacao.Agencia.ToString (),
                solicitacao.Conta.ToString (),
                solicitacao.DataReferencia,
                _tipoLayout,
                solicitacao.Segmento);

            if (_ativo != null) {
                oDetalhamento.StatusSecao = new StatusSecao ();
                if (_ativo.StatusProcessamento.Code != 200) {
                    throw (new Exception (string.Format ("Erro no Serviço: {0} - {1}", "AtivoCarteira", _ativo.StatusProcessamento.Message)));
                }

                if (_ativo.LstFundoInvestimento[0].QuantidadeOcorrencias != -1) {

                    _ativo.LstFundoInvestimento = _ativo.LstFundoInvestimento.OrderBy (x => x.IdentSeqFamilia)
                        .ThenBy (x => x.OrdemGrupoProduto)
                        .ThenByDescending (x => x.TipoLayoutApresentar)
                        .ThenBy (x => x.NomeFundo).ToList ();

                    foreach (var itemFundo in _ativo.LstFundoInvestimento) {
                        DetalhamentoFundosInvestimento oDet = new DetalhamentoFundosInvestimento ();

                        if (string.IsNullOrEmpty (itemFundo.NomeFundo)) {
                            oDet.Fundos = itemFundo.NomeGrupo;
                            oDet.IsBold = "S";
                        } else {
                            oDet.Fundos = itemFundo.NomeFundo;
                            oDet.QtdeCotas = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N6}", itemFundo.QtdCotas);
                            oDet.ValorCotas = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N6}", itemFundo.ValorCota);
                            oDet.SaldoAplicado = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N2}", itemFundo.SaldoAplicado);
                            oDet.SaldoBruto = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N2}", itemFundo.SaldoBruto);
                            oDet.ImpostoPrevisto = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N2}", itemFundo.ImpostoPrevisto);
                            oDet.SaldoLiquido = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N2}", itemFundo.SaldoLiquido);
                            oDet.IsBold = "N";
                        }
                        oDetalhamentoList.Add (oDet);
                    }
                }

                if (_ativo.LstPrevidencia[0].QuantidadeOcorrencias != -1) {
                    _ativo.LstPrevidencia = _ativo.LstPrevidencia.OrderBy (x => x.IdentSeqFamilia)
                        .ThenBy (x => x.IdentSeqGrupoProduto)
                        .ThenBy (x => x.IdentSeqProduto).ToList ();

                    foreach (var itemPrev in _ativo.LstPrevidencia) {
                        DetalhamentoFundosInvestimento oDet = new DetalhamentoFundosInvestimento ();

                        if (string.IsNullOrEmpty (itemPrev.PlanoPrevidencia)) {
                            oDet.Fundos = itemPrev.NomeGrupo;
                            oDet.IsBold = "S";
                        } else {
                            oDet.Fundos = itemPrev.PlanoPrevidencia;
                            oDet.QtdeCotas = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N6}", itemPrev.QuantidadeCota);
                            oDet.ValorCotas = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N6}", itemPrev.ValorCota);
                            oDet.SaldoAplicado = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N2}", itemPrev.ValorAplicado);
                            oDet.SaldoBruto = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N2}", itemPrev.SaldoBruto);
                            oDet.ImpostoPrevisto = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N2}", itemPrev.ValorImpPrevisto);
                            oDet.SaldoLiquido = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N2}", itemPrev.SaldoLiquido);
                            oDet.IsBold = "N";
                        }
                        oDetalhamentoList.Add (oDet);
                    }
                }
                oDetalhamento.DetalhamentoFundosInvestimentoList = oDetalhamentoList;
            }

            return oDetalhamento;
        }
    }
}