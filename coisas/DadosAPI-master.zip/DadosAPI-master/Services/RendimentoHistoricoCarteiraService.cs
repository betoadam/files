using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using DadosAPI.Dtos;
using DadosAPI.Extensions;
using DadosAPI.Models;
using DadosAPI.Models.GerenciamentoSolicitacao;

namespace DadosAPI.Services {
    public class RendimentoHistoricoCarteiraService {
        private readonly RelatorioService _service;
        private readonly PrivateService _privateService;

        public RendimentoHistoricoCarteiraService (
            RelatorioService service,
            PrivateService privateService
        ) {
            _service = service;
            _privateService = privateService;
        }

        public async Task<RendimentoHistoricoCarteira> GetData (SolicitacaoRelatorio solicitacao) {

            RendimentoHistoricoCarteira oRendCart = new RendimentoHistoricoCarteira ();
            List<RendimentoHistoricoCarteira> oRendCartList = new List<RendimentoHistoricoCarteira> ();

            DateTime _dataCompara = Convert.ToDateTime (string.Format ("{0}/{1}/01", solicitacao.DataReferencia.Substring (0, 4), solicitacao.DataReferencia.Substring (4, 2)));
            //_dataCompara.AddMonths(1);

            var _retocorr = "S";
            var _codRent = "999";
            var _codIndice = "02";
            var _qtdmes = 12;
            var _indAcumulado = "S";
            var _segmento = solicitacao.Segmento;

            var _rentabilidadeFlex = await _privateService.ObterRentabilidadeFlexivel (
                solicitacao.Sistema,
                solicitacao.Legado,
                solicitacao.Agencia.ToString (),
                solicitacao.Conta.ToString (),
                solicitacao.DataReferencia,
                _codRent,
                _qtdmes,
                _indAcumulado,
                _segmento,
                _retocorr);

            //Carteira
            RendimentoHistoricoCarteira Carteira = new RendimentoHistoricoCarteira ();
            if (_rentabilidadeFlex != null) {
                if (_rentabilidadeFlex.StatusProcessamento.Code != 200) {
                    throw (new Exception (string.Format ("Erro no Serviço: {0} - {1}", "RentabilidadeFlexivel", _rentabilidadeFlex.StatusProcessamento.Message)));
                }

                if (_rentabilidadeFlex.Conteudo[0].QuantidadeOcorrencias != -1) {
                    var rentFlexConteudo = _rentabilidadeFlex.Conteudo.Where (x => x.CodRentabilidade == 999).ToList ();

                    Carteira.Resumo = rentFlexConteudo.FirstOrDefault ().NomeRentabilidade;

                    var numero = 0;

                    for (int i = -11, mes = 1; i <= 0; i++, mes++) {
                        numero++;

                        var dc = _dataCompara.AddMonths (i);

                        //Caso não haja índice, não se adiciona itens à lista
                        if (!rentFlexConteudo.Any (x => x.dtAnoMesRef.Month == dc.Month &&
                                x.dtAnoMesRef.Year == dc.Year))
                            continue;

                        var registro = new TransferRow<string, string> ()
                            .Set ("Numero", numero.ToString ())
                            .Set ("Label", $"{dc.MonthName().Substring(0, 3)}/{dc.ToString("yy")}")
                            .Set ("Valor", string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}",
                                rentFlexConteudo.Where (x => x.dtAnoMesRef.Month == dc.Month &&
                                    x.dtAnoMesRef.Year == dc.Year).Sum (x => x.PercRentabilidade)));

                        Carteira.Itens.Add (registro);
                    }

                    Carteira.Mes1 = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", rentFlexConteudo.Where (x => x.dtAnoMesRef.Month == _dataCompara.AddMonths (-11).Month && x.dtAnoMesRef.Year == _dataCompara.AddMonths (-11).Year).Sum (x => x.PercRentabilidade));
                    Carteira.Mes2 = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", rentFlexConteudo.Where (x => x.dtAnoMesRef.Month == _dataCompara.AddMonths (-10).Month && x.dtAnoMesRef.Year == _dataCompara.AddMonths (-10).Year).Sum (x => x.PercRentabilidade));
                    Carteira.Mes3 = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", rentFlexConteudo.Where (x => x.dtAnoMesRef.Month == _dataCompara.AddMonths (-9).Month && x.dtAnoMesRef.Year == _dataCompara.AddMonths (-9).Year).Sum (x => x.PercRentabilidade));
                    Carteira.Mes4 = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", rentFlexConteudo.Where (x => x.dtAnoMesRef.Month == _dataCompara.AddMonths (-8).Month && x.dtAnoMesRef.Year == _dataCompara.AddMonths (-8).Year).Sum (x => x.PercRentabilidade));
                    Carteira.Mes5 = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", rentFlexConteudo.Where (x => x.dtAnoMesRef.Month == _dataCompara.AddMonths (-7).Month && x.dtAnoMesRef.Year == _dataCompara.AddMonths (-7).Year).Sum (x => x.PercRentabilidade));
                    Carteira.Mes6 = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", rentFlexConteudo.Where (x => x.dtAnoMesRef.Month == _dataCompara.AddMonths (-6).Month && x.dtAnoMesRef.Year == _dataCompara.AddMonths (-6).Year).Sum (x => x.PercRentabilidade));
                    Carteira.Mes7 = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", rentFlexConteudo.Where (x => x.dtAnoMesRef.Month == _dataCompara.AddMonths (-5).Month && x.dtAnoMesRef.Year == _dataCompara.AddMonths (-5).Year).Sum (x => x.PercRentabilidade));
                    Carteira.Mes8 = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", rentFlexConteudo.Where (x => x.dtAnoMesRef.Month == _dataCompara.AddMonths (-4).Month && x.dtAnoMesRef.Year == _dataCompara.AddMonths (-4).Year).Sum (x => x.PercRentabilidade));
                    Carteira.Mes9 = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", rentFlexConteudo.Where (x => x.dtAnoMesRef.Month == _dataCompara.AddMonths (-3).Month && x.dtAnoMesRef.Year == _dataCompara.AddMonths (-3).Year).Sum (x => x.PercRentabilidade));
                    Carteira.Mes10 = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", rentFlexConteudo.Where (x => x.dtAnoMesRef.Month == _dataCompara.AddMonths (-2).Month && x.dtAnoMesRef.Year == _dataCompara.AddMonths (-2).Year).Sum (x => x.PercRentabilidade));
                    Carteira.Mes11 = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", rentFlexConteudo.Where (x => x.dtAnoMesRef.Month == _dataCompara.AddMonths (-1).Month && x.dtAnoMesRef.Year == _dataCompara.AddMonths (-1).Year).Sum (x => x.PercRentabilidade));
                    Carteira.Mes12 = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", rentFlexConteudo.Where (x => x.dtAnoMesRef.Month == _dataCompara.Month && x.dtAnoMesRef.Year == _dataCompara.Year).Sum (x => x.PercRentabilidade));
                }
            }

            var _rentabilidadeFixo = await _privateService.ObterRentabilidadeFixo (
                solicitacao.Sistema,
                solicitacao.Legado,
                solicitacao.Agencia.ToString (),
                solicitacao.Conta.ToString (),
                solicitacao.DataReferencia,
                _codRent,
                solicitacao.Segmento,
                _retocorr);

            if (_rentabilidadeFixo != null) {
                if (_rentabilidadeFixo.StatusProcessamento.Code != 200) {
                    throw (new Exception (string.Format ("Erro no Serviço: {0} - {1}", "RentabilidadeFixo", _rentabilidadeFixo.StatusProcessamento.Message)));
                }

                if (_rentabilidadeFixo.Conteudo[0].QuantidadeOcorrencias != -1) {
                    var rentConteudo = _rentabilidadeFixo.Conteudo.Where (x => x.CodRentabilidade == 999).ToList ();

                    Carteira.AcumAno = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", rentConteudo[0].PercAcumuladoAno);
                    Carteira.Acum12Meses = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", rentConteudo[0].PerAcumulado12M);
                    Carteira.Acum24Meses = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", rentConteudo[0].PercAcumulado24M);
                    Carteira.Acum36Meses = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", rentConteudo[0].PercAcumulado36M);
                }
            }

            if (!string.IsNullOrEmpty (Carteira.Resumo)) {
                oRendCartList.Add (Carteira);
            }

            _codIndice = "02";
            _indAcumulado = "N";
            var _indiceEquivalente = await _privateService.ObterIndiceEquivalente (
                solicitacao.Sistema,
                solicitacao.Legado,
                solicitacao.Agencia.ToString (),
                solicitacao.Conta.ToString (),
                solicitacao.DataReferencia,
                _codIndice,
                _qtdmes,
                _indAcumulado,
                _segmento,
                _retocorr);

            //CDI
            RendimentoHistoricoCarteira CDI = new RendimentoHistoricoCarteira ();
            if (_indiceEquivalente != null) {
                if (_indiceEquivalente.StatusProcessamento.Code != 200) {
                    throw (new Exception (string.Format ("Erro no Serviço: {0} - {1}", "IndiceEquivalente", _indiceEquivalente.StatusProcessamento.Message)));
                }

                if (_indiceEquivalente.Conteudo[0].QuantidadeOcorrencias != -1) {
                    var indicEquConteudo = _indiceEquivalente.Conteudo.Where (x => x.CodIndice == "2").ToList ();

                    for (int i = -11; i <= 0; i++) {
                        var dc = _dataCompara.AddMonths (i);

                        if (!_rentabilidadeFlex.Conteudo.Where (x => x.CodRentabilidade == 999).Any (x => x.dtAnoMesRef.Month == dc.Month &&
                                x.dtAnoMesRef.Year == dc.Year))
                            continue;

                        var registro = new TransferRow<string, string> ()
                            .Set ("Label", $"{dc.MonthName().Substring(0, 3)}/{dc.ToString("yy")}")
                            .Set ("Valor", string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}",
                                indicEquConteudo.Where (x => x.dtAnoMesRef.Month == dc.Month &&
                                    x.dtAnoMesRef.Year == dc.Year).Sum (x => x.PercRentabilidade)));

                        CDI.Itens.Add (registro);
                    }

                    CDI.Resumo = "% CDI EQUIVALENTE";
                    CDI.Mes1 = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", indicEquConteudo.Where (x => x.dtAnoMesRef.Month == _dataCompara.AddMonths (-11).Month && x.dtAnoMesRef.Year == _dataCompara.AddMonths (-11).Year).Sum (x => x.PercRentabilidade));
                    CDI.Mes2 = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", indicEquConteudo.Where (x => x.dtAnoMesRef.Month == _dataCompara.AddMonths (-10).Month && x.dtAnoMesRef.Year == _dataCompara.AddMonths (-10).Year).Sum (x => x.PercRentabilidade));
                    CDI.Mes3 = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", indicEquConteudo.Where (x => x.dtAnoMesRef.Month == _dataCompara.AddMonths (-9).Month && x.dtAnoMesRef.Year == _dataCompara.AddMonths (-9).Year).Sum (x => x.PercRentabilidade));
                    CDI.Mes4 = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", indicEquConteudo.Where (x => x.dtAnoMesRef.Month == _dataCompara.AddMonths (-8).Month && x.dtAnoMesRef.Year == _dataCompara.AddMonths (-8).Year).Sum (x => x.PercRentabilidade));
                    CDI.Mes5 = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", indicEquConteudo.Where (x => x.dtAnoMesRef.Month == _dataCompara.AddMonths (-7).Month && x.dtAnoMesRef.Year == _dataCompara.AddMonths (-7).Year).Sum (x => x.PercRentabilidade));
                    CDI.Mes6 = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", indicEquConteudo.Where (x => x.dtAnoMesRef.Month == _dataCompara.AddMonths (-6).Month && x.dtAnoMesRef.Year == _dataCompara.AddMonths (-6).Year).Sum (x => x.PercRentabilidade));
                    CDI.Mes7 = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", indicEquConteudo.Where (x => x.dtAnoMesRef.Month == _dataCompara.AddMonths (-5).Month && x.dtAnoMesRef.Year == _dataCompara.AddMonths (-5).Year).Sum (x => x.PercRentabilidade));
                    CDI.Mes8 = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", indicEquConteudo.Where (x => x.dtAnoMesRef.Month == _dataCompara.AddMonths (-4).Month && x.dtAnoMesRef.Year == _dataCompara.AddMonths (-4).Year).Sum (x => x.PercRentabilidade));
                    CDI.Mes9 = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", indicEquConteudo.Where (x => x.dtAnoMesRef.Month == _dataCompara.AddMonths (-3).Month && x.dtAnoMesRef.Year == _dataCompara.AddMonths (-3).Year).Sum (x => x.PercRentabilidade));
                    CDI.Mes10 = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", indicEquConteudo.Where (x => x.dtAnoMesRef.Month == _dataCompara.AddMonths (-2).Month && x.dtAnoMesRef.Year == _dataCompara.AddMonths (-2).Year).Sum (x => x.PercRentabilidade));
                    CDI.Mes11 = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", indicEquConteudo.Where (x => x.dtAnoMesRef.Month == _dataCompara.AddMonths (-1).Month && x.dtAnoMesRef.Year == _dataCompara.AddMonths (-1).Year).Sum (x => x.PercRentabilidade));
                    CDI.Mes12 = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", indicEquConteudo.Where (x => x.dtAnoMesRef.Month == _dataCompara.Month && x.dtAnoMesRef.Year == _dataCompara.Year).Sum (x => x.PercRentabilidade));
                }
            }

            var _indiceEquiv = "S";
            var _benchMarkFixo = await _privateService.ObterBenchmarkFixo (
                solicitacao.Sistema,
                solicitacao.Legado,
                solicitacao.Agencia.ToString (),
                solicitacao.Conta.ToString (),
                solicitacao.DataReferencia,
                _codIndice,
                _indiceEquiv,
                _segmento,
                _retocorr);

            if (_benchMarkFixo != null) {
                if (_benchMarkFixo.StatusProcessamento.Code != 200) {
                    throw (new Exception (string.Format ("Erro no Serviço: {0} - {1}", "BenchMarkFixo", _benchMarkFixo.StatusProcessamento.Message)));
                }

                if (_benchMarkFixo.Conteudo[0].QuantidadeOcorrencias != -1) {
                    _benchMarkFixo.Conteudo = _benchMarkFixo.Conteudo.Where (x => x.CodIndice == "2").ToList ();

                    if (_benchMarkFixo.Conteudo[0].dtAnoMesRef.Month == _dataCompara.AddMonths (0).Month && _benchMarkFixo.Conteudo[0].dtAnoMesRef.Year == _dataCompara.AddMonths (0).Year) {
                        CDI.AcumAno = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", _benchMarkFixo.Conteudo[0].PercAcumuladoAno);
                        CDI.Acum12Meses = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", _benchMarkFixo.Conteudo[0].PerAcumulado12M);
                        CDI.Acum24Meses = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", _benchMarkFixo.Conteudo[0].PercAcumulado24M);
                        CDI.Acum36Meses = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", _benchMarkFixo.Conteudo[0].PercAcumulado36M);
                    }

                }
                if (!string.IsNullOrEmpty (CDI.Resumo)) {
                    oRendCartList.Add (CDI);
                }

                oRendCart.RendimentoHistoricoCarteiraList = oRendCartList;
            }

            return oRendCart;
        }
    }
}