using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using DadosAPI.Models;
using DadosAPI.Models.GerenciamentoSolicitacao;

namespace DadosAPI.Services {
    public class PosicaoInvestimentosService {
        private readonly RelatorioService _service;
        private readonly PrivateService _privateService;

        public PosicaoInvestimentosService (
            RelatorioService service,
            PrivateService privateService
        ) {
            _service = service;
            _privateService = privateService;
        }
        public async Task<PosicaoInvestimentos> GetData (SolicitacaoRelatorio solicitacao) {

            PosicaoInvestimentos oposicaoinvestimentos = new PosicaoInvestimentos ();
            List<PosicaoInvestimentos> oPosicaoList = new List<PosicaoInvestimentos> ();

            var _resumo = await _privateService.ObterInformacaoResumoConta (
                solicitacao.Sistema,
                solicitacao.Legado,
                solicitacao.Agencia.ToString (),
                solicitacao.Conta.ToString (),
                solicitacao.DataReferencia,
                solicitacao.Segmento);

            if (_resumo != null) {
                if (_resumo.StatusProcessamento.Code != 200) {
                    throw (new Exception (string.Format ("Erro no Serviço: {0} - {1}", "ResumoConta", _resumo.StatusProcessamento.Message)));
                }

                if (_resumo.Conteudo[0].QuantidadeOcorrencias != -1) {
                    var TotalCarteira = _resumo.Conteudo.Where (x => x.CodGrupoProduto == 999)
                        .FirstOrDefault ().SaldoBrutoAtual;

                    //_resumo.Conteudo.Where(x => x.NomeGrupoProduto != "Carteira" && x.NomeRentabilidadePai != "Carteira" ).Select(x => x.NomeRentabilidadePai).Distinct()

                    var resConteudo = _resumo.Conteudo.Where (x => x.CodGrupoProduto != 999 && x.SaldoBrutoAtual > 0)
                        .OrderBy (x => x.IdentSeqFamilia)
                        .ThenByDescending (X => X.OrdemApresentacaoPai)
                        .ThenBy (x => x.NomeGrupoProduto)
                        .ThenByDescending (X => X.IdentSeqGrupoProduto)
                        .ThenByDescending (x => x.OrdemApresentacaoProduto)
                        .ToList ();

                    foreach (var itemRes in resConteudo) {
                        PosicaoInvestimentos oPosicaoInvestimento = new PosicaoInvestimentos ();
                        oPosicaoInvestimento.CodGrupoProduto = itemRes.CodGrupoProduto;
                        oPosicaoInvestimento.Resumo = itemRes.NomeGrupoProduto;
                        oPosicaoInvestimento.SaldoBrutoPatrimonio = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", itemRes.SaldoBrutoAtual);
                        oPosicaoInvestimento.ImpostoPatrimonio = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", itemRes.ImpostoPrevisto);
                        oPosicaoInvestimento.SaldoLiquidoPatrimonio = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", itemRes.SaldoLiquido);
                        oPosicaoInvestimento.IdentSeqFamilia = itemRes.IdentSeqFamilia;
                        oPosicaoInvestimento.IdentSeqGrupoProduto = itemRes.IdentSeqGrupoProduto;
                        oPosicaoInvestimento.IdentSeqProduto = itemRes.IdentSeqProduto;
                        oPosicaoInvestimento.IsBold = itemRes.CodRentabilidadePai == 999 ? "S" : "N";
                        oPosicaoInvestimento.PLPercentual = TotalCarteira == 0 ? 0 : decimal.Round (decimal.Round ((itemRes.SaldoBrutoAtual / TotalCarteira), 4) * 100, 2);
                        oPosicaoList.Add (oPosicaoInvestimento);
                    }
                }
            }

            var _retocorr = "S";
            var _codRent = "0000";

            var _rentabilidadeFixo = await _privateService.ObterRentabilidadeFixo (
                solicitacao.Sistema,
                solicitacao.Legado,
                solicitacao.Agencia.ToString (),
                solicitacao.Conta.ToString (),
                solicitacao.DataReferencia,
                _codRent,
                solicitacao.Segmento,
                _retocorr);

            if (_rentabilidadeFixo != null) {
                if (_rentabilidadeFixo.StatusProcessamento.Code != 200) {
                    throw (new Exception (string.Format ("Erro no Serviço: {0} - {1}", "RentabilidadeFixo", _rentabilidadeFixo.StatusProcessamento.Message)));
                }

                if (_rentabilidadeFixo.Conteudo[0].QuantidadeOcorrencias != -1) {
                    var rentFixoConteudo = _rentabilidadeFixo.Conteudo;

                    foreach (var itemRentFixo in rentFixoConteudo) {
                        foreach (var itemPos in oPosicaoList) {
                            if (itemRentFixo.IdentSeqFamilia == itemPos.IdentSeqFamilia && itemRentFixo.IdentSeqGrupoProduto == itemPos.IdentSeqGrupoProduto && itemRentFixo.IdentSeqProduto == itemPos.IdentSeqProduto) {
                                itemPos.RentMes = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", itemRentFixo.PercAcumuladoMes);
                                itemPos.RentAno = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", itemRentFixo.PercAcumuladoAno);
                                itemPos.Rent12Meses = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", itemRentFixo.PerAcumulado12M);
                                itemPos.Rent24Meses = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", itemRentFixo.PercAcumulado24M);
                                itemPos.Rent36Meses = string.Format (CultureInfo.GetCultureInfo ("pt-BR"), "{0:N}", itemRentFixo.PercAcumulado36M);
                            }
                        }
                    }
                }
            }

            oposicaoinvestimentos.PosicaoInvestimentosList = oPosicaoList;

            return oposicaoinvestimentos;
        }
    }
}