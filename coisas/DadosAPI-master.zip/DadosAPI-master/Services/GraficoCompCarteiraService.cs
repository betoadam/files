using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using DadosAPI.Models;
using DadosAPI.Models.GerenciamentoSolicitacao;

namespace DadosAPI.Services {
    public class GraficoCompCarteiraService {
        private readonly RelatorioService _service;
        private readonly PrivateService _privateService;

        public GraficoCompCarteiraService (
            RelatorioService service,
            PrivateService privateService
        ) {
            _service = service;
            _privateService = privateService;
        }
        public async Task<List<GraficoComposicaoCarteira>> GetData (SolicitacaoRelatorio solicitacao) {
            List<GraficoComposicaoCarteira> oListGraf = new List<GraficoComposicaoCarteira> ();

            var _resumo = await _privateService.ObterInformacaoResumoConta (
                solicitacao.Sistema,
                solicitacao.Legado,
                solicitacao.Agencia.ToString (),
                solicitacao.Conta.ToString (),
                solicitacao.DataReferencia,
                solicitacao.Segmento);

            if (_resumo != null) {
                if (_resumo.StatusProcessamento.Code != 200) {
                    throw new Exception (string.Format ("Erro no Serviço: {0} - {1}", "ResumoConta", _resumo.StatusProcessamento.Message));
                }

                if (_resumo.Conteudo[0].QuantidadeOcorrencias != -1) {
                    var SldCarteira = _resumo.Conteudo.Where (x => x.CodGrupoProduto == 999).FirstOrDefault ().SaldoBrutoAtual;

                    if (SldCarteira == 0) {
                        throw new Exception (string.Format ("Para este período não há Saldo Bruto para a Carteira"));
                    }

                    //_resumo.Conteudo = _resumo.Conteudo.Where(x => x.CodRentabilidadePai == 999).OrderBy(x => x.NomeGrupoProduto).ToList();
                    //Preenchimento do gráfico Rolha
                    _resumo.Conteudo = _resumo.Conteudo.Where (x => x.CodRentabilidadePai == 999)
                        .OrderBy (x => x.IdentSeqFamilia)
                        .ThenBy (X => X.OrdemApresentacaoPai.HasValue).ThenByDescending (x => x.OrdemApresentacaoPai)
                        .ThenByDescending (X => X.IdentSeqGrupoProduto.HasValue).ThenBy (x => x.IdentSeqGrupoProduto)
                        .ThenByDescending (X => X.OrdemApresentacaoProduto.HasValue).ThenBy (x => x.OrdemApresentacaoProduto)
                        .ToList ();

                    decimal Percentual = 0;
                    foreach (var item in _resumo.Conteudo) {
                        Percentual = SldCarteira == 0 ? 0 : decimal.Round (decimal.Round ((item.SaldoBrutoAtual / SldCarteira), 4) * 100, 2);
                        GraficoComposicaoCarteira oGraf = new GraficoComposicaoCarteira ();
                        oGraf.Familia = item.NomeGrupoProduto.ToUpper ();
                        oGraf.Amount = Math.Abs (item.SaldoBrutoAtual);
                        oGraf.Percentual = Math.Abs (Percentual);

                        switch (item.NomeGrupoProduto) {
                            case "Op. Estruturadas":
                                oGraf.CorFamilia = "#106060";
                                break;
                            case "Multimercado":
                                oGraf.CorFamilia = "#C04918";
                                break;
                            case "Renda Fixa":
                                oGraf.CorFamilia = "#002958";
                                break;
                            case "Renda Variável":
                                oGraf.CorFamilia = "#610000";
                                break;
                            case "Poupança":
                                oGraf.CorFamilia = "#0279AC";
                                break;
                            case "Corretora":
                                oGraf.CorFamilia = "#A0A0A0";
                                break;
                            case "Cambial":
                                oGraf.CorFamilia = "#B07011";
                                break;
                            case "FIP":
                                oGraf.CorFamilia = "#787821";
                                break;
                            case "Previdencia":
                                oGraf.CorFamilia = "#402068";
                                break;
                            case "Previdência":
                                oGraf.CorFamilia = "#402068";
                                break;
                            default:
                                oGraf.CorFamilia = "#000000";
                                break;
                        }
                        oListGraf.Add (oGraf);
                    }
                }
            }

            return oListGraf;
        }
    }
}