using System;
using System.Net.Http;
using System.Threading.Tasks;
using DadosAPI.Extensions;
using DadosAPI.Models;
using DadosAPI.Models.GerenciamentoSolicitacao;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;

namespace DadosAPI.Services {
    public class GraficoSuitabilityService {
        private readonly RelatorioService _service;
        private readonly PrivateService _privateService;

        public GraficoSuitabilityService (
            RelatorioService service,
            PrivateService privateService
        ) {
            _service = service;
            _privateService = privateService;
        }
        public async Task<Suitability> GetData (SolicitacaoRelatorio solicitacao) {
            try {
                string url = AppConfig.Configuration.GetValue<string> ("UrlSuitabilityService");

                var dataSolicitacao = $"{solicitacao.DataReferencia.Substring(6, 2)}.{solicitacao.DataReferencia.Substring(4, 2)}.{solicitacao.DataReferencia.Substring(0, 4)}";
                var dados = $"2048{solicitacao.CodigoCliente.PadLeft(9, '0')}{dataSolicitacao}{solicitacao.CodigoTipoPessoa.PadLeft(4, '0')}";

                var stringContent = new StringContent (new {
                    Header = new {
                            TransacaoRoteador = "PZWD",
                                GrupoServico = "GCA",
                                NomeServico = "PRIV64",
                                Agencia = 0,
                                ContaCorrente = 0,
                                Origem = "VCG",
                                QuantidadeOcorrencias = 2,
                                UserId = "",
                                Senha24 = "",
                                Sessao = "",
                                SenhaCliente = "",
                                Filler = "",
                                CEDF = ""
                        },
                        Dados = new string[] { dados }
                }.ToString ());

                using (HttpClient client = new HttpClient ())
                using (HttpResponseMessage res = await client.PostAsync (url, stringContent))
                using (HttpContent content = res.Content) {
                    string data = await content.ReadAsStringAsync ();
                    Suitability suitability = JsonConvert.DeserializeObject<Suitability> (data);
                    return suitability;

                }
            } catch (Exception ex) {
                throw new Exception (string.Format ("Desculpe: Não foi possível obter os dados cadastrais do Suitability: {0} ", ex.Message));
            }
        }
    }
}