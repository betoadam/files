using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using DadosAPI.Models;
using DadosAPI.Models.GerenciamentoSolicitacao;

namespace DadosAPI.Services {
    public class GraficoRendHistoricoService {
        private readonly RelatorioService _service;
        private readonly PrivateService _privateService;

        public GraficoRendHistoricoService (
            RelatorioService service,
            PrivateService privateService
        ) {
            _service = service;
            _privateService = privateService;
        }
        public async Task<List<GraficoHistoricoRendimentoCarteira>> GetData (SolicitacaoRelatorio solicitacao) {
            List<GraficoHistoricoRendimentoCarteira> oListGraf = new List<GraficoHistoricoRendimentoCarteira> ();

            DateTime _data = Convert.ToDateTime (string.Format ("{0}/{1}/01", solicitacao.DataReferencia.Substring (0, 4), solicitacao.DataReferencia.Substring (4, 2)));
            _data = _data.AddMonths (-11);

            var _retocorr = "S";
            var _codRent = "999";
            var _codIndice = "02";
            var _qtdmes = 12;
            var _indAcumulado = "S";
            var _segmento = solicitacao.Segmento;

            var _rentabilidadeFlex = await _privateService.ObterRentabilidadeFlexivel (
                solicitacao.Sistema,
                solicitacao.Legado,
                solicitacao.Agencia.ToString (),
                solicitacao.Conta.ToString (),
                solicitacao.DataReferencia,
                _codRent,
                _qtdmes,
                _indAcumulado,
                _segmento,
                _retocorr);

            if (_rentabilidadeFlex != null) {
                if (_rentabilidadeFlex.StatusProcessamento.Code != 200) {
                    throw new Exception(string.Format ("Erro no Serviço: {0} - {1}", "RentabilidadeFlexivel", _rentabilidadeFlex.StatusProcessamento.Message));
                }

                if (_rentabilidadeFlex.Conteudo[0].QuantidadeOcorrencias != -1) {
                    var rentFlexConteudo = _rentabilidadeFlex.Conteudo.Where (x => x.CodRentabilidade == 999).ToList ();

                    for (int i = 0; i < 12; i++) {
                        GraficoHistoricoRendimentoCarteira oGraf = new GraficoHistoricoRendimentoCarteira ();
                        oGraf.Periodo = _data.AddMonths (i).ToShortDateString ();
                        oGraf.dtMesAno = _data.AddMonths (i);
                        oGraf.ValorCarteira = Math.Abs (Math.Round (rentFlexConteudo.Where (x => x.dtAnoMesRef.Month == _data.AddMonths (i).Month && x.dtAnoMesRef.Year == _data.AddMonths (i).Year).Sum (x => x.PercRentabilidade), 2));
                        oListGraf.Add (oGraf);
                    }
                }
            }

            _indAcumulado = "E";
            _codIndice = "02";
            var _indiceAcumulado = await _privateService.ObterIndiceAcumulado(
                solicitacao.Sistema,
                solicitacao.Legado,
                solicitacao.Agencia.ToString (),
                solicitacao.Conta.ToString (),
                solicitacao.DataReferencia,
                _codIndice,
                _qtdmes,
                _indAcumulado,
                _segmento);

            if (_indiceAcumulado != null) {
                if (_indiceAcumulado.StatusProcessamento.Code != 200) {
                    throw new Exception( string.Format ("Erro no Serviço: {0} - {1}", "IndiceAcumulado", _indiceAcumulado.StatusProcessamento.Message) );
                }

                if (_indiceAcumulado.Conteudo[0].QuantidadeOcorrencias != -1) {
                    var indAcumConteudo = _indiceAcumulado.Conteudo.Where (x => x.CodIndice == "2").OrderBy (x => x.CodIndice).ToList ();

                    foreach (var indAcum in indAcumConteudo) {
                        foreach (var itemGraf in oListGraf) {
                            if (indAcum.dtAnoMesRef.Month == itemGraf.dtMesAno.Month && indAcum.dtAnoMesRef.Year == itemGraf.dtMesAno.Year) {
                                itemGraf.ValorCDI = Math.Abs (Math.Round (indAcum.PercIndice, 2));
                            }
                        }
                    }
                }
            }

            var _indProduto = "S";
            var _saldocarteirafechamento = await _privateService.ObterSaldoCarteiraFechamento(
                solicitacao.Sistema,
                solicitacao.Legado,
                solicitacao.Agencia.ToString (),
                solicitacao.Conta.ToString (),
                solicitacao.DataReferencia,
                _qtdmes,
                _indProduto,
                _segmento);

            if (_saldocarteirafechamento != null) {
                if (_saldocarteirafechamento.StatusProcessamento.Code != 200) {
                    throw new Exception(string.Format ("Erro no Serviço: {0} - {1}", "SaldoCarteiraFechamento", _saldocarteirafechamento.StatusProcessamento.Message));
                }

                if (_saldocarteirafechamento.Conteudo[0].QuantidadeOcorrencias != -1) {
                    var SaldoCarteira = _saldocarteirafechamento.Conteudo.ToList ();

                    foreach (var indSaldo in SaldoCarteira) {
                        foreach (var itemGraf in oListGraf) {
                            if (indSaldo.dtAnoMesRef.Month == itemGraf.dtMesAno.Month && indSaldo.dtAnoMesRef.Year == itemGraf.dtMesAno.Year) {
                                itemGraf.ValorSaldo = Math.Abs (Math.Round (indSaldo.ValorSaldoBruto, 2));
                            }
                        }
                    }
                }
            }

            return oListGraf;
        }
    }
}