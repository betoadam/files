using System.Collections.Generic;
using System.Linq;
using DadosAPI.Models.GerenciamentoSolicitacao;

namespace DadosAPI.Common {
    public static class GerenciamentoSolicitacao {
        private static List<SolicitacaoRelatorio> _solicitacoes;

        static GerenciamentoSolicitacao () {
            _solicitacoes = new List<SolicitacaoRelatorio> ();
        }

        public static void RegistrarSolicitacao (SolicitacaoRelatorio solicitacao) {
            _solicitacoes.Add (solicitacao);
        }

        public static SolicitacaoRelatorio ValidarSolicitacao (string token) {
            if (token == "dev") {
                var sm = new SolicitacaoRelatorio () {
                    Sistema = "EXT",
                    Legado = "EXT",
                    Agencia = 11500,
                    Conta = 51385,
                    CodigoCliente = "4135305",
                    CodigoTipoPessoa = "0007",
                    DataReferencia = "20191024",
                    Segmento = "22",
                    UsuarioSolicitante = "AUTOMAT",
                    Template = 1
                };


                return sm;
            }

            var solicitacao = _solicitacoes != null ? _solicitacoes.FirstOrDefault (x => x.Token == token) : null;

            if (solicitacao == null)
                return null;

            if (!solicitacao.Valida)
                return null;

            _solicitacoes.Remove (solicitacao);

            return solicitacao;
        }
    }
}