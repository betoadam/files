# Gerador de Relatório

Para iniciar o servidor, basta executar:

```
npm install
npm start
```

Ao executar uma requisição GET na porta 8080 do servidor ele deve retornar um pdf criado com base no json na pasta src/input/generic.json.

Também é possível executar uma requsição POST, que tenha no seu body um json no mesmo formato do template genérico para gerar um pdf.


