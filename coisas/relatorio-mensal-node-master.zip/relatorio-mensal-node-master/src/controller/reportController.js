var archiver = require('archiver')
const renderPdf = require('../services/renderPdf')
const generateHtml = require('../services/generateHtml')
const signPdf = require('../services/signPdf')
const passwordProtect = require('../services/passwordProtect')
const { saveToStorage } = require('../services/storageService')
const {
  getReportData,
  getCompCarteiraData,
  getRendHistoricoData,
  getSuitabilityData,
  getSolicitacao
} = require('../services/reportDataService')

exports.onDemand = async (req, res) => {
  try {
    let solicitacao = await getSolicitacao(req.query.token)

    const pdf = await processRequest(solicitacao)
    
    const protected = await passwordProtect(pdf)

    res.set('Content-Type', 'application/pdf')
    res.send(protected)
  } catch(e) {
    console.log(e.message);

    res.status(500)
    res.send({
      message: e.message
    })
  }
}

exports.getPdf = async (req, res) => {
  try {
    let solicitacao = req.body
    
    const pdf = await processRequest(solicitacao)

    // const signedPdf = await signPdf(pdf)
    
    const protected = await passwordProtect(pdf)

    const response = await saveToStorage(protected)

    // console.log("Storage ID", response.properties['r_object_id'])

    res.send({
      "message": "ok",
      "objectId": response.properties['r_object_id']
    })
  } catch (e) {
    console.log(e.message);

    res.status(500)
    res.send({
      message: e.message
    })
  }
}

const processRequest = async solicitacao => {
  const relatorio = await getReportData(solicitacao)
  const composicaoCarteira = await getCompCarteiraData(solicitacao)
  const rendHistorico = await getRendHistoricoData(solicitacao)
  const suitability = await getSuitabilityData(solicitacao)

  const html = generateHtml(
    relatorio,
    composicaoCarteira,
    rendHistorico,
    suitability,
    APP_ROOT)

  return await renderPdf.renderPdf(html)
}

exports.sampleReport = async (req, res) => {
  try {
    if (!Array.isArray(req.body)) {
      res.status(400)
      res.send({
        message: 'O body da requisição deve ser uma lista de solicitações.'
      })
      return
    }

    let solicitacoes = req.body

    // var output = fs.createWriteStream('./output/relatorios.zip');
    var archive = archiver('zip', {
      gzip: true,
      zlib: { level: 9 } // Sets the compression level.
    });

    archive.on('error', function (err) {
      throw err;
    });

    // de maneira paralela, executa todas as solicitações
    let pdfArray = await Promise.all(
      solicitacoes.map(solicitacao => processRequest(solicitacao))
    )

    pdfArray.forEach((pdf, i) => {
      archive.append(pdf, { name: `relatorio-${i}.pdf` })
    })

    archive.finalize()

    res.set("Content-Disposition", "attachment;filename=relatorios.zip")
    res.set('Content-Type', 'application/zip')

    archive.pipe(res)


    // for (let i = 0; i < solicitacoes.length; i++) {
    //   const pdf = await processRequest(solicitacoes[i])

    //   archive.append(pdf, {name: `relatorio-${i}.pdf`})
    //   // archive.file('/path/to/README.md', {name: 'foobar.md'});
    //   console.log(`relatorio ${i} pronto`)
    // }


  } catch (e) {
    console.log(e.message);

    res.status(500)
    res.send({
      message: e.message
    })
  }
}