const express = require('express')
const path = require('path')
const bodyParser = require('body-parser')
const cors = require('cors')
const dotenv = require('dotenv')

const dependencyChecker = require('./util/dependencyChecker')
const reportRoute = require('./routes/reportRoute')

dotenv.config()
dependencyChecker()

const PORT = process.env.PORT || 3001
const HOST = process.env.HOST || '0.0.0.0'

const app = express()
app.use(cors())

app.use(bodyParser.json({ limit: '50mb' }))
app.use(bodyParser.urlencoded({ limit: '50mb', extended: true }))

global.APP_ROOT = path.resolve(__dirname)

app.use('/report', reportRoute)

app.get('/test', (req, res) => res.send({
  message: 'ok 👍',
  root: APP_ROOT
}))


app.listen(PORT)

console.log(`Running on http://${HOST}:${PORT}`)
