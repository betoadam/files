module.exports = {
  produtos: {
    rendaFixa: {
      primary:   '#182C53',
      secondary: '#080F36'
    },
    rendaVariavel: {
      primary:   '#500612',
      secondary: '#D02F72'
    },
    multimercado: {
      primary:   '#AF5433',
      secondary: '#F0514F'
    },
    cambial: {
      primary:   '#9F6E35',
      secondary: '#F58350'
    },
    flip: {
      primary:   '#6F7436',
      secondary: '#43B979'
    },
    opEstruturada: {
      primary:   '#2B5E5C',
      secondary: '#83C77F'
    },
    poupanca: {
      primary:   '#204964',
      secondary: '#1891CB'
    },
    curtoPrazo: {
      primary:   '#284080',
      secondary: '#385FAC'
    },
    previdencia: {
      primary:   '#39296B',
      secondary: '#3CBEB0'
    },
    corretora: {
      primary:   '#949697',
      secondary: '#949697'
    },
  },
  indices: {
    cdi: {
      primary:   '#555F73',
      secondary: '#6A80B3'
    },
    bovespa: {
      primary:   '#CA3B7E',
      secondary: '#EF59A0'
    },
    ignp: {
      primary:   '#EBB650',
      secondary: '#FDBB4A'
    },
    dolar: {
      primary:   '#C2CD57',
      secondary: '#6DC17C'
    },
    ipca: {
      primary:   '#788897',
      secondary: '#A0D1F1'
    },
    carteira: {
      primary:   '#69BDC9',
      secondary: '#4CC7EB'
    },
  }
}