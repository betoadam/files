var qpdf = require('node-qpdf')
var fs = require('fs')

const cleanTemp = (file) => {
    fs.unlinkSync(`./temp/${file}.in`)
    fs.unlinkSync(`./temp/${file}.out`)
}

module.exports = async (buffer) => {
    let password = process.env.PDF_PASSWORD
    let randomString = Math.random().toString(36).substring(7);

    var options = {
        keyLength: 256,
        password: password,
        outputFile: `./temp/${randomString}.out`,
        restrictions: {
            modify: 'none',
            extract: 'n'
        }
    }

    fs.writeFileSync(`./temp/${randomString}.in`, buffer)
    
    await qpdf.encrypt(`./temp/${randomString}.in`, options)

    const doc = fs.readFileSync(options.outputFile)

    cleanTemp(randomString)

    return doc
}