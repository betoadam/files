const puppeteer = require("puppeteer");
const fs = require('fs');


async function timeout(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

exports.renderPdf = async html => {
  try {
    let browser

    if (fs.existsSync('/etc/alpine-release')) {
      browser = await puppeteer.launch({
        executablePath: '/usr/bin/chromium-browser',
        args: ['--no-sandbox', '--headless', '--disable-gpu']
      })
    } else {
      browser = await puppeteer.launch({
        args: ['--no-sandbox', '--headless', '--disable-gpu']
      })
    }

    const page = await browser.newPage();

    await page.setViewport({
      width: parseInt(842 * 1.35),
      height: parseInt(595 * 1.35),
      isLandscape: true,
      deviceScaleFactor: 6
    });

    if (process.env.DEBUG === "true") {
      await page.setRequestInterception(true);

      page.on("console", msg => console.log("PAGE LOG:", msg.text()));

      page.on("request", request => {
        console.log(`Intercepted request with URL: ${request.url()}`);
        request.continue();
      });
    }

    await page.goto(`file://${APP_ROOT}/page.html`);

    await page.setContent(html, { waitUntil: "networkidle0" });

    await page.evaluate(() => window.scrollBy(0, window.scrollHeight))
    await page.evaluateHandle('document.fonts.ready'); // dá problemas no windows
    await timeout(100)


    let pdfBuffer = await page.pdf({
      // path: `./output/relatorio-${currentDate}.pdf`,
      format: "A4",
      margin: "0mm",
      landscape: true
    })

    // encerrar o browser após ele ser utilizado
    browser.close()

    // const signedPdf = signPdf.sign(pdfBuffer)

    // fs.writeFileSync('./output/pagesigned.pdf', signedPdf)

    return pdfBuffer;
  } catch (e) {
    console.log(e.message)

    res.status(500)
    res.send({
      message: e.message
    })
  }
};
