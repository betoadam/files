const fs = require('fs')
const path = require('path')

module.exports = () => {    
    if (!process.env.CERT_DIR)
        throw `Variável de ambiente da pasta do certificado (CERT_DIR) não configurada.`
    
    if (!fs.existsSync(process.env.CERT_DIR))
        throw `O diretório definido na variável CERT_DIR (${process.env.CERT_DIR}) não existe.`

    const entries = fs.readdirSync(process.env.CERT_DIR)
    const certificates = entries.filter(p => p.includes('.pdx') || p.includes('.p12'))

    if (certificates.length < 1)
        throw `Nenhum certificado pfx/p12 foi encontrado na pasta ${process.env.CERT_DIR}.`

    if (certificates.length > 1)
        throw `Mais de um certificado pfx/p12 foi encontrado na pasta ${process.env.CERT_DIR}: ${certificates.join(', ')}.`

    return path.join(process.env.CERT_DIR, certificates[0])
}