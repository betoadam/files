const axios = require('axios').default

exports.getReportData = async header => {
  try {
    const model = await axios.post(
      `${process.env.DATA_API}/api/report`, 
      header
    )

    return model.data
  } catch (e) {
    throw(new Error('Não foi possível se comunicar com a API do busca de dados: ' + e.message))
  }
};

exports.getCompCarteiraData = async header => {
  try {
    const model = await axios.post(
      `${process.env.DATA_API}/api/report/graficoCompCarteira`, 
      header
    )

    return model.data
  } catch (e) {
    throw(new Error('Não foi possível se comunicar com a API do busca de dados: ' + e.message))
  }
};

exports.getRendHistoricoData = async header => {
  try {
    const model = await axios.post(
      `${process.env.DATA_API}/api/report/graficoRendHistorico`, 
      header
    )

    return model.data
  } catch (e) {
    throw(new Error('Não foi possível se comunicar com a API do busca de dados: ' + e.message))
  }
};

exports.getSuitabilityData = async header => {
  try {
    const model = await axios.post(
      `${process.env.DATA_API}/api/report/graficoSuitability`, 
      header
    )

    return model.data
  } catch (e) {
    throw(new Error('Não foi possível se comunicar com a API do busca de dados: ' + e.message))
  }
};

exports.getSolicitacao = async token => {
  try {
    const solicitacao = await axios.get(
      `${process.env.DATA_API}/api/report`,
      {
        params: {
          token: token
        }
      }
    )

    return solicitacao.data
  } catch (e) {
    throw(new Error('Não foi possível se comunicar com a API do busca de dados: ' + e.message))
  }
}