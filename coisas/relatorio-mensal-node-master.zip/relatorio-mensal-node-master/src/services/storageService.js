const axios = require('axios').default
const FormData = require('form-data')

exports.saveToStorage = async pdf => {
  try {
    const currentDate = new Date().toISOString()

    let formData = new FormData()
    formData.append("type", "pdf")
    formData.append("binary", pdf, {
      filename: `relatorio-${currentDate}.pdf`,
      contentType: 'application/pdf'
    })

    const properties = {
      "properties": {
        "r_object_type": "safra_doc_ppl",
        "object_name": "teste",
        "chave_negocio": "PPL_teste",
        "tipo": "A025",
        "cpf_cnpj": "33376666806",
        "agencia": "0097",
        "conta": "1234567",
        "cod_cliente": "123456789",
        "dt_retencao": "2025-02-21T10:11:48.000-03:00",
        "dt_movimentacao": "2018-02-21T10:11:48.000-03:00"
      }
    }

    formData.append("object", JSON.stringify(properties))

    const retornoStorage = await axios.post(`${process.env.STORAGE_API}/img/criar_arquivo`,
      formData,
      {
        headers: {
          'Authorization': 'Basic dXNyX2ltZ193c19wcGxfZGVzOlIlVTAmVkBUdiQ1VG4zIw==',
          'amc-aplicacao': 'EFG',
          'amc-message-id': 'teste-local-EFG-log',
          'amc-session-id': new Date().getTime(),
          'amc-work-id': new Date().getTime(),
          'Accept-language': 'pt-BR',
          ...formData.getHeaders()
        }
      }
    )

    return retornoStorage.data
  } catch (e) {
    console.log(e.message)
    throw (new Error("Falha ao enviar arquivo ao storage: " + e.message))
  }
}