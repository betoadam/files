const fs = require('fs')
const signer = require('node-signpdf').default
const { plainAddPlaceholder } = require('node-signpdf/dist/helpers')
const getCertificate = require('./getCertificate')

const sign = pdfBuffer => {
  let file = plainAddPlaceholder({
    pdfBuffer,
    reason: 'Arquivo criado pelo sistema.',
    signatureLength: 1612,
  })

  const certlocation = getCertificate()

  const signedPdf = signer.sign(
    file,
    fs.readFileSync(certlocation),
    { passphrase: process.env.CERT_PASSPHRASE }
  )

  return signedPdf
}

module.exports = sign