const fs = require('fs')
// const pdf = require('html-pdf')
const Handlebars = require('handlebars')
const colors = require('../config/colors')

const moment = require('moment')

const util = require('../util')
// import 'moment/locale/pt-br'

moment.locale('pt-br')

var html = fs.readFileSync('./src/template/index.html', 'utf8')

const paginas = [
  'Paginas/Capa',
  'Paginas/ContraCapa',
  'Paginas/ComposicaoCarteira',
  'Paginas/RendHistoricoCarteira',
  'Paginas/RendHistoricoProduto',
  'Paginas/PosicaoInvestimento',
  'Paginas/DetalhamentoFundos',
  'Paginas/DetalhamentoRendaFixa',
  'Paginas/DetalhamentoAcoes',
  'Paginas/DetalhamentoProdutosEstruturados',
  'Paginas/DetalhamentoDerivativos',
  'Paginas/DetalhamentoPoupanca',
  'Paginas/Notas',
  'Paginas/NotaFinal',
  'Modelos/SecaoFooter',
  'Modelos/SecaoHeader',
  'Modelos/TableHistorico',
  'Secoes/ComposicaoCarteira/SecGrafCompCarteira',
  'Secoes/ComposicaoCarteira/SecNotaCompCarteira',
  'Secoes/ComposicaoCarteira/SecResumoCarteira',
  'Secoes/DetalhamentoAcoes/SecDetalhamentoAcoes',
  'Secoes/DetalhamentoDerivativo/SecDetalhamentoDerivativo',
  'Secoes/DetalhamentoFundos/SecDetalhamentoFundos',
  'Secoes/DetalhamentoPoupanca/SecDetalhamentoPoupanca',
  'Secoes/DetalhamentoProdEstruturados/SecDetalhamentoProdEstruturados',
  'Secoes/DetalhamentoRendaFixa/SecDetalhamentoRendaFixa',
  'Secoes/NotaFinal/SecNotaFinal',
  'Secoes/Notas/SecNotas',
  'Secoes/PosicaoInvestimento/SecPosicaoInvestimento',
  'Secoes/RendHistoricoCarteira/SecGrafRendHistCarteira',
  'Secoes/RendHistoricoCarteira/SecRendHistCarteira',
  'Secoes/RendHistoricoProduto/SecNotaRendHistProduto',
  'Secoes/RendHistoricoProduto/SecRendHistoricoProduto',
  'Graficos/Rentabilidade',
  'Graficos/PerfilInvestidor',
  'Graficos/ComposicaoCarteira',
]

const template = Handlebars.compile(html)

const getComposicaoCarteiraDataset = compCarteira => {
  // console.log(compCarteira)
  const dataset = {
    labels: compCarteira.map(x => util.capitalizeFirst(x.familia)),
    datasets: [
      {
        fill: true,
        backgroundColor: compCarteira.map(x => x.corFamilia),
        data: compCarteira.map(x => x.percentual),
        borderWidth: 2,
      },
    ],
  }

  return JSON.stringify(dataset)
}

const getRentabilidadeDataset = rendHistorico => {
  // console.log(rendHistorico)
  const dataset = {
    datasets: [
      {
        label: 'label to remove',
        data: rendHistorico.map(x => x.valorSaldo),
        //        backgroundColor: '#EFEFEE',
        //        order: 3,
        //        yAxisID: "id1" // typo in property name.
        borderWidth: 0,
      },
      {
        label: 'Carteira',
        data: rendHistorico.map(x => x.valorCarteira),
        backgroundColor: '#2FB0E5',
        borderColor: '#2FB0E5',
        // Changes this dataset to become a line
        type: 'line',
        fill: false,
        order: 1,
        lineTension: 0,
        pointRadius: 0,
        yAxisID: 'id2', // typo in property name.
        borderWidth: 2,
        pointStyle: 'rectRounded',
      },
      {
        label: 'CDI Equivalente',
        data: rendHistorico.map(x => x.valorCDI),
        backgroundColor: '#99154E',
        borderColor: '#99154E',
        // Changes this dataset to become a line
        type: 'line',
        fill: false,
        order: 2,
        lineTension: 0,
        pointRadius: 0,
        yAxisID: 'id2',
        borderWidth: 2, // typo in property name.
        pointStyle: 'rectRounded',
        elements: {
          point: {
            borderWidth: 20,
          },
        },
      },
    ],
    labels: rendHistorico.map(x => moment(x.dtMesAno).format('MMM / YY')),
  }

  return JSON.stringify(dataset)
}

const getSuitability = suitability => {
  const dataVencimentoCadastro = moment(
    suitability.dataVencimentoCadastro
  ).format('DD/MM/YYYY');

  return {
    ...suitability,
    dataVencimentoCadastro
  }
}

const getMonthNames = model => {
  let monthNames = []
  let dataPosicao = moment(model.dataPosicao, "DD/MM/YYYY").subtract(1, 'year')

  for (let i = 0; i < 12; i++)
    monthNames.push(dataPosicao.add(1, 'month').format('MMM/YY'))

  return monthNames
}

module.exports = (model, composicaoCarteira, rendHistorico, suitability) => {

  let page = 0;

  Handlebars.registerHelper({
    eq: (v1, v2) => v1 === v2,
    mod: (ind, maxPage, limit) => {
      return ((ind + 1) % maxPage === 0) && (ind < limit - 1)
    },
    ne: (v1, v2) => v1 !== v2,
    lt: (v1, v2) => v1 < v2,
    gt: (v1, v2) => v1 > v2,
    lte: (v1, v2) => v1 <= v2,
    gte: (v1, v2) => v1 >= v2,
    and: () => Array.prototype.slice.call(arguments).every(Boolean),
    or: () => Array.prototype.slice.call(arguments, 0, -1).some(Boolean),
    iterator: n => Array.from(Array(n).keys()),
    times: (n, block) => {
      var accum = ''
      for (var i = 0; i < n; ++i) accum += block.fn(i)
      return accum
    },
    for: (from, to, incr, block) => {
      var accum = ''
      for (var i = from; i < to; i += incr) accum += block.fn(i)
      return accum
    },
    hypn: v1 => {
      if (!v1)
        return "-"
        
      let valor = String(v1).split(",")

      if (valor.reduce((a, b) => a + b, 0) == 0)
        return '-'
      
      valor[valor.length - 1] = valor[valor.length - 1].substring(0, 2)

      return valor.join(",")
    },
    listItems: ()=> {
      page++;
      return page;
    },
  })
  

  paginas.forEach(pagina => {
    var arquivo = fs.readFileSync(`./src/template/${pagina}.html`, 'utf8')
    Handlebars.registerPartial(pagina, arquivo)
  })

  model.dataApresentacaoLong = moment(new Date()).format('DD/MM/YYYY hh:mm')
  model.dataApresentacaoShort = moment(new Date()).format('DD/MM/YY')

  const result = template({
    model: model,
    dataRef: '',
    secNotas: model.notaSessao
      ? model.notaSessao.conteudo.filter(x => x.secao === '13')
      : null,
    secNotaCompCarteira: model.notaSessao
      ? model.notaSessao.conteudo.find(x => x.secao == "11")
      : null,
    secNotaFinal: model.notaSessao
      ? model.notaSessao.conteudo.find(x => x.secao == "14")
      : null,
    secNotaRendHistProduto: model.notaSessao
      ? model.notaSessao.conteudo.find(x => x.secao == "12")
      : null,
    graficoRentabilidadeDataset: getRentabilidadeDataset(rendHistorico),
    graficoComposicaoCarteiraDataset: getComposicaoCarteiraDataset(
      composicaoCarteira
    ),
    suitability: getSuitability(suitability),
    monthNames: getMonthNames(model),
  })

  fs.writeFileSync('./src/page.html', result)

  return result
}

// const signedPdf = signer.sign(
//   fs.readFileSync('./page.pdf'),
//   fs.readFileSync('./Certificates.p12')
// );

// fs.writeFile('./pagesigned.pdf', signedPdf)
