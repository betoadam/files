const router = require('express').Router()
const reportController = require('../controller/reportController')

/* GET users listing. */
router.get('/', reportController.onDemand)
router.post('/', reportController.getPdf)
router.post('/sample', reportController.sampleReport)

module.exports = router
