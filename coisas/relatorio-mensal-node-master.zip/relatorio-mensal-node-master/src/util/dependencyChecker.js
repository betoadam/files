const fs = require('fs')
const { execSync } = require('child_process')

module.exports = () => {
    if (fs.existsSync('/etc/alpine-release')) {
        if (!fs.existsSync('/usr/bin/qpdf')) {
            execSync('apk add qpdf', (err, stdout, stderr) => {
                if (err) {
                    console.error(err)
                } else {
                    console.log(`stdout: ${stdout}`)
                    console.log(`stderr: ${stderr}`)
                }
            });
        }
    }
}