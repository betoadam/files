exports.capitalizeFirst = text => String(text).charAt(0).toUpperCase() + String(text).substring(1).toLowerCase()
