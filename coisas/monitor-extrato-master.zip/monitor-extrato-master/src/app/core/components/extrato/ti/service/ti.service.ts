import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { environment } from "src/environments/environment";
import { ToastService } from 'src/app/core/services/toast/toast.service';

@Injectable({
  providedIn: "root"
})
export class TiService {
  constructor(
    private http: HttpClient,
    private toast: ToastService
  ) {}

  getTi(date, tipo, role) {
    return new Promise((resolve, reject) => {
      return this.http.get(`${environment.urlApiTwo}/${environment.ti}?data=${date}&tipo=${tipo}&role=${role}`).subscribe(
        res => {
          resolve(res);
        },
        err => {
          this.toast.show(err.error.Message, {
            delay: 10000,
            autohide: true,
            classname: 'bg-danger text-light'
          });
        },
      );
    });
  }
}
