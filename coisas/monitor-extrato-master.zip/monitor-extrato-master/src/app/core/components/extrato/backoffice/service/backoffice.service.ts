import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../../../../environments/environment';
import { ToastService } from 'src/app/core/services/toast/toast.service';

@Injectable({
  providedIn: 'root'
})
export class BackOfficeService {
  constructor(private http: HttpClient, private toast: ToastService) {}

  getBackOffice(date, tipo) {
    return new Promise((resolve, reject) => {
      return this.http
        .get(
          `${environment.urlApiTwo}/${environment.backOffice}?data=${date}&tipo=${tipo}`
        )
        .subscribe(
          res => {
            resolve(res);
          },
          err => {
            console.log(err);
            reject(err);
          }
        );
    });
  }

  approve(date, tipo, operacao, role, body) {
    return new Promise((resolve, reject) => {
      return this.http
        .put(
          `${environment.urlApiTwo}/${environment.backOffice}/aprovar?data=${date}&tipo=${tipo}&operacao=${operacao}&role=${role}`,
          body
        )
        .subscribe(
          res => {
            this.toast.show('Aprovado com sucesso', {
              delay: 10000,
              autohide: true,
              classname: 'bg-success text-light'
            });
            resolve(res);
          },
          err => {
            if (err.error.Message) {
              this.toast.show(err.error.Message, {
                delay: 5000,
                autohide: true,
                classname: 'bg-danger text-light'
              });
              console.log(err);
              } else {
                this.toast.show
              ('Aprovação da operação desejada sem sucesso.',
              {
                delay: 5000,
                autohide: true,
                classname: 'bg-danger text-light'
              });
              console.log(err); }
              reject(err);
          }
        );
    });
  }

  reprove(date, tipo, operacao, role, body) {
    return new Promise((resolve, reject) => {
      return this.http
        .put(
          `${environment.urlApiTwo}/${environment.backOffice}/reprovar?data=${date}&tipo=${tipo}&operacao=${operacao}&role=${role}`,
          body
        )
        .subscribe(
          res => {
            console.log('res');
            this.toast.show('Reprovado com sucesso', {
              delay: 10000,
              autohide: true,
              classname: 'bg-success text-light'
            });
            resolve(res);
          },
          errs => {
            this.toast.show('Erro ao reprovar a operação desejada.', {
              delay: 10000,
              autohide: true,
              classname: 'bg-danger text-light'
            });
            resolve(errs);
          }
        );
    });
  }

}
