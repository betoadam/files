import { Component, OnInit, Input } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { ConfirmationComponent} from 'src/app/core/components/extrato/confirmation/confirmation.component';

import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { BackOfficeService } from './service/backoffice.service';
import { ObservationComponent } from '../observation/observation.component';

@Component({
  selector: 'app-backoffice',
  templateUrl: './backoffice.component.html',
  styleUrls: ['./backoffice.component.scss']
})
export class BackofficeComponent implements OnInit {


  @Input() date;
  @Input() title;

  tipo: any;
  status: any;
  Observation: typeof ObservationComponent;
  Confirmation: typeof ConfirmationComponent;

  constructor(
    public activeModal: NgbActiveModal,
    private modalService: NgbModal,
    private backOffService: BackOfficeService
  ) {
    this.Observation = ObservationComponent;
    this.Confirmation = ConfirmationComponent;
  }

  async ngOnInit() {
    this.tipo = await this.title.toLocaleLowerCase();
    this.status = await this.backOffService.getBackOffice(this.date, this.tipo);
    console.log(this.status);

  }

  async open(content, approved, operacao, role) {

    const modalRef = await this.modalService.open(content, {
      centered: true,
      size: 'lg',
      keyboard: false
    });
    modalRef.componentInstance.content = 'R';
    modalRef.componentInstance.date = this.date;
    modalRef.componentInstance.tipo = this.tipo;
    modalRef.componentInstance.operacao = operacao;
    modalRef.componentInstance.role = role;
    modalRef.result.then(async res => {
      if (approved) {
        this.status = await this.backOffService.approve(this.date, this.tipo, operacao, role, res)
        .then(res => {
          this.activeModal.close();
        }).catch(err => {
          this.activeModal.close();
          // toast msg de erro
        });
      } else {
        // this.status = await this.backOffService.reprove(this.date, this.tipo, operacao, res)
        // .then(res => {
          this.activeModal.close();
        // }).catch(err => {
        //   // toast msg de erro
        //   this.activeModal.close();
        // });
      }
    });
  }

  async cancel() {
    await this.activeModal.close();
  }
}
