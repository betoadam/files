import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reprovation',
  templateUrl: './reprovation.component.html',
  styleUrls: ['./reprovation.component.scss']
})
export class ReprovationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
