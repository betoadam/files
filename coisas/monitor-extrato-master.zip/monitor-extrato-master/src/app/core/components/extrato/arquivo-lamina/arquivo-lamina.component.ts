import { ToastService } from './../../../services/toast/toast.service';
import { Component, OnInit, Input } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { Title } from '@angular/platform-browser';
import { LaminaService } from './service/lamina.service';
@Component({
  selector: 'app-arquivo-lamina',
  templateUrl: './arquivo-lamina.component.html',
  styleUrls: ['./arquivo-lamina.component.scss']
})
export class ArquivoLaminaComponent implements OnInit {

  @Input() title;
  @Input() date;

  public imagePath;
  imgURL: any;
  public message: string;

  constructor(
    public activeModal: NgbActiveModal,
    private lamService: LaminaService,
    private toast: ToastService
    ) { }

  ngOnInit() {

  }


 reintregar() {
    const tipo = this.title.toLocaleLowerCase();
    const role = 'ti';
    this.lamService.reintegrar(this.date, tipo, role)
    .then(data => {
      this.activeModal.close();
    }).catch(async err => {
      await this.activeModal.close();
      this.toast.show(err.error.Message);
      // this.activeModal.close();
    });
  }

  async cancel() {
    await this.activeModal.close();
  }
}
