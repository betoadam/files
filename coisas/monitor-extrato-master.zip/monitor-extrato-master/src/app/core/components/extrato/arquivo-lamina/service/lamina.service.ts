import { ToastService } from './../../../../services/toast/toast.service';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class LaminaService {

  constructor(
    private http: HttpClient, private toast: ToastService
  ) { }

  reintegrar(date, tipo, role) {
    return new Promise((resolve, reject) => {
      return this.http.put(`${environment.urlApiTwo}/${environment.lamina}?data=${date}&tipo=${tipo}&role=${role}`, '')
      .subscribe(res => {
        this.toast.show('Reintegrado com sucesso', {
          delay: 10000,
          autohide: true,
          classname: 'bg-success text-light'
        });
        resolve(res);
      }, err => {
        if (err.error.Message) {
          this.toast.show(err.error.Message, {
            delay: 5000,
            autohide: true,
            classname: 'bg-danger text-light'
          });
          console.log(err);
          } else {
            this.toast.show
          ('Erro ao processar a reintegração.',
          {
            delay: 5000,
            autohide: true,
            classname: 'bg-danger text-light'
          });
          console.log(err); }
          reject(err);
      });
    });
  }
}
