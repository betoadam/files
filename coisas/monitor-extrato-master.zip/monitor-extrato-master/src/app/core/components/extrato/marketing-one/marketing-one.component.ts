import { MarketingOneService } from './service/marketing-one.service';
import { Component, OnInit, Input } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';



@Component({
  selector: 'app-marketing-one',
  templateUrl: './marketing-one.component.html',
  styleUrls: ['./marketing-one.component.scss']
})
export class MarketingOneComponent implements OnInit {

  nameFile = null;
  listimage = [null, null, null];
  listFiles = [null, null, null];
  listaNome = ["CENARIO_ECONOMICO", "INFORME_SAFRA","RENTABILIDADE_FUNDOS"];
  nomelista = [{},{},{}];
  imagen = null;
  error = "";
  file = "";

  @Input() title;
           date; 

  MarketingOneService: any;
  status: any;


  constructor(
    public activeModal: NgbActiveModal,
    private service: MarketingOneService,
  ) { }
  async ngOnInit() {
    const role = 'TI';
    this.imagen = await this.service.getMarketing(this.date, this.title,role);
    this.lendoImagem(this.imagen);
  }

  async cancel() {
    await this.activeModal.close();
  }
  onFileSelected(event, posicao){
    this.imagen[posicao] = event.target.files[0];
    this.listFiles[posicao] = event.target.files[0];
    this.nameFile = event.target.files[0].name;
    this.nomelista[posicao] = this.listaNome[posicao]
    this.file = this.nameFile.split(".");
    var nameFile =  this.validacaoImg(posicao,this.nomelista);
    document.getElementById("image"+posicao).innerHTML = nameFile;;
      if(nameFile!= null){
        this.error = '';
        document.getElementById('errorFormato').innerHTML = this.error;  
      }  

    }

  x(posicao){
    this.listimage[posicao] = null;
    document.getElementById('image'+posicao).innerHTML = '';
    this.error = '';
  }

  async confirmar()
  {
    var validacao = false;
    for(var i=0; i < this.listimage.length; i++)
    {
      if(this.listimage[i] != null)
      {
        validacao = true; 
      }      
    }
    if(validacao == true)
    {

      const role = 'ti';
      let imagem = this.listFiles[0]
      if( (imagem!==null) )
        await this.service.onUpload(this.listFiles[0], this.title, this.date, this.nomelista, role, 'CENARIO_ECONOMICO');
      imagem = this.listFiles[1]
      if( imagem!==null)
        await this.service.onUpload(this.listFiles[1], this.title, this.date, this.nomelista, role, 'INFORME_SAFRA');
      imagem = this.listFiles[2]
      if( imagem!==null )
         this.service.onUpload(this.listFiles[2], this.title, this.date, this.nomelista, role, 'RENTABILIDADE_FUNDOS');
      
      this.error = ''
      var carregando = "CARREGANDO IMAGEM..."
      document.getElementById('carregando').innerHTML = carregando;
      setTimeout(() => {
        this.activeModal.close()
      }, 4000);
      carregando = ''

    }else{
      this.error = "Selecione no mínimo uma Imagem"
        document.getElementById('errorFormato').innerHTML = this.error;
    }
    
    
  }
  private validacaoImg(selector, nome)
  {
      if (this.file[1] == "pdf" || this.file[1] == "png" ||
      this.file[1] == "jpeg" || this.file[1] == "jpg")
      {
        
          this.listimage[selector] == null;
            this.listimage[selector] = this.imagen[selector];
            this.date = this.date.replace('/','-');
            var nameFile = this.title+'_'+nome[selector]+'_'+this.date+'.'+this.file[1];
            this.error=" ";
            return nameFile;
          
        
      }else
      {
        this.error = "Imagem tem que estar nos formatos PDF, PNG, JPEG ou JPG";
        document.getElementById('errorFormato').innerHTML = this.error;
        this.imagen[selector] = null;
        return null;
      }
    
  } 
  private lendoImagem(imagem){
      if(imagem[0]!= null){
        this.listimage[0] = imagem[0];
        document.getElementById("image0").innerHTML = imagem[0];

      }
      if(imagem[1]!= null){
        this.listimage[1] = imagem[1];
        document.getElementById("image1").innerHTML = imagem[1];

      }
      if(imagem[2]!= null){
        this.listimage[2] = imagem[2];
        document.getElementById("image2").innerHTML = imagem[2];

      }
    
  }
}