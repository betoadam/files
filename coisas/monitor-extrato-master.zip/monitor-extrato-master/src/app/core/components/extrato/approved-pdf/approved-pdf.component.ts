import { Component, OnInit, Input } from '@angular/core';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-approved-pdf',
  templateUrl: './approved-pdf.component.html',
  styleUrls: ['./approved-pdf.component.scss']
})
export class ApprovedPdfComponent implements OnInit {
  @Input() close;

  constructor(
    private modalService: NgbModal,
    public activeModal: NgbActiveModal
   ) { }

  ngOnInit() {
  }

// async cancel() {
//     await this.activeModal.close();
//   }
async cancel() {
  await this.modalService.dismissAll('Fechando modais');
  // await this.activeModal.close();
}
}
