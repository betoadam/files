import { TestBed } from '@angular/core/testing';

import { MarketingOneService } from './marketing-one.service';

describe('MarketingOneService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: MarketingOneService = TestBed.get(MarketingOneService);
    expect(service).toBeTruthy();
  });
});
