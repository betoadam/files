import { TestBed } from '@angular/core/testing';

import { ReportsProdService } from './reports-prod.service';

describe('ReportsProdService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ReportsProdService = TestBed.get(ReportsProdService);
    expect(service).toBeTruthy();
  });
});
