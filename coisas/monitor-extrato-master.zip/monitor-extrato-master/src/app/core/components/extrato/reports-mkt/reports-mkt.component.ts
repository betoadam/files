
import { Component, OnInit, Input } from '@angular/core';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ApprovedPdfComponent } from 'src/app/core/components/extrato/approved-pdf/approved-pdf.component';
import { RollbackComponent } from '../rollback/rollback.component';
import { ObservationComponent } from '../observation/observation.component';
import { HomeService } from 'src/app/pages/home/service/home.service';
import { saveAs } from "file-saver";
import { ReportsMktService } from './service/reports-mkt.service';
@Component({
  selector: 'app-reports-mkt',
  templateUrl: './reports-mkt.component.html',
  styleUrls: ['./reports-mkt.component.scss']
})
export class ReportsMktComponent implements OnInit {
  ApprovedPDF: typeof ApprovedPdfComponent;
  RollBack: typeof RollbackComponent;
  amostras: any;
  loading = false;
  data: any;
  Observation: typeof ObservationComponent;
  tipo: any;

  @Input() title;
  @Input() date;


  constructor(
    public activeModal: NgbActiveModal,
    private modalService: NgbModal,
    private homeService: HomeService,
    private reportsMktService: ReportsMktService
  ) {
    this.RollBack    = RollbackComponent;
    this.Observation = ObservationComponent;
  }

  async ngOnInit() {
    this.tipo = await this.title.toLocaleLowerCase();
    await this.getAmostras();
  }
  
  isOdd(data) {
    if (data % 2 === 1) {
      return true;
    }
    return false;
  }

  async getAmostras() {
    this.amostras = await this.homeService.getAmostra(this.date);
    console.log('amostras --->', this.amostras);
    // this.amostras = await mock;
  }

  async getDownload() {
  this.loading = true;
  let filename = "report.zip";
  await this.homeService.downloadReport(this.amostras)
  .subscribe(
    data => {
      this.loading = false;
      saveAs(data, filename);
    },
    err => {
      this.loading = false;
      alert("Não foi possível realizar o download.");
      console.error(err);
    }
  );
  }
  async openModal(content, approved, role) {
    const modalRef = await this.modalService.open(content, {
      centered: true,
      size: 'lg',
      keyboard: false
    });
    modalRef.componentInstance.date = this.date;
    modalRef.componentInstance.tipo = this.tipo;
    modalRef.componentInstance.modal = 'mkt';
    modalRef.result.then(async res => {
      if (approved) {
        this.reportsMktService.approve(this.date, this.tipo, role, res)
        .then(res => {
          this.activeModal.close();
        }).catch(err => {
          // toast msg erro
          this.activeModal.close();
        });
      } else {
        this.activeModal.close();
      }
    });
  }

  async cancel() {
    await this.activeModal.close();
  }
}
