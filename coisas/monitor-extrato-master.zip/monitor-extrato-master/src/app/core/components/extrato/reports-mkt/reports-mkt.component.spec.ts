import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportsMktComponent } from './reports-mkt.component';

describe('ReportsMktComponent', () => {
  let component: ReportsMktComponent;
  let fixture: ComponentFixture<ReportsMktComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReportsMktComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReportsMktComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
