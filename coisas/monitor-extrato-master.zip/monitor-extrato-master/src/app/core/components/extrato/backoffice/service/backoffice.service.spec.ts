import { TestBed } from '@angular/core/testing';

import { BackOfficeService } from './backoffice.service';

describe('LaminaService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: BackOfficeService = TestBed.get(BackOfficeService);
    expect(service).toBeTruthy();
  });
});
