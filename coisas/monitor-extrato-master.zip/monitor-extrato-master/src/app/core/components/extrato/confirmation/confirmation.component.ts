import { BackOfficeService } from './../backoffice/service/backoffice.service';
import { SpreadsheetComponent } from './../spreadsheet/spreadsheet.component';
import { NgbModal, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { ObservationComponent } from './../observation/observation.component';
import { Component, OnInit, Input } from '@angular/core';
import { Backoffice } from '../../../interfaces/backoffice';
import { HttpParams, HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-confirmation',
  templateUrl: './confirmation.component.html',
  styleUrls: ['./confirmation.component.scss']
})
export class ConfirmationComponent implements OnInit {

  Spreadsheet: typeof SpreadsheetComponent;
  Observation: typeof ObservationComponent;
    closeResult: string;
    @Input() content;
    @Input() close;
    @Input() date;
    @Input() tipo;
    @Input() operacao;
    @Input() role;



  backOffice: any;
  data: any;

  constructor(
    private observation: NgbModal,
    public activeModal: NgbActiveModal,
    private modalService: NgbModal,
    private bkoService: BackOfficeService,
    private http: HttpClient
    ) {
      this.Observation = ObservationComponent;
      this.Spreadsheet = SpreadsheetComponent;
  }

  ngOnInit() {  }

  async openSpreadsheet (spreadsheet) {
    const modalRef = await this.modalService.open(spreadsheet, {
      size: 'lg',
      centered: true,
      keyboard: false

    });
    modalRef.result.then(res => {
      this.activeModal.close();
    });
  }


  async openObservation() {
    const modalRef = await this.observation.open(this.Observation,
    {
      centered: true,
      size: 'lg',
      keyboard: true

    });

    modalRef.result.then(async res => {
      await this.bkoService.reprove(this.date, this.tipo, this.operacao, this.role, res);
      this.activeModal.close();
    });

    modalRef.result.then(async res => {
      this.activeModal.close();
    });

  }



  aprovarTudo() {
    // this.confirmationService.aprovarTudo(this.backOffice).subscribe((backOffices: Backoffice[]) => {
    //   this.backOffices = backOffices;
    // });
  }

  currentDate() {
    const data = new Date();
    data.setDate(data.getDate());
    console.log([('0' + data.getDate()).slice(-2), ('0' + (data.getMonth() + 1)).slice(-2)].join('/'));
    const dataAtual = [('0' + data.getDate()).slice(-2), ('0' + (data.getMonth() + 1)).slice(-2)].join('/');
    return dataAtual;
  }



}
