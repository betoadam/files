import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { LineRefreshService } from './service/line-refresh.service';


@Component({
  selector: 'app-line-refresh',
  templateUrl: './line-refresh.component.html',
  styleUrls: ['./line-refresh.component.scss']
})
export class LineRefreshComponent implements OnInit {

  tipo: any;
  @Input() date;

  constructor(
    private activeModal: NgbActiveModal,
    private modalService: NgbModal,
    private refreshService: LineRefreshService
    ) { }

  ngOnInit() {
  }

   reset(tipo) {
      if (tipo) {
      this.refreshService.Reset(this.date, tipo)
        .then(res => {
          this.activeModal.close();
        }).catch(err => {
          this.activeModal.close();
        });
      } else {
          this.activeModal.close();
      }
    }

  async cancel() {
    await this.activeModal.close();
  }
}
