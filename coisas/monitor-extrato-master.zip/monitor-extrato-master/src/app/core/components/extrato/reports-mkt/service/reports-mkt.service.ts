import { ToastService } from './../../../../services/toast/toast.service';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ReportsMktService {
  constructor(private http: HttpClient, private toast: ToastService) {}

  approve(date, tipo, role, body) {
    return new Promise((resolve, reject) => {
      return this.http
        .put(
          `${environment.urlApiTwo}/${environment.Aprov}/${environment.marketing}?data=${date}&tipo=${tipo}&role=${role}`,
          body
        )
        .subscribe(
          res => {
            this.toast.show('Aprovado com sucesso', {
              delay: 5000,
              autohide: true,
              classname: 'bg-success text-light'
            });
            resolve(res);
          },
          err => {
            if (err.error.Message) {
              this.toast.show(err.error.Message, {
                delay: 5000,
                autohide: true,
                classname: 'bg-danger text-light'
              });
              console.log(err);
              } else {
                this.toast.show
              ('Erro inesperado, não foi possível concluir a ação.',
              {
                delay: 5000,
                autohide: true,
                classname: 'bg-danger text-light'
              });
              console.log(err); }
              reject(err);
          }
        );
    });
  }
}
