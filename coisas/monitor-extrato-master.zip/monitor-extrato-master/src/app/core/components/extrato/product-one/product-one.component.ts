import { Component, OnInit, Input } from '@angular/core';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { saveAs } from "file-saver";
import { HomeService } from 'src/app/pages/home/service/home.service';
import { ObservationComponent } from '../observation/observation.component';
import { ProductOneService } from './service/product-one.service';
@Component({
  selector: 'app-product-one',
  templateUrl: './product-one.component.html',
  styleUrls: ['./product-one.component.scss']
})
export class ProductOneComponent implements OnInit {


  amostras: any;
  loading = false;
  data: any;
  Observation: typeof ObservationComponent;
  tipo: any;

  @Input() title;
  @Input() date;

  constructor(
    public activeModal: NgbActiveModal,
    private homeService: HomeService,
    private modalService: NgbModal,
    private producOneService: ProductOneService
    ) {
      this.Observation = ObservationComponent;
    }

  async ngOnInit() {
    this.tipo = await this.title.toLocaleLowerCase();
    await this.getAmostras();
  }

  isOdd(data) {
    if (data % 2 === 1) {
      return true;
    }
    return false;
  }

  async getAmostras() {
    console.log('date product-one', this.date);
    this.amostras = await this.homeService.getAmostra(this.date);
    // this.amostras = await mock;
  }

  async getDownload() {
  this.loading = true;
  let filename = "report.zip";
  await this.homeService.downloadReport(this.amostras)
  .subscribe(
    data => {
      this.loading = false;
      saveAs(data, filename);
    },
    err => {
      this.loading = false;
      alert("Não foi possível realizar o download.");
      console.error(err);
    }
  );
  }

  async open(content, approved, role) {
    const modalRef = await this.modalService.open(content, {
      centered: true,
      size: 'lg',
      keyboard: false
    });
    modalRef.result.then(async res => {
      if (approved) {
        this.producOneService.approve(this.date, this.tipo, role, res)
        .then(res => {
          this.activeModal.close();
        }).catch(err => {
          // toast msg de erro
          this.activeModal.close();
        });
      } else {
        this.producOneService.reprove(this.date, this.tipo, role, res)
        .then(res => {
          this.activeModal.close();
        }).catch(err => {
          // toast msg de erro
          this.activeModal.close();
        });
      }
    });
  }

  async cancel() {
    await this.activeModal.close();
  }
}
