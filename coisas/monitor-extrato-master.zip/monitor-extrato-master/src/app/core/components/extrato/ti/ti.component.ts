import { Component, OnInit, Input } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { DataService } from 'src/app/pages/home/data/data.service';
import { TiService } from './service/ti.service';
@Component({
  selector: 'app-ti',
  templateUrl: './ti.component.html',
  styleUrls: ['./ti.component.scss']
})
export class TiComponent implements OnInit {

  @Input() tipo;
  @Input() date;
  @Input() title;
  @Input() role;
  tis: any;
  count = 0;
  current: number;
  loaded = false;
  total: number;



  constructor(
    public activeModal: NgbActiveModal,
    private tiService: TiService
  ) { }

  async ngOnInit() {

    await this.getTis();
    await this.approvedCal();
    this.loaded = true;
  }

  async getTis() {
    const tipo = this.title.toLowerCase();
    const role = 'ti';
    this.tis = await this.tiService.getTi(this.date, tipo, role);
  }

  approvedCal() {
    Object.keys(this.tis).map(data => {
        if (this.tis[data].status === 'A') {
          this.count = this.count + 1;
        }
    });
    this.total = Object.keys(this.tis).length;
    this.current = Math.round((this.count / this.total) * 100);
  }

  async cancel() {
    await this.activeModal.close();
  }
}
