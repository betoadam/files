import { TestBed } from '@angular/core/testing';

import { TiService } from './ti.service';

describe('TiService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: TiService = TestBed.get(TiService);
    expect(service).toBeTruthy();
  });
});
