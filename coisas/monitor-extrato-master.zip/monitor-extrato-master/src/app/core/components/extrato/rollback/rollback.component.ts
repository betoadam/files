import { Component, OnInit, Input } from '@angular/core';
import { NgbActiveModal, NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';

import { ObservationComponent } from '../observation/observation.component';
import { RollbackService } from './service/rollback.service';

@Component({
  selector: 'app-rollback',
  templateUrl: './rollback.component.html',
  styleUrls: ['./rollback.component.scss']
})
export class RollbackComponent implements OnInit {

  @Input() date;
  @Input() tipo;
  @Input() modal;

  Observation: typeof ObservationComponent;

  constructor(
    public activeModal: NgbActiveModal,
    private modalService: NgbModal,
    private rollbackService: RollbackService
  ) {
    this.Observation = ObservationComponent;
  }

  ngOnInit() {
  }

  async openModal(data, step, role) {
    const modalRef = await this.modalService.open(data, {
      centered: true,
      size: 'lg',
      keyboard: false
    });
    modalRef.result.then(async res => {
      if (this.modal === 'prod') {
        this.rollbackService.reproveProd(this.date, this.tipo, step, role, res)
        .then(x => {
          this.activeModal.close();
        }).catch(e => {
          // toast com a mensagem de erro.
          this.activeModal.close();
        });
      }
      if (this.modal === 'mkt') {
        this.rollbackService.reproveMkt(this.date, this.tipo, step, role, res)
        .then(x => {
          this.activeModal.close();
        }).catch(e => {
          // toast com a mensagem de erro.
          this.activeModal.close();
        });
      }
    });

    modalRef.result.then (res => {
      this.cancel();
    });
  }

  async cancel() {
    await this.activeModal.close();
  }
}
