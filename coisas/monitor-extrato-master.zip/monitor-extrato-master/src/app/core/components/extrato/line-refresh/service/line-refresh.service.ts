import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { ToastService } from 'src/app/core/services/toast/toast.service';

@Injectable({
  providedIn: 'root'
})
export class LineRefreshService {

  constructor(private http: HttpClient, private toast: ToastService) { }

  Reset(date, tipo ) {
    try {
      let body: any;
      body = {};
      return new Promise((resolve, reject) => {
        return this.http
          .put(
            `${environment.urlApiTwo}/resetar?data=${date}&tipo=${tipo}`,
            body
          )
          .subscribe(
              res => {
                this.toast.show('Aprovado com sucesso', {
                  delay: 10000,
                  autohide: true,
                  classname: 'bg-success text-light'
                });
                resolve(res);
              },
              err => {
                if (err.error.Message) {
                  this.toast.show(err.error.Message, {
                    delay: 5000,
                    autohide: true,
                    classname: 'bg-danger text-light'
                  });
                  console.log(err);
                  } else {
                    this.toast.show
                  ('Erro inesperado, não foi possível concluir a ação.',
                  {
                    delay: 5000,
                    autohide: true,
                    classname: 'bg-danger text-light'
                  });
                  console.log(err); }
                  reject(err);
              }
          );
      });
    } catch (error) {
      console.log(error);
    }

  }
}
