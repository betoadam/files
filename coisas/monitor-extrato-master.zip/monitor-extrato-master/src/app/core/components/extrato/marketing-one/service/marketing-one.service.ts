import { ToastService } from '../../../../services/toast/toast.service';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';


@Injectable({
  providedIn: 'root'
})
export class MarketingOneService {

  constructor(private httpClient: HttpClient, private toast: ToastService) { }

  listar() {

  }

  onUpload(imagens, tipo, date, nome, role, setorImagem) {

    const formData = new FormData();
    formData.append("files",imagens);
    this.httpClient.post<any>(`${environment.urlApiTwo}/${environment.marketingImagem}?data=${date}&tipo=${tipo}&role=${role}&setorImagem=${setorImagem}`, formData)
    .subscribe(
      res => {
            this.toast.show('Aprovado com sucesso', {
              delay: 10000,
              autohide: true,
              classname: 'bg-success text-light'
            });
      console.log(res)
    },
      (err) => {
      if (err.error.Message) {
        this.toast.show(err.error.Message, {
          delay: 10000,
          autohide: true,
          classname: 'bg-danger text-light'
        });
        console.log(err);
      } else {
        this.toast.show('Erro inesperado, não foi possível concluir a ação.', {
          delay: 10000,
          autohide: true,
          classname: 'bg-danger text-light'
        });
        console.log(err);
      }
    });

  }

  getMarketing(date, tipo, role) {
    return new Promise((resolve, reject) => {
      return this.httpClient
        .get(
          `${environment.urlApiTwo}/${environment.marketingGet}?data=${date}&tipo=${tipo}&role=${role}`
        )
        .subscribe(
          res => {
            resolve(res);
          },
          err => {
            console.log(err);
            reject(err);
          }
        );
    });
  }
}
