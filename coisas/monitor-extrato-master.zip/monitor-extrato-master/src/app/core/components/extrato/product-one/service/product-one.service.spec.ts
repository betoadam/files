import { TestBed } from '@angular/core/testing';

import { ProductOneService } from './product-one.service';

describe('ServiceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ProductOneService = TestBed.get(ProductOneService);
    expect(service).toBeTruthy();
  });
});
