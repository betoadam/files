import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ArquivoLaminaComponent } from './arquivo-lamina.component';

describe('ArquivoLaminaComponent', () => {
  let component: ArquivoLaminaComponent;
  let fixture: ComponentFixture<ArquivoLaminaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ArquivoLaminaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ArquivoLaminaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
