import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportsProdComponent } from './reports-prod.component';

describe('ReportsProdComponent', () => {
  let component: ReportsProdComponent;
  let fixture: ComponentFixture<ReportsProdComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReportsProdComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReportsProdComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
