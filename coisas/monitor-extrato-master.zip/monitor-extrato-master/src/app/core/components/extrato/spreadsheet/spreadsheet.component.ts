import { ObservationComponent } from './../observation/observation.component';
import { Component, OnInit } from '@angular/core';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-spreadsheet',
  templateUrl: './spreadsheet.component.html',
  styleUrls: ['./spreadsheet.component.scss']
})
export class SpreadsheetComponent implements OnInit {

  Observation: typeof ObservationComponent;

  constructor(
    public activeModal: NgbActiveModal,
    private modalService: NgbModal) {
       this.Observation = ObservationComponent; }

  ngOnInit() {
  }

  async openObs(observation) {
    const modalRef = await this.modalService.open(observation, {

      centered: true,
      keyboard: false,
      size: 'lg'

    });
    modalRef.result.then(async res => {
      this.activeModal.close();
    });
  }


  async cancel() {
    await this.activeModal.close({
    });
}

}
