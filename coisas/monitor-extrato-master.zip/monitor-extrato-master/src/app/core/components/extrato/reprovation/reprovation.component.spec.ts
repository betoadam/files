import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReprovationComponent } from './reprovation.component';

describe('ReprobationComponent', () => {
  let component: ReprovationComponent;
  let fixture: ComponentFixture<ReprovationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReprovationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReprovationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
