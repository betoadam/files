import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ApprovedPdfComponent } from './approved-pdf.component';

@NgModule({
    imports: [CommonModule],
    declarations: [ApprovedPdfComponent],
    exports: [ApprovedPdfComponent]
})
export class ApprovedModule {

}
