import { TestBed } from '@angular/core/testing';

import { LaminaService } from './lamina.service';

describe('LaminaService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: LaminaService = TestBed.get(LaminaService);
    expect(service).toBeTruthy();
  });
});
