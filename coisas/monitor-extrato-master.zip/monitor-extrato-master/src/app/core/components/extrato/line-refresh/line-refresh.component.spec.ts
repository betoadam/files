import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LineRefreshComponent } from './line-refresh.component';

describe('LineRefreshComponent', () => {
  let component: LineRefreshComponent;
  let fixture: ComponentFixture<LineRefreshComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LineRefreshComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LineRefreshComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
