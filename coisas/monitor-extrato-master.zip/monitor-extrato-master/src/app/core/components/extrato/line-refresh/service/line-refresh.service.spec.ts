import { TestBed } from '@angular/core/testing';

import { LineRefreshService } from './line-refresh.service';

describe('LineRefreshService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: LineRefreshService = TestBed.get(LineRefreshService);
    expect(service).toBeTruthy();
  });
});
