import { Component, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-observation',
  templateUrl: './observation.component.html',
  styleUrls: ['./observation.component.scss']
})
export class ObservationComponent implements OnInit {

  justify: String = '';

  constructor(
    public activeModal: NgbActiveModal
  ) { }

  ngOnInit() {
  }

  input(data) {
    this.justify = data;
  }

  async cancel() {
    await this.activeModal.close({
      Obs: this.justify
    });
}
}

