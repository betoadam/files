import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { StorageService } from 'src/app/core/services/storage/storage.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  constructor(
    private router: Router,
    private storage: StorageService,
  ) {
    console.log(this.router.url)

  }

  async logout() {
    await this.storage.clearStorage();
    window.location.reload();
  }

  ngOnInit() {
  }

}
