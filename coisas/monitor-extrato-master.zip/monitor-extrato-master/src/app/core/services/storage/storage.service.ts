import { Injectable } from '@angular/core';
import { environment } from '../../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class StorageService {

  constructor() { }

// Função número 1
  setItem(name: string, item: any) {
    try {
      localStorage.setItem(
        btoa(name + environment.envName),
        btoa(JSON.stringify(item))
      );
    } catch (error) {
      throw error;
    }
  }

// Função numero 2
  getItem(name: string) {
    try {
      const data = localStorage.getItem(btoa(name + environment.envName));
      if (data) {
        return JSON.parse(atob(data));
      } else {
        return false;
      }
    } catch (error) {
      return false;
    }

  }

// Função numero 3
  deleteItem(name: string) {
    try {
      localStorage.removeItem(btoa(name + environment.envName));
    } catch (e) {
      throw e;
    }
  }

// Função numero 4
  clearStorage() {
    try {
      localStorage.clear();
      return true;
    } catch (e) {
      throw e;
    }
  }
}
