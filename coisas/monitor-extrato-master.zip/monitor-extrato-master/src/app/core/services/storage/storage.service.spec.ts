import { TestBed } from '@angular/core/testing';

import { StorageService } from './storage.service';

describe('StorageService', () => {
  beforeEach(() => TestBed.configureTestingModule({

  }));

  it('should be created', () => {
    const service: StorageService = TestBed.get(StorageService);
    expect(service).toBeTruthy();
  });

  it('Verificando armazenamento local', () => {
    const service: StorageService = TestBed.get(StorageService);
    const user = {
      User: 'user',
      Password: 'pass'
    };
    service.setItem('Banana', user);
    expect(service.getItem('Banana')).toEqual(user);
  });

  it('Armazenando um usuráro e deletando em seguida', () => {
    const service: StorageService = TestBed.get(StorageService);
    const user = {
      User: 'Allan',
      Password: '123'
    };
    service.setItem('Uva', user);
    expect(service.deleteItem('Uva')).toBeFalsy();
  });

  it('Armazenando usuários e deletando todos de uma vez em seguida', () => {
    const service: StorageService = TestBed.get(StorageService);
    const user = {
      User: 'Allan',
      Password: '123'
    };
    const user2 = {
      User: 'Vinicius',
      Password: '123'
    };
    const user3 = {
      User: 'Pedro',
      Password: '123'
    };
    service.setItem('abacate', user);
    service.setItem('abacaxi', user2);
    service.setItem('goiaba', user3);
    service.clearStorage();
    expect(service.getItem('abacate')).toBeFalsy();
  });
});
