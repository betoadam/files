export interface Ti {
    Token: string;
    BackofficePrevidencia: string;
    BackofficeFundos: string;
    BackofficeCoe: string;
    Backoffice: string;
}