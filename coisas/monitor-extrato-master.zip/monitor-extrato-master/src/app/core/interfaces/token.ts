export interface Token {
    Token: string;
}