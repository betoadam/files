export interface User {
    User: string;
    Password: string;
    Profile: string;
}