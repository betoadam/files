export interface Backoffice {
    Previdencia: string;
    Fundos: string;
    Coe: string;
    Backoffice: string;
}
