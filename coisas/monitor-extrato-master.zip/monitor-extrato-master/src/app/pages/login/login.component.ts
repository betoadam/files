import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms';
import { AuthService } from './auth/auth.service';
import { ToastService } from 'src/app/core/services/toast/toast.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  private router: Router;
  private loginForm: FormGroup;

  constructor(
    private formBuilder: FormBuilder,
    private auth: AuthService,
    private toast: ToastService,
  ) { 
    this.loginForm = this.formBuilder.group({
      User: new FormControl(''),
      Password: new FormControl('')
      
    });
  }

  ngOnInit() {

  }

  async login() {
    console.log('-->', this.loginForm.value);
    await this.auth.login(this.loginForm.value);

  }


}
