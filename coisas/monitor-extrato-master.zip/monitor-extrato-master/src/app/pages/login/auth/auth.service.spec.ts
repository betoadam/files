import { TestBed, fakeAsync } from '@angular/core/testing';
import { AuthService } from './auth.service';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { environment } from '../../../../environments/environment';
import { StorageService } from 'src/app/core/services/storage/storage.service';
describe('AuthService', () => {
  beforeEach(() => TestBed.configureTestingModule({
    imports: [
      HttpClientTestingModule,
      RouterTestingModule,
    ]
  }));
  it('should be created', () => {
    const service: AuthService = TestBed.get(AuthService);
    expect(service).toBeTruthy();
  });

  it('verificando req post dentro de login(user)', () => {
    const httpMock: HttpTestingController = TestBed.get(HttpTestingController);
    const service: AuthService = TestBed.get(AuthService);
    const user = {
      User: 'jovem',
      Password: '123'
    };
    service.login(user);
    const req = httpMock.expectOne(`${environment.urlApiOne}/${environment.login}`);
    expect(req.request.url).toBe(`${environment.urlApiOne}/${environment.login}`);
    expect(req.request.method).toEqual('POST');
    expect(req.request.body).toEqual(user);
    req.flush(user);
  });
});
