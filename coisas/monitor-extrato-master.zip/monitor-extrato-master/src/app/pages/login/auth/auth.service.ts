import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { StorageService } from 'src/app/core/services/storage/storage.service';
import { environment } from '../../../../environments/environment';
import { User } from 'src/app/core/interfaces/user';
import { Router } from '@angular/router';
import { ToastService } from 'src/app/core/services/toast/toast.service';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  loading: boolean;

  constructor(
    private http: HttpClient,
    private storage: StorageService,
    private router: Router,
    private toast: ToastService
  ) { }

  // Função número 5
  async login(user) {
    this.loading = true;
    // post to get auth token
    this.http.post<User>(`${environment.urlApiOne}/${environment.login}`, user).subscribe(async res => {
      await this.storage.setItem('Token', res);
      // auth with token
      this.http.get(`${environment.urlApiOne}/${environment.authentication}`).subscribe(async res => {
        console.log(res);
        await this.storage.setItem('User', res);
        this.loading = false;
        this.router.navigate(['']);
      }, error => {
        this.loading = false;
        console.log(error);
      });
    }, error => {
      // fail1
      this.loading = false;
      this.toast.show('Usuário ou senha inválida!', {
        delay: 10000,
        autohide: true,
        classname: 'bg-danger text-light'
      });
    });
    // const tempUser = {
    //   id: "001",
    //   profile: "admin"
    // }
    // await this.storage.setItem('User', tempUser);
    // this.loading = false;
    // this.router.navigate(['home']);
  }


}
