import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { environment } from "../../../../environments/environment";
import { Observable } from "rxjs";



@Injectable({
  providedIn: "root"
})
export class HomeService {
  constructor(
    private http: HttpClient
  ) {  }

  getAmostra(date) {
    return new Promise((resolve, reject) => {
      return this.http.get(environment.urlApiTwo + `/download/amostra?data=${date}`).subscribe(
        res => {
          resolve(res);
        },
        err => {
          console.log(err);
          reject(err);
        }
      );
    });
  }

  getDownload(amostras) {
    return this.http
      .post<any>("https://api.generate.private.dev.vectorlabs.cloud/report/sample", amostras)
      .subscribe(
        res => {
          const blob = new Blob([res], {
            type: "application/zip"
          });
          const url = window.URL.createObjectURL(blob);
          window.open(url);
        },
        error => {
          console.log("erro", error);
        }
      );
  }

  public downloadReport(file): Observable<any> {
    let url = "https://api.generate.private.dev.vectorlabs.cloud/report/sample";
    var body = file;

    return this.http.post(url, body, {
      responseType: "blob",
      headers: new HttpHeaders().append("Content-Type", "application/json")
    });
  }
}
