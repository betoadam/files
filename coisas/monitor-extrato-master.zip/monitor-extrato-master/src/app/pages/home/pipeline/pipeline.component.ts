import { Component, OnInit, Input } from '@angular/core';
import { TiComponent } from 'src/app/core/components/extrato/ti/ti.component';
import { BackofficeComponent } from 'src/app/core/components/extrato/backoffice/backoffice.component';
import { ProductOneComponent } from 'src/app/core/components/extrato/product-one/product-one.component';
import { MarketingOneComponent } from 'src/app/core/components/extrato/marketing-one/marketing-one.component';
import { ObservationComponent } from 'src/app/core/components/extrato/observation/observation.component';
import { ConfirmationComponent} from 'src/app/core/components/extrato/confirmation/confirmation.component';
import { ToastComponent} from 'src/app/core/components/extrato/toast/toast.component';
import { ReportsMktComponent } from 'src/app/core/components/extrato/reports-mkt/reports-mkt.component';
import { ArquivoLaminaComponent } from 'src/app/core/components/extrato/arquivo-lamina/arquivo-lamina.component';

import { NgbModal, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { DataService } from '../data/data.service';

@Component({
  selector: 'app-pipeline',
  templateUrl: './pipeline.component.html',
  styleUrls: ['./pipeline.component.scss']
})
export class PipelineComponent implements OnInit {
  closeResult: string;
  Observation: typeof ObservationComponent;
  BackOffice: typeof BackofficeComponent;
  Confirmation: typeof ConfirmationComponent;
  MarketingOne: typeof MarketingOneComponent;
  ProductOne: typeof ProductOneComponent;
  ArquivoLamina: typeof ArquivoLaminaComponent;
  Ti: typeof TiComponent;
  Toast: typeof ToastComponent;
  reportsMkt: typeof ReportsMktComponent;


  constructor(
    private modalService: NgbModal,
    private data: DataService
  ) {
    this.Observation = ObservationComponent;
    this.BackOffice = BackofficeComponent;
    this.Confirmation = ConfirmationComponent;
    this.MarketingOne = MarketingOneComponent;
    this.ProductOne = ProductOneComponent;
    this.ArquivoLamina = ArquivoLaminaComponent;
    this.Ti = TiComponent;
    this.Toast = ToastComponent;
    this.reportsMkt = ReportsMktComponent;
  }

  @Input() title;
  private _listApproved;
  @Input() set listApproved(value) {
    this._listApproved = value;
  }
  @Input() profile;
  @Input() date;

  ngOnInit() {
  }

    open(content) {
      this.modalService.open(content, {
        centered: true,
        size: 'lg',
        backdrop: 'static'
      });
    }

    openPdfConfirmation(content) {
      this.modalService.open(content, {
        centered: true,
        backdrop: 'static'
      });
    }

  async openModal(content, tipo, operacao) {
    const modalRef = await this.modalService.open(content, {
    size: 'lg',
    backdrop: 'static'
    });
    modalRef.componentInstance.tipo = tipo;
    modalRef.componentInstance.operacao = operacao;
    modalRef.componentInstance.date = this.date;

    modalRef.result.then(res => {
//      this.data.getApproved(tipo, operacao, this.date);
    });
  }
}
