import { Component, OnInit } from "@angular/core";
import { HomeService } from "./service/home.service";
import { saveAs } from "file-saver";
import { mock } from "../home/mock"


@Component({
  selector: "ap-home",
  templateUrl: "./home.component.html",
  styleUrls: ["./home.component.scss"]
})
export class HomeComponent implements OnInit {
  amostras: any;
  loading = false;
  data: any;
  constructor(
    private homeService: HomeService
  ) {
  }

  async ngOnInit() {
    // await this.getAmostras();
  }

  isOdd(data) {
    if (data % 2 === 1) {
      
      return true;
    }
    return false;
  }

  async getAmostras() {
    // this.amostras = await this.homeService.getAmostra(this.date);
    // console.log('amostras --->', this.amostras);
    // this.amostras = await mock;
  }

  async getDownload() {
  this.loading = true;
  let filename = "report.zip";
  await this.homeService.downloadReport(this.amostras)
  .subscribe(
    data => {
      this.loading = false;
      saveAs(data, filename);
    },
    err => {
      this.loading = false;
      alert("Não foi possível realizar o download.");
      console.error(err);
    }
  );
  }

  currentDate() {
    const data = new Date();
    return data;
  }
}
