import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  constructor(
    private http: HttpClient
  ) { }

  getApproved() {
    return new Promise((resolve, reject) => {
      return this.http.get(
        `${environment.urlApiTwo}/${environment.home}`)
      .subscribe(res => {
        resolve(res);
      }, err => {
        console.log(err);
        reject(err);
      });
    });
  }
  getInfoModal(operacao, tipo, date) {
    return new Promise((resolve, reject) => {
      switch (tipo) {
        case 'ti':
          return this.http.get(
            `${environment.urlApiTwo}/${environment.ti}?date=${date}&tipo=${tipo}&operacao=${operacao}`)
          .subscribe(res => {
            resolve(res);
          }, err => {
            console.log(err);
            reject(err);
          });
        case 'BackOffice':
          return this.http.get(
            `${environment.urlApiTwo}/${environment.BackOffice}?date=${date}&tipo=${tipo}&operacao=${operacao}`)
          .subscribe(res => {
            resolve(res);
          }, err => {
            console.log(err);
            reject(err);
          });
        case 'producOne':
          break;
      }
    });
  }
}
