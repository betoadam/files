import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ExtratoComponent } from './extrato.component';
import { RouterModule } from '@angular/router';
import { PipelineComponent } from './pipeline/pipeline.component';
import { NgCircleProgressModule } from 'ng-circle-progress';
import { ConfirmationModule } from '../../core/components/extrato/confirmation/confirmation.module';
import { ConfirmationComponent} from '../../core/components/extrato/confirmation/confirmation.component';
import { ApprovedPdfComponent } from 'src/app/core/components/extrato/approved-pdf/approved-pdf.component';
import { ApprovedModule } from 'src/app/core/components/extrato/approved-pdf/approved-pdf.module';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { setTheme } from 'ngx-bootstrap/utils';
import { FormsModule } from '@angular/forms';
setTheme('bs4'); // or 'bs4'


@NgModule({
  declarations: [
    ExtratoComponent,
    PipelineComponent
  ],
  imports: [
    CommonModule,
    ConfirmationModule,
    ApprovedModule,
    FormsModule,
    RouterModule.forChild([
      {
        path: '',
        component: ExtratoComponent,
      }
    ]),
    NgCircleProgressModule.forRoot({
      // set defaults here
      radius: 100,
      outerStrokeWidth: 16,
      innerStrokeWidth: 8,
      outerStrokeColor: '#78C000',
      innerStrokeColor: '#C7E596',
      animationDuration: 300,
      percent: 85
    }),
    BsDatepickerModule.forRoot(),
    ],
    entryComponents: [ConfirmationComponent, ApprovedPdfComponent],
  providers: [

  ]
})
export class ExtratoModule { }
