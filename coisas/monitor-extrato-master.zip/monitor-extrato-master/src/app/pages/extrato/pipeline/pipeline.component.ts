import { Component, OnInit, Input, Output, EventEmitter } from "@angular/core";
import { TiComponent } from "src/app/core/components/extrato/ti/ti.component";
import { BackofficeComponent } from "src/app/core/components/extrato/backoffice/backoffice.component";
import { ProductOneComponent } from "src/app/core/components/extrato/product-one/product-one.component";
import { MarketingOneComponent } from "src/app/core/components/extrato/marketing-one/marketing-one.component";
import { ObservationComponent } from "src/app/core/components/extrato/observation/observation.component";

import { ToastComponent } from "src/app/core/components/extrato/toast/toast.component";
import { ArquivoLaminaComponent } from "src/app/core/components/extrato/arquivo-lamina/arquivo-lamina.component";
import { ReportsMktComponent } from "src/app/core/components/extrato/reports-mkt/reports-mkt.component";

import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { ReportsProdComponent } from "src/app/core/components/extrato/reports-prod/reports-prod.component";
import { ApprovedPdfComponent } from 'src/app/core/components/extrato/approved-pdf/approved-pdf.component';

@Component({
  selector: "app-pipeline",
  templateUrl: "./pipeline.component.html",
  styleUrls: ["./pipeline.component.scss"]
})
export class PipelineComponent implements OnInit {
  data: any;
  closeResult: string;
  Observation: typeof ObservationComponent;
  BackOffice: typeof BackofficeComponent;
  MarketingOne: typeof MarketingOneComponent;
  ProductOne: typeof ProductOneComponent;
  ArquivoLamina: typeof ArquivoLaminaComponent;
  ApprovedPdf: typeof ApprovedPdfComponent;
  ReportsMkt: typeof ReportsMktComponent;
  Ti: typeof TiComponent;
  Toast: typeof ToastComponent;
  ReportsProd: typeof ReportsProdComponent;

  @Output() valueChange = new EventEmitter;

  constructor(private modalService: NgbModal) {
    this.Observation = ObservationComponent;
    this.BackOffice = BackofficeComponent;
    this.MarketingOne = MarketingOneComponent;
    this.ProductOne = ProductOneComponent;
    this.ArquivoLamina = ArquivoLaminaComponent;
    this.Ti = TiComponent;
    this.Toast = ToastComponent;
    this.ReportsMkt = ReportsMktComponent;
    this.ReportsProd = ReportsProdComponent;
    this.ApprovedPdf = ApprovedPdfComponent;
  }

  @Input() title;
  private _listApproved;
  @Input() set listApproved(value) {
    this._listApproved = value;
  }
  @Input() profile;
  @Input() date;

  ngOnInit() {}

  openPdfConfirmation(content) {
    this.modalService.open(content, {
      centered: true,
      backdrop: "static"
    });
  }

  async openModal(content, modal) {
    let options = {};
    if (modal === "ArquivoLamina" || modal === "ApprovedPdf") {
      options = {
        size: "md",
        backdrop: "static",
        centered: true,
        modalClass: "modal",
        keyboard: false
      };
    } else {
      options = {
        size: "lg",
        backdrop: "static",
        centered: true,
        keyboard: false
      };
    }
    if (modal === "ApprovedPdf") {
      // chamar serviço
    }
    const modalRef = await this.modalService.open(content, options);
    modalRef.componentInstance.date = this.date;
    modalRef.componentInstance.title = this.title;
    modalRef.result.then(res => {
      this.valueChange.emit(res);
    });
  }
}
