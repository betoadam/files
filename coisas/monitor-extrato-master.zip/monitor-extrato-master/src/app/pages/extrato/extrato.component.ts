import { Component, OnInit, Inject, Input } from '@angular/core';
import { StorageService } from 'src/app/core/services/storage/storage.service';
import { User } from 'src/app/core/interfaces/user';
import { DataService } from './data/data.service';
import { defineLocale } from 'ngx-bootstrap/chronos';
import { ptBrLocale } from 'ngx-bootstrap/locale';
import { BsLocaleService } from 'ngx-bootstrap/datepicker';
import { __await } from 'tslib';

import { ExtratoService } from '../extrato/extrato.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { LineRefreshComponent } from 'src/app/core/components/extrato/line-refresh/line-refresh.component';
import { TiComponent } from 'src/app/core/components/extrato/ti/ti.component';
defineLocale('pt-br', ptBrLocale);


@Component({
  selector: 'extrato',
  templateUrl: './extrato.component.html',
  styleUrls: ['./extrato.component.scss']
})
export class ExtratoComponent implements OnInit {

  @Input() date;

  user: User;
  listApproved: {};
  private: any;
  safraInvest: any;
  outros: any;
  loaded: boolean;
  count = 0;
  current: number;

  modelDate: any;
  status: any;

  lineRefresh: typeof LineRefreshComponent;
  activeModal: any;

  constructor(
    private data: DataService,
    private storage: StorageService,
    private localeService: BsLocaleService,
    private modalService: NgbModal,
    private extratoService: ExtratoService
  ) {
    localeService.use('pt-br');
    this.lineRefresh = LineRefreshComponent;
  }


  async ngOnInit() {
    this.user = await this.storage.getItem('User');
    // this.locale.use('pt');
    this.modelDate = await this.currentDate();
    await this.getApproved(null);
  }

  async logout() {
    await this.storage.clearStorage();
    window.location.reload();
  }

  async restore() {
    this.count = await null;
    this.current = await null;
    this.loaded = await false;
    this.private = await null;
    this.safraInvest = await null;
    this.outros = await null;
    this.listApproved = await null;
  }

  async getApproved(date) {
    this.restore();
    if (date) {
        this.listApproved = await this.data.getApproved(date);
        this.private = await this.listApproved['private'];
        this.safraInvest = await this.listApproved['safrainvest'];
        this.outros = await this.listApproved['outros'];
        await this.approvedCal();
        this.loaded = true;
    } else {
      const month = new Date(this.currentDate()).getMonth() + 1;
      const year = new Date(this.currentDate()).getFullYear();
      this.date = month.toString().padStart(2, '0') + '/' + year;
        this.listApproved = await this.data.getApproved(this.date);
        this.private = await this.listApproved['private'];
        this.safraInvest = await this.listApproved['safrainvest'];
        this.outros = await this.listApproved['outros'];
        await this.approvedCal();
        this.loaded = true;
    }
    console.log('listApproved', this.listApproved);
  }

  approvedCal() {
    Object.keys(this.listApproved).map(data => {
      Object.keys(this.listApproved[data]).map(res => {
        if (this.listApproved[data][res] === 'A') {
          this.count = this.count + 1;
        }
      });
    });
    this.current = Math.round((this.count / 21) * 100);
  }

  refresh() {
    this.getApproved(this.date);
  }

  onOpenCalendar(container) {
    container.monthSelectHandler = async (event: any) => {
      container._store.dispatch(container._actions.select(event.date));
      const month = new Date(this.modelDate).getMonth() + 1;
      const year = new Date(this.modelDate).getFullYear();
      this.date = month.toString().padStart(2, '0') + '/' + year;
      this.getApproved(this.date);
    };
    container.setViewMode('month');
  }

  currentDate() {
    const data = new Date();
    return data;
  }

  async openModal() {
    const modalRef = await this.modalService.open(this.lineRefresh, {
      centered: true,
      size: 'lg',
      keyboard: false
    });
    modalRef.componentInstance.date = this.date;
    modalRef.result.then(async res => {
      this.getApproved(this.date);
    });
  }

  async cancel() {
    await this.activeModal.close();
  }
}
