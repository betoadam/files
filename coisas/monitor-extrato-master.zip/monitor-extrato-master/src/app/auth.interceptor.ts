import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { StorageService } from './core/services/storage/storage.service';
import { User } from './core/interfaces/user';
import { Token } from './core/interfaces/token';


@Injectable()
export class AuthInterceptor implements HttpInterceptor {
    user: User;
    token: Token;
    constructor(
        private storage: StorageService) {
    }
    public intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        this.token = this.storage.getItem('Token');
        if (this.token) {
            const cloned = req.clone({
                headers: req.headers.set('Authorization',
                    this.token.Token)
            });
            return next.handle(cloned);

        } else {
            return next.handle(req);
        }
    }
}
