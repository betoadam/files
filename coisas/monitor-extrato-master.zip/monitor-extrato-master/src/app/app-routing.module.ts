import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from './core/guards/auth/auth.guard';

const routes: Routes = [
  {
    path: 'login',
    loadChildren: './pages/login/login.module#LoginModule'
  },
  {
    path: 'home',
    loadChildren: './pages/home/home.module#HomeModule',
    canActivate: [AuthGuard]
  },
  {
    path: 'extrato',
    loadChildren: './pages/extrato/extrato.module#ExtratoModule',
    canActivate: [AuthGuard]
  },
  {
    path: '',
    redirectTo: '/extrato',
    pathMatch: 'full'
  },
  {
    path: '**',
    redirectTo: '/extrato',
    pathMatch: 'full'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
