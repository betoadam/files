import { Component } from '@angular/core';
import { StorageService } from './core/services/storage/storage.service';
import { User } from './core/interfaces/user';
import { Router, NavigationStart, NavigationEnd } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'monitor';
  user: User;
  show: boolean;

  constructor(private storage: StorageService, private router: Router) {
    this.innitialize();
  }

  async innitialize() {
    this.router.events.forEach(event => {
      if (event instanceof NavigationEnd) {
        console.log(event);
        if (event['url'] == '/login') {
          this.show = false;
        } else {
          this.show = true;
        }
      }
    });
  }
}
