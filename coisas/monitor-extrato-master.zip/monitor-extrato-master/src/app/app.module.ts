import { SpreadsheetComponent } from './core/components/extrato/spreadsheet/spreadsheet.component';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { AuthInterceptor } from './auth.interceptor';
import { LocationStrategy, HashLocationStrategy } from '@angular/common';
import { ToastComponent } from './core/components/extrato/toast/toast.component';
import { NgCircleProgressModule } from 'ng-circle-progress';
import { BackofficeComponent } from './core/components/extrato/backoffice/backoffice.component';
import { TiComponent } from './core/components/extrato/ti/ti.component';
import { ProductOneComponent } from './core/components/extrato/product-one/product-one.component';
import { MarketingOneComponent } from './core/components/extrato/marketing-one/marketing-one.component';
import { ApprovedPdfComponent } from 'src/app/core/components/extrato/approved-pdf/approved-pdf.component';
import { ApprovedModule } from 'src/app/core/components/extrato/approved-pdf/approved-pdf.module';
import { ObservationComponent } from './core/components/extrato/observation/observation.component';
import { BrowserAnimationsModule, NoopAnimationsModule } from '@angular/platform-browser/animations';
import { ArquivoLaminaComponent } from './core/components/extrato/arquivo-lamina/arquivo-lamina.component';
import { setTheme } from 'ngx-bootstrap/utils';
import { SidebarComponent } from './core/components/global/sidebar/sidebar.component';
import { HeaderComponent } from './core/components/global/header/header.component';
import { ReportsMktComponent } from './core/components/extrato/reports-mkt/reports-mkt.component';
import { ReportsProdComponent } from './core/components/extrato/reports-prod/reports-prod.component';
import { ReprovationComponent } from './core/components/extrato/reprovation/reprovation.component';
import { ConfirmationModule } from './core/components/extrato/confirmation/confirmation.module';
import { ConfirmationComponent} from './core/components/extrato/confirmation/confirmation.component';
import { RollbackComponent } from './core/components/extrato/rollback/rollback.component';
import { LineRefreshComponent } from './core/components/extrato/line-refresh/line-refresh.component';

setTheme('bs4'); // or 'bs4'

@NgModule({
  declarations: [
    AppComponent,
    ToastComponent,
    TiComponent,
    BackofficeComponent,
    ProductOneComponent,
    MarketingOneComponent,
    ObservationComponent,
    SidebarComponent,
    HeaderComponent,
    ArquivoLaminaComponent,
    ReportsMktComponent,
    ReportsProdComponent,
    ReprovationComponent,
    RollbackComponent,
    SpreadsheetComponent,
    LineRefreshComponent
  ],
  imports: [
    NgbModule,
    BrowserModule,
    AppRoutingModule,
    ConfirmationModule,
    HttpClientModule,
    ApprovedModule,
    NgCircleProgressModule.forRoot({
      // set defaults here
      radius: 100,
      outerStrokeWidth: 16,
      innerStrokeWidth: 8,
      outerStrokeColor: '#78C000',
      innerStrokeColor: '#C7E596',
      animationDuration: 300,
      percent: 85
    }),
    BrowserAnimationsModule,
    NoopAnimationsModule
  ],
  entryComponents: [
    TiComponent,
    BackofficeComponent,
    ProductOneComponent,
    MarketingOneComponent,
    ApprovedPdfComponent,
    ObservationComponent,
    ArquivoLaminaComponent,
    ReportsMktComponent,
    ReportsProdComponent,
    ReprovationComponent,
    ConfirmationComponent,
    RollbackComponent,
    SpreadsheetComponent,
    LineRefreshComponent
  ],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthInterceptor,
      multi: true
    },
    {
      provide: LocationStrategy,
      useClass: HashLocationStrategy
    },
  ],
  bootstrap: [
    AppComponent
  ]
})
export class AppModule { }

