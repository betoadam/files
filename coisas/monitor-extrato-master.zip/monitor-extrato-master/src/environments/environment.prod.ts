export const environment = {
  production: true,
  URL_API_TI: 'http://3.19.120.199:5001/ti'
};
