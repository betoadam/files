// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  envName: 'develop',
  urlApiOne: 'http://18.191.167.25:3001',
  urlApiTwo: 'http://api.private.dev.vectorlabs.cloud',
  //urlApiTwo: 'http://localhost:5000',
  apiNet: 'http://localhost:5000',
  authentication: 'authentication',
  ti: 'ti',
  BackOffice: 'BackOffice',
  login: 'login',
  home: 'home',
  lamina: 'lamina',
  download: 'download/amostra',
  private: 'private',
  product: 'produtos',
  backOffice: 'backoffice',
  rollBack: 'RollBack',
  marketing: 'marketing',
  marketingGet: 'marketing/imagens',
  Aprov : 'validacao/aprovar',
  Reprov : 'validacao/reprovar',
  KEY_TOKEN: 'Token',
  marketingImagem: 'marketing/img',
  URL_API_MARKETINGONE: 'http://localhost:5000/marketing/img',
  URL_API_TI: 'http://3.19.120.199:5001/ti',
  URL_API_AMOSTRA: 'http://localhost:5000/download/amostra?data=11/2019'
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
